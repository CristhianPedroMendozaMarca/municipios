/** Obtener iniciales de un nombre completo */
export const getInitials = (name = '') =>
  name.split(' ').map(w => w[0]).filter(Boolean).slice(0,2).join('').toUpperCase();

/** Formatear número como moneda boliviana */
export const formatBs = (n) =>
  `Bs ${Number(n || 0).toLocaleString('es-BO', { minimumFractionDigits:2, maximumFractionDigits:2 })}`;

/** Formatear fecha DD/MM/YYYY → YYYY-MM-DD */
export const toInputDate = (d) => {
  if (!d) return '';
  if (d.includes('-')) return d.split('T')[0];
  const [day,month,year] = d.split('/');
  return `${year}-${month}-${day}`;
};

/** Formatear fecha ISO a DD/MM/YYYY */
export const fmtDate = (d) => {
  if (!d) return '—';
  try {
    return new Date(d).toLocaleDateString('es-BO', { day:'2-digit', month:'2-digit', year:'numeric' });
  } catch { return d; }
};

/** Formatear fecha+hora */
export const fmtDateTime = (d) => {
  if (!d) return '—';
  try {
    return new Date(d).toLocaleString('es-BO', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' });
  } catch { return d; }
};

/** Retorna clase CSS del badge según estado */
export const badgeClass = (estado) => {
  const map = {
    Activo:'success', Presente:'success', Excelente:'success', Bueno:'success',
    Finalizado:'success', Acreditado:'success', Pagado:'success', Certificado:'success', Vigente:'success',
    Tardanza:'warning', Regular:'warning', 'Por Cerrar':'warning', Pendiente:'warning', 'Por Certificar':'warning',
    Ausente:'danger', Inhabilitado:'danger', Anulado:'danger', Malo:'danger',
    Permiso:'info', Ejecución:'info', Inicio:'info', 'En Proceso':'info', Planificado:'info',
    Licencia:'purple', Suspendido:'purple',
    Baja:'gray', 'Dado de Baja':'gray',
  };
  return `g-badge badge-${map[estado] || 'gray'}`;
};

/** Color de progreso según porcentaje */
export const progressColor = (pct) =>
  pct >= 80 ? '#10b981' : pct >= 50 ? '#f59e0b' : '#ef4444';

/** Paginación: construir query string */
export const buildQuery = (params) =>
  Object.entries(params).filter(([,v]) => v !== '' && v != null).map(([k,v]) => `${k}=${encodeURIComponent(v)}`).join('&');
