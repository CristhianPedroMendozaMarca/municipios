// Datos mock para desarrollo sin backend
export const MOCK_PERSONAL = [
  { id:'F-001', nombre:'Roberto Cáceres Vera', ci:'5678901', cargo:'Técnico en Sistemas', unidad:'Infraestructura TI', tipo:'Ítem', estado:'Activo', ingreso:'15/03/2022', av:'RC' },
  { id:'F-002', nombre:'Lucía Mamani Flores', ci:'4567890', cargo:'Auxiliar Administrativa', unidad:'Administración General', tipo:'Eventual', estado:'Activo', ingreso:'08/01/2024', av:'LM' },
  { id:'F-003', nombre:'José Luis Quispe Condori', ci:'6789012', cargo:'Ingeniero Civil', unidad:'Obras Públicas', tipo:'Consultor', estado:'Activo', ingreso:'10/02/2024', av:'JQ' },
  { id:'F-004', nombre:'Carmen Rosa Alvarado', ci:'3456789', cargo:'Secretaria Ejecutiva', unidad:'Despacho Alcaldía', tipo:'Ítem', estado:'Activo', ingreso:'01/06/2021', av:'CA' },
  { id:'F-005', nombre:'Raúl Condori Mamani', ci:'7890123', cargo:'Chofer Ejecutivo', unidad:'Transporte', tipo:'Ítem', estado:'Licencia', ingreso:'15/01/2020', av:'RC' },
  { id:'F-006', nombre:'Elena Torrez Choque', ci:'2345678', cargo:'Abogada Municipal', unidad:'Asesoría Legal', tipo:'Ítem', estado:'Activo', ingreso:'20/07/2019', av:'ET' },
  { id:'F-007', nombre:'Marco Huanca Apaza', ci:'8901234', cargo:'Contador', unidad:'Finanzas', tipo:'Ítem', estado:'Activo', ingreso:'01/09/2022', av:'MH' },
  { id:'F-008', nombre:'Sandra Rojas Vda. de Lima', ci:'1234567', cargo:'Trabajadora Social', unidad:'Desarrollo Social', tipo:'Eventual', estado:'Activo', ingreso:'01/03/2024', av:'SR' },
];

export const MOCK_ASISTENCIA = [
  { id:'F-001', nombre:'Roberto Cáceres V.', entrada:'08:02', salida:'17:05', estado:'Presente', obs:'—' },
  { id:'F-002', nombre:'Lucía Mamani F.', entrada:'08:47', salida:'17:00', estado:'Tardanza', obs:'47 min tarde' },
  { id:'F-003', nombre:'José Luis Quispe', entrada:'—', salida:'—', estado:'Permiso', obs:'Permiso médico aprobado' },
  { id:'F-004', nombre:'Carmen Rosa A.', entrada:'07:58', salida:'17:10', estado:'Presente', obs:'—' },
  { id:'F-005', nombre:'Raúl Condori M.', entrada:'—', salida:'—', estado:'Licencia', obs:'Licencia vigente 30 días' },
  { id:'F-006', nombre:'Elena Torrez Ch.', entrada:'08:01', salida:'17:00', estado:'Presente', obs:'—' },
  { id:'F-007', nombre:'Marco Huanca A.', entrada:'08:15', salida:'17:05', estado:'Presente', obs:'—' },
  { id:'F-008', nombre:'Sandra Rojas', entrada:'—', salida:'—', estado:'Ausente', obs:'Sin justificación' },
];

export const MOCK_DESEMPENO = [
  { id:'F-001', nombre:'Roberto Cáceres Vera', cargo:'Técnico TI', periodo:'Ene–Jun 2024', eficiencia:90, eficacia:88, resultado:85, prom:88, nivel:'Excelente' },
  { id:'F-002', nombre:'Lucía Mamani Flores', cargo:'Aux. Administrativa', periodo:'Ene–Jun 2024', eficiencia:72, eficacia:75, resultado:70, prom:72, nivel:'Bueno' },
  { id:'F-003', nombre:'José Luis Quispe', cargo:'Ingeniero Civil', periodo:'Ene–Jun 2024', eficiencia:95, eficacia:92, resultado:94, prom:94, nivel:'Excelente' },
  { id:'F-006', nombre:'Elena Torrez Choque', cargo:'Abogada Municipal', periodo:'Ene–Jun 2024', eficiencia:85, eficacia:88, resultado:86, prom:86, nivel:'Excelente' },
  { id:'F-007', nombre:'Marco Huanca Apaza', cargo:'Contador', periodo:'Ene–Jun 2024', eficiencia:60, eficacia:65, resultado:58, prom:61, nivel:'Regular' },
];

export const MOCK_ACTIVOS = [
  { id:'ACT-001', desc:'Computadora HP EliteDesk 800 G6', cod:'GAMEA/TI/2022/001', ubi:'Oficina TI – Piso 3', valor:'8,500.00', estado:'Bueno', resp:'Carlos Choque', fecha:'15/03/2022', cat:'Equipo Tecnológico' },
  { id:'ACT-002', desc:'Vehículo Toyota HiLux 4x4', cod:'GAMEA/TRS/2021/005', ubi:'Parque Automotor', valor:'125,000.00', estado:'Bueno', resp:'Jef. Transporte', fecha:'20/08/2021', cat:'Vehículo' },
  { id:'ACT-003', desc:'Motoniveladora Caterpillar 140M3', cod:'GAMEA/OPU/2019/001', ubi:'Almacén Central Obras', valor:'450,000.00', estado:'Regular', resp:'Dir. Obras Públicas', fecha:'10/01/2019', cat:'Maquinaria Pesada' },
  { id:'ACT-004', desc:'Escritorio Ejecutivo Nogal', cod:'GAMEA/MOB/2023/012', ubi:'Despacho Alcaldía', valor:'2,800.00', estado:'Excelente', resp:'Sec. Alcaldía', fecha:'01/05/2023', cat:'Mobiliario' },
  { id:'ACT-005', desc:'Proyector Epson EB-U05 WUXGA', cod:'GAMEA/TI/2022/015', ubi:'Sala Reuniones A', valor:'5,600.00', estado:'Bueno', resp:'Administración', fecha:'30/11/2022', cat:'Equipo Tecnológico' },
  { id:'ACT-006', desc:'Excavadora Komatsu PC200LC-8', cod:'GAMEA/OPU/2020/003', ubi:'Zona Norte – Pavimento', valor:'380,000.00', estado:'Regular', resp:'Dir. Obras Públicas', fecha:'15/06/2020', cat:'Maquinaria Pesada' },
];

export const MOCK_PROYECTOS = [
  { id:'PRY-001', nombre:'Pavimentación Calle 14 Zona Norte', sector:'Infraestructura Vial', presupuesto:'2,500,000', avFis:65, avFin:60, estado:'Ejecución', inicio:'15/01/2024', fin:'31/12/2024' },
  { id:'PRY-002', nombre:'Sistema Agua Potable Zona Sur', sector:'Servicios Básicos', presupuesto:'1,800,000', avFis:30, avFin:25, estado:'Ejecución', inicio:'01/03/2024', fin:'28/02/2025' },
  { id:'PRY-003', nombre:'Mercado Municipal 23 de Marzo', sector:'Desarrollo Económico', presupuesto:'3,200,000', avFis:10, avFin:8, estado:'Inicio', inicio:'15/04/2024', fin:'30/06/2025' },
  { id:'PRY-004', nombre:'Refacción Unidad Educativa 16 de Julio', sector:'Educación', presupuesto:'450,000', avFis:90, avFin:88, estado:'Por Cerrar', inicio:'10/01/2024', fin:'30/08/2024' },
  { id:'PRY-005', nombre:'Mantenimiento Parques y Plazas', sector:'Medio Ambiente', presupuesto:'280,000', avFis:100, avFin:97, estado:'Finalizado', inicio:'02/01/2024', fin:'30/04/2024' },
];

export const MOCK_TESORERIA = [
  { id:1, tipo:'Ingreso', desc:'Coparticipación Tributaria Municipal', monto:'1,245,680.00', fuente:'TGN', ref:'TGN-2024-0612', fecha:'02/06/2024', estado:'Acreditado' },
  { id:2, tipo:'Egreso',  desc:'Pago Planilla Personal Ítem', monto:'856,340.00', fuente:'Interno', ref:'ORD-2024-0145', fecha:'05/06/2024', estado:'Pagado' },
  { id:3, tipo:'Ingreso', desc:'Transferencia Inversión Pública', monto:'580,000.00', fuente:'TGN', ref:'TGN-2024-0628', fecha:'08/06/2024', estado:'Acreditado' },
  { id:4, tipo:'Egreso',  desc:'Contratación Materiales Construcción', monto:'124,500.00', fuente:'Interno', ref:'ORD-2024-0162', fecha:'12/06/2024', estado:'Pagado' },
  { id:5, tipo:'Ingreso', desc:'IDH Municipal Junio 2024', monto:'342,150.00', fuente:'IDH', ref:'TGN-2024-0641', fecha:'15/06/2024', estado:'Pendiente' },
];

export const MOCK_LOGS = [
  { id:1, user:'admin@gamea.bo', nombre:'Carlos Mamani', accion:'Inició sesión en el sistema', modulo:'Autenticación', fecha:'15/06/2024 08:03:22', ip:'192.168.1.10', tipo:'info' },
  { id:2, user:'rrhh@gamea.bo', nombre:'María Quispe', accion:'Registró asistencia del día', modulo:'Adm. Personal', fecha:'15/06/2024 08:35:15', ip:'192.168.1.25', tipo:'success' },
  { id:3, user:'admin@gamea.bo', nombre:'Carlos Mamani', accion:'Modificó datos de Pedro Flores López', modulo:'Super Usuario', fecha:'15/06/2024 09:15:44', ip:'192.168.1.10', tipo:'warning' },
  { id:4, user:'activos@gamea.bo', nombre:'Pedro Flores', accion:'Registró activo ACT-006 en BSIAF', modulo:'Activos Fijos', fecha:'15/06/2024 10:02:11', ip:'192.168.1.30', tipo:'success' },
  { id:5, user:'admin@gamea.bo', nombre:'Carlos Mamani', accion:'Modificó permisos de planif@gamea.bo', modulo:'Super Usuario', fecha:'15/06/2024 14:20:05', ip:'192.168.1.10', tipo:'warning' },
  { id:6, user:'activos@gamea.bo', nombre:'Pedro Flores', accion:'Cerró sesión', modulo:'Autenticación', fecha:'15/06/2024 16:58:00', ip:'192.168.1.30', tipo:'info' },
  { id:7, user:'admin@gamea.bo', nombre:'Carlos Mamani', accion:'Inhabilitó cuenta de Ana Quispe Mamani', modulo:'Super Usuario', fecha:'16/06/2024 09:05:12', ip:'192.168.1.10', tipo:'danger' },
];

export const MOCK_CHART_ASIST = [
  { mes:'Ene', presentes:142, tardanzas:12, ausentes:8 },
  { mes:'Feb', presentes:138, tardanzas:9,  ausentes:12 },
  { mes:'Mar', presentes:145, tardanzas:11, ausentes:5 },
  { mes:'Abr', presentes:140, tardanzas:8,  ausentes:10 },
  { mes:'May', presentes:148, tardanzas:7,  ausentes:4 },
  { mes:'Jun', presentes:143, tardanzas:6,  ausentes:9 },
];

export const MOCK_CHART_PIE = [
  { name:'Equipo Tecnológico', value:35, color:'#1B3A6B' },
  { name:'Vehículos/Maq.',    value:28, color:'#C8952A' },
  { name:'Mobiliario',        value:22, color:'#10b981' },
  { name:'Equipamiento',      value:15, color:'#8b5cf6' },
];

export const MOCK_CHART_AVANCE = [
  { proj:'Pavimento',  fisico:65,  financiero:60 },
  { proj:'Agua Pot.',  fisico:30,  financiero:25 },
  { proj:'Mercado',    fisico:10,  financiero:8  },
  { proj:'Escuela',    fisico:90,  financiero:88 },
  { proj:'Parques',    fisico:100, financiero:97 },
];

export const MOCK_USUARIOS = [
  { id:1, email:'admin@gamea.bo', password:'Admin123', nombre:'Carlos Mamani Choque', cargo:'Super Administrador', role:'superuser', avatar:'CM', active:true, creado:'15/01/2023' },
  { id:2, email:'rrhh@gamea.bo',  password:'Rrhh123',  nombre:'María Elena Quispe',   cargo:'Jefa de RRHH',        role:'rrhh',      avatar:'MQ', active:true, creado:'20/03/2023' },
  { id:3, email:'activos@gamea.bo',password:'Activos123',nombre:'Pedro Flores López', cargo:'Encargado Activos',   role:'activos',   avatar:'PF', active:true, creado:'10/05/2023' },
  { id:4, email:'planif@gamea.bo', password:'Planif123', nombre:'Ana Quispe Mamani',   cargo:'Planificadora',       role:'planificacion',avatar:'AQ',active:false,creado:'01/07/2023' },
];

export const MOCK_PERMS = {
  2: { personal:true,  activos:false, planificacion:false, hojarutas:false },
  3: { personal:false, activos:true,  planificacion:false, hojarutas:false },
  4: { personal:false, activos:false, planificacion:true,  hojarutas:true  },
};
