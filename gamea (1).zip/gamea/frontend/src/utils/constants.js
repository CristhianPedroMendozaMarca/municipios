export const APP_NAME   = 'GAMEA';
export const APP_FULL   = 'Gobierno Autónomo Municipal de El Alto';
export const APP_SLOGAN = 'Sistema Municipal Integrado';

export const ROLES = {
  SUPERUSER:    'superuser',
  RRHH:         'rrhh',
  ACTIVOS:      'activos',
  PLANIFICACION:'planificacion',
  FINANZAS:     'finanzas',
};

export const TIPO_CONTRATO   = ['Ítem','Eventual','Consultor'];
export const ESTADO_PERSONAL = ['Activo','Baja','Licencia','Suspendido'];
export const ESTADO_ASIST    = ['Presente','Tardanza','Ausente','Permiso','Licencia','Feriado'];
export const ESTADO_ACTIVO   = ['Excelente','Bueno','Regular','Malo','Dado de Baja'];
export const ESTADO_PROYECTO = ['Planificado','Inicio','Ejecución','Por Cerrar','Finalizado','Suspendido'];
export const TIPO_TRANSACC   = ['Ingreso','Egreso'];
export const ESTADO_TRANSACC = ['Pendiente','Acreditado','Pagado','Anulado'];
export const CAT_ACTIVOS     = ['Equipo Tecnológico','Vehículo','Maquinaria Pesada','Mobiliario','Equipamiento'];

export const MODULES = [
  { id:'personal',     label:'Adm. Personal',  icon:'bi-people-fill' },
  { id:'activos',      label:'Activos Fijos',   icon:'bi-box-seam-fill' },
  { id:'planificacion',label:'Planificación',   icon:'bi-clipboard-data-fill' },
  { id:'hojarutas',    label:'Hojas de Ruta',   icon:'bi-map-fill' },
];

export const COLORES_CHART = {
  primary:  '#1B3A6B',
  gold:     '#C8952A',
  success:  '#10b981',
  purple:   '#8b5cf6',
  danger:   '#ef4444',
  info:     '#3b82f6',
};
