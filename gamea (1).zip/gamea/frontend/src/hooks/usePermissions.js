import { useAuth } from './useAuth';
export function usePermissions() {
  const { user, getPerms } = useAuth();
  if (!user) return { canAccess: () => false, perms: {}, isSuperUser: false };
  const isSuperUser = user.role === 'superuser';
  const perms = isSuperUser
    ? { personal:true, activos:true, planificacion:true, hojarutas:true }
    : getPerms(user.id);
  const canAccess = (mod) => isSuperUser || !!perms[mod];
  return { canAccess, perms, isSuperUser };
}
