import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { MOCK_USUARIOS, MOCK_PERMS } from '../utils/mockData';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]           = useState(null);
  const [loading, setLoading]     = useState(true);
  const [usersDb, setUsersDb]     = useState(MOCK_USUARIOS);
  const [permsDb, setPermsDb]     = useState(MOCK_PERMS);

  // Restaurar sesión al cargar
  useEffect(() => {
    const saved = localStorage.getItem('gamea_user');
    if (saved) {
      try { setUser(JSON.parse(saved)); } catch { localStorage.clear(); }
    }
    setLoading(false);
  }, []);

  const login = useCallback(async (email, password) => {
    // Mock login — reemplazar por llamada a API cuando el backend esté listo:
    // const res = await authApi.login({ email, password });
    // const { token, user } = res.data;
    // localStorage.setItem('gamea_token', token);
    const u = usersDb.find(x => x.email === email && x.password === password);
    if (!u) throw new Error('Credenciales incorrectas');
    if (!u.active) throw new Error('Usuario inhabilitado. Contacte al administrador.');
    const userData = { id:u.id, nombre:u.nombre, email:u.email, cargo:u.cargo, role:u.role, avatar:u.avatar };
    localStorage.setItem('gamea_user', JSON.stringify(userData));
    setUser(userData);
    return userData;
  }, [usersDb]);

  const logout = useCallback(() => {
    localStorage.removeItem('gamea_token');
    localStorage.removeItem('gamea_user');
    setUser(null);
  }, []);

  const getPerms = useCallback((userId) => {
    if (!userId) return {};
    return permsDb[userId] || {};
  }, [permsDb]);

  const updatePerms = useCallback((userId, perms) => {
    setPermsDb(p => ({ ...p, [userId]: perms }));
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, usersDb, setUsersDb, permsDb, getPerms, updatePerms }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuthContext = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuthContext debe usarse dentro de AuthProvider');
  return ctx;
};
