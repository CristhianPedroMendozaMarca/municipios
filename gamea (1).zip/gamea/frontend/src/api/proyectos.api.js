import api from './axios';

export const getProyectos      = (params)    => api.get('/proyectos', { params });
export const getProyectosStats = ()          => api.get('/proyectos/stats');
export const getProyectoById   = (id)        => api.get(`/proyectos/${id}`);
export const createProyecto    = (data)      => api.post('/proyectos', data);
export const updateProyecto    = (id,data)   => api.put(`/proyectos/${id}`, data);
export const deleteProyecto    = (id)        => api.delete(`/proyectos/${id}`);
export const updateAvance      = (id,data)   => api.put(`/proyectos/${id}/avance`, data);
export const getHistorialAvance= (id)        => api.get(`/proyectos/${id}/historial`);

export const getCertificados   = ()          => api.get('/proyectos/certificados/lista');
export const createCertificado = (data)      => api.post('/proyectos/certificados', data);

export const getHojasRuta      = ()          => api.get('/proyectos/hojarutas/lista');
export const createHojaRuta    = (data)      => api.post('/proyectos/hojarutas', data);
export const saveSeguimiento   = (data)      => api.post('/proyectos/hojarutas/seguimiento', data);
