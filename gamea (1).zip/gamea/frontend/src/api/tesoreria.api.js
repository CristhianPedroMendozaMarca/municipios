import api from './axios';

export const getTesoreria         = (params)  => api.get('/tesoreria', { params });
export const getTesoreriaStats    = ()        => api.get('/tesoreria/stats');
export const getTransaccionById   = (id)      => api.get(`/tesoreria/${id}`);
export const createTransaccion    = (data)    => api.post('/tesoreria', data);
export const updateEstado         = (id,data) => api.put(`/tesoreria/${id}/estado`, data);
export const anularTransaccion    = (id)      => api.delete(`/tesoreria/${id}`);

export const getContrataciones    = ()        => api.get('/tesoreria/contrataciones/lista');
export const createContratacion   = (data)    => api.post('/tesoreria/contrataciones', data);
export const updateContratacion   = (id,data) => api.put(`/tesoreria/contrataciones/${id}`, data);
