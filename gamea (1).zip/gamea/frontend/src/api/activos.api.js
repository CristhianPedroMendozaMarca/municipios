import api from './axios';

export const getActivos      = (params)  => api.get('/activos', { params });
export const getActivosStats = ()        => api.get('/activos/stats');
export const getActivoById   = (id)      => api.get(`/activos/${id}`);
export const createActivo    = (data)    => api.post('/activos', data);
export const updateActivo    = (id,data) => api.put(`/activos/${id}`, data);
export const deleteActivo    = (id)      => api.delete(`/activos/${id}`);

export const getMantenimiento  = (id)   => api.get(`/activos/${id}/mantenimiento`);
export const saveMantenimiento = (data) => api.post('/activos/mantenimiento', data);

export const getAlmacenes      = ()      => api.get('/activos/almacenes/lista');
export const createAlmacen     = (data)  => api.post('/activos/almacenes', data);
export const getInventario      = (id)   => api.get(`/activos/almacenes/${id}/inventario`);
export const saveInventario     = (data) => api.post('/activos/almacenes/inventario', data);
