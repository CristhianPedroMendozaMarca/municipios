import api from './axios';

export const getPersonal        = (params)  => api.get('/personal', { params });
export const getPersonalById    = (id)      => api.get(`/personal/${id}`);
export const createPersonal     = (data)    => api.post('/personal', data);
export const updatePersonal     = (id,data) => api.put(`/personal/${id}`, data);
export const deletePersonal     = (id)      => api.delete(`/personal/${id}`);

export const getAsistenciaHoy      = (fecha)  => api.get('/personal/asistencia/hoy', { params:{fecha} });
export const getAsistenciaHistorial = (params) => api.get('/personal/asistencia/historial', { params });
export const getAsistenciaResumen   = ()       => api.get('/personal/asistencia/resumen');
export const saveAsistencia         = (data)   => api.post('/personal/asistencia', data);

export const getDesempeno  = (params)  => api.get('/personal/desempeno/lista', { params });
export const saveDesempeno = (data)    => api.post('/personal/desempeno', data);

export const getPermisos         = (id)     => api.get(`/personal/${id}/permisos`);
export const savePermiso         = (data)   => api.post('/personal/permisos', data);
export const updatePermisoEstado = (id,data)=> api.put(`/personal/permisos/${id}/estado`, data);
