import api from './axios';

export const getUsuarios    = ()          => api.get('/admin/usuarios');
export const getUsuarioById = (id)        => api.get(`/admin/usuarios/${id}`);
export const createUsuario  = (data)      => api.post('/admin/usuarios', data);
export const updateUsuario  = (id,data)   => api.put(`/admin/usuarios/${id}`, data);
export const deleteUsuario  = (id)        => api.delete(`/admin/usuarios/${id}`);
export const toggleUsuario  = (id)        => api.patch(`/admin/usuarios/${id}/toggle`);
export const resetPassword  = (id,data)   => api.patch(`/admin/usuarios/${id}/password`, data);

export const getPermisos    = ()          => api.get('/admin/permisos');
export const updatePermisos = (uid,data)  => api.put(`/admin/permisos/${uid}`, data);

export const getRoles       = ()          => api.get('/admin/roles');

export const getLogs        = (params)    => api.get('/admin/logs', { params });
export const getModulosLog  = ()          => api.get('/admin/logs/modulos');
