import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import Sidebar from './Sidebar';
import Topbar from './Topbar';

export default function MainLayout() {
  const { user, loading } = useAuth();
  if (loading) return <div className="d-flex justify-content-center align-items-center" style={{ height:'100vh' }}>Cargando...</div>;
  if (!user)   return <Navigate to="/login" replace />;
  return (
    <div style={{ display:'flex', minHeight:'100vh' }}>
      <Sidebar/>
      <Topbar/>
      <main className="g-main g-fade-in">
        <Outlet/>
      </main>
    </div>
  );
}
