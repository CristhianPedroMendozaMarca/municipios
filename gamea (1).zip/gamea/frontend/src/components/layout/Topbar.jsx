import { Bell } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import Avatar from '../common/Avatar';

const LABELS = {
  '/app/dashboard':'Dashboard General',
  '/app/personal/expediente':'Expediente Digital',
  '/app/personal/asistencia':'Control de Asistencia',
  '/app/personal/desempeno':'Evaluación de Desempeño',
  '/app/personal/kpis':'KPIs de Personal',
  '/app/activos/bsiaf':'BSIAF — Activos Fijos',
  '/app/activos/almacenes':'Control de Almacenes',
  '/app/planificacion/poa':'Plan Operativo Anual',
  '/app/planificacion/seguimiento':'Seguimiento Físico',
  '/app/planificacion/certificados':'Certificados de Cumplimiento',
  '/app/hojarutas/proyectos':'Programas y Proyectos',
  '/app/hojarutas/seguimiento':'Seguimiento — Hojas de Ruta',
  '/app/hojarutas/contabilidad':'Contabilidad y Tesorería',
  '/app/superuser/usuarios':'Gestión de Usuarios',
  '/app/superuser/permisos':'Permisos de Acceso',
  '/app/superuser/logs':'Logs del Sistema',
};

export default function Topbar() {
  const { user } = useAuth();
  const { pathname } = useLocation();
  const label = LABELS[pathname] || 'GAMEA';

  return (
    <div className="g-topbar">
      <h5 style={{ margin:0, fontFamily:'Lora,serif', fontSize:17, fontWeight:600, color:'#1a1a2e' }}>{label}</h5>
      <div className="d-flex align-items-center gap-3">
        <div style={{ position:'relative', cursor:'pointer' }}>
          <Bell size={19} color="#6b7280"/>
          <div style={{ position:'absolute', top:-3, right:-3, width:8, height:8, background:'#ef4444', borderRadius:'50%', border:'2px solid white' }}/>
        </div>
        <div className="d-flex align-items-center gap-2" style={{ padding:'5px 10px 5px 5px', background:'#F0F2F5', borderRadius:100 }}>
          <Avatar initials={user?.avatar||'?'} size={28}/>
          <div>
            <div style={{ fontSize:12.5, fontWeight:600, color:'#1a1a2e', fontFamily:'Nunito,sans-serif', lineHeight:1.2 }}>
              {user?.nombre?.split(' ').slice(0,2).join(' ')}
            </div>
            <div style={{ fontSize:10.5, color:'#6b7280', fontFamily:'Nunito,sans-serif' }}>
              {user?.role==='superuser'?'Super Administrador':user?.cargo}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
