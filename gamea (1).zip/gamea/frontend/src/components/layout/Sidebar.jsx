import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { BarChart3, Users, Package, ClipboardList, Route, Shield, ChevronRight, LogOut } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { usePermissions } from '../../hooks/usePermissions';
import Avatar from '../common/Avatar';
import { getInitials } from '../../utils/helpers';

const NAV = [
  { key:'personal',     label:'Adm. de Personal',  icon:<Users size={15}/>,
    subs:[['expediente','Expediente Digital'],['asistencia','Control Asistencia'],['desempeno','Desempeño'],['kpis','KPIs / Dashboard']] },
  { key:'activos',      label:'Activos Fijos',       icon:<Package size={15}/>,
    subs:[['bsiaf','BSIAF'],['almacenes','Control Almacenes']] },
  { key:'planificacion',label:'Planificación',        icon:<ClipboardList size={15}/>,
    subs:[['poa','Plan Operativo Anual'],['seguimiento','Seguimiento Físico'],['certificados','Certificados']] },
  { key:'hojarutas',    label:'Hojas de Ruta',        icon:<Route size={15}/>,
    subs:[['proyectos','Prog. y Proyectos'],['seguimiento','Seguimiento'],['contabilidad','Contabilidad/Tesorería']] },
];

export default function Sidebar() {
  const { user, logout } = useAuth();
  const { canAccess, isSuperUser } = usePermissions();
  const navigate  = useNavigate();
  const location  = useLocation();
  const [open, setOpen] = useState({});
  const toggle = k => setOpen(p => ({ ...p, [k]:!p[k] }));
  const go     = (path) => navigate(path);
  const active = (path) => location.pathname.startsWith(path);

  return (
    <div className="g-sidebar">
      {/* Brand */}
      <div className="g-sb-brand" style={{ cursor:'pointer' }} onClick={() => go('/app/dashboard')}>
        <div className="g-sb-logo">G</div>
        <div>
          <div style={{ fontSize:13, fontWeight:700, color:'white', fontFamily:'Lora,serif' }}>GAMEA</div>
          <div style={{ fontSize:9.5, color:'rgba(200,149,42,.8)', letterSpacing:'0.7px', textTransform:'uppercase', fontFamily:'Nunito,sans-serif' }}>Sistema Municipal</div>
        </div>
      </div>

      {/* Nav */}
      <div className="g-sb-nav">
        <span className="g-sb-label">Navegación</span>
        <button className={`g-nav-btn ${active('/app/dashboard')?'active':''}`} onClick={() => go('/app/dashboard')}>
          <BarChart3 size={15}/><span>Dashboard</span>
        </button>

        {NAV.filter(s => canAccess(s.key)).map(s => (
          <div key={s.key}>
            <button className={`g-nav-btn ${active(`/app/${s.key}`)?'active':''}`}
              onClick={() => toggle(s.key)}
              style={{ justifyContent:'space-between' }}>
              <span className="d-flex align-items-center gap-2">{s.icon}{s.label}</span>
              <ChevronRight size={13} style={{ transition:'transform .2s', transform:open[s.key]?'rotate(90deg)':'none' }}/>
            </button>
            {open[s.key] && s.subs.map(([sid, slabel]) => (
              <button key={sid}
                className={`g-nav-sub ${location.pathname===`/app/${s.key}/${sid}`?'active':''}`}
                onClick={() => go(`/app/${s.key}/${sid}`)}>
                <span style={{ width:4, height:4, borderRadius:'50%', background:'currentColor', flexShrink:0 }}/>
                {slabel}
              </button>
            ))}
          </div>
        ))}

        {isSuperUser && (
          <>
            <span className="g-sb-label" style={{ marginTop:12 }}>Administración</span>
            <button className={`g-nav-btn ${active('/app/superuser')?'active':''}`}
              onClick={() => toggle('su')} style={{ justifyContent:'space-between' }}>
              <span className="d-flex align-items-center gap-2"><Shield size={15}/>Super Usuario</span>
              <ChevronRight size={13} style={{ transition:'transform .2s', transform:open.su?'rotate(90deg)':'none' }}/>
            </button>
            {open.su && [['usuarios','Gestión Usuarios'],['permisos','Permisos de Acceso'],['logs','Logs del Sistema']].map(([sid,slabel]) => (
              <button key={sid}
                className={`g-nav-sub ${location.pathname===`/app/superuser/${sid}`?'active':''}`}
                onClick={() => go(`/app/superuser/${sid}`)}>
                <span style={{ width:4, height:4, borderRadius:'50%', background:'currentColor', flexShrink:0 }}/>{slabel}
              </button>
            ))}
          </>
        )}
      </div>

      {/* Footer */}
      <div className="g-sb-footer">
        <div className="g-user-chip">
          <Avatar initials={user?.avatar || '?'} size={30}/>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:12.5, color:'white', fontWeight:600, fontFamily:'Nunito,sans-serif', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
              {user?.nombre?.split(' ').slice(0,2).join(' ')}
            </div>
            <div style={{ fontSize:10.5, color:'rgba(255,255,255,.45)', fontFamily:'Nunito,sans-serif' }}>{user?.cargo}</div>
          </div>
        </div>
        <button className="g-nav-btn" onClick={logout} style={{ color:'rgba(239,68,68,.75)' }}>
          <LogOut size={14}/>Cerrar Sesión
        </button>
      </div>
    </div>
  );
}
