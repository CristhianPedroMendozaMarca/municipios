import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogIn } from 'lucide-react';
export default function LandingNavbar() {
  const [scrolled, setScrolled] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', fn);
    return () => window.removeEventListener('scroll', fn);
  }, []);
  const sc = id => document.getElementById(id)?.scrollIntoView({ behavior:'smooth' });
  return (
    <nav className="g-nav-landing" style={{ background: scrolled?'rgba(10,23,50,.99)':'rgba(10,23,50,.88)' }}>
      <button onClick={() => sc('inicio')} style={{ background:'none', border:'none', display:'flex', alignItems:'center', gap:10, cursor:'pointer' }}>
        <div style={{ width:38, height:38, background:'linear-gradient(135deg,#C8952A,#e8b84b)', borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'Lora,serif', fontWeight:700, fontSize:16, color:'#1B3A6B' }}>G</div>
        <div>
          <div style={{ fontSize:13, fontWeight:700, color:'white', fontFamily:'Lora,serif' }}>GAMEA</div>
          <div style={{ fontSize:9.5, color:'rgba(200,149,42,.85)', letterSpacing:'0.7px', textTransform:'uppercase', fontFamily:'Nunito,sans-serif' }}>Sistema Municipal</div>
        </div>
      </button>
      <div className="d-flex align-items-center gap-1">
        {[['inicio','Inicio'],['quienes-somos','Quiénes Somos'],['mision','Misión'],['vision','Visión']].map(([id,label])=>(
          <button key={id} onClick={()=>sc(id)} style={{ background:'none', border:'none', color:'rgba(255,255,255,.75)', fontFamily:'Nunito,sans-serif', fontSize:14, fontWeight:500, padding:'7px 13px', borderRadius:7, cursor:'pointer' }}
            onMouseEnter={e=>e.target.style.background='rgba(255,255,255,.09)'} onMouseLeave={e=>e.target.style.background='none'}>
            {label}
          </button>
        ))}
        <button onClick={()=>navigate('/login')}
          style={{ background:'linear-gradient(135deg,#C8952A,#e8b84b)', border:'none', color:'#0d2247', fontFamily:'Nunito,sans-serif', fontSize:14, fontWeight:700, padding:'8px 18px', borderRadius:8, cursor:'pointer', display:'flex', alignItems:'center', gap:6 }}>
          <LogIn size={15}/>Ingresar
        </button>
      </div>
    </nav>
  );
}
