export default function Footer() {
  return (
    <footer className="g-footer">
      <div style={{ maxWidth:1180, margin:'0 auto', padding:'0 32px', textAlign:'center' }}>
        <div className="d-flex align-items-center justify-content-center gap-2 mb-3">
          <div style={{ width:34, height:34, background:'linear-gradient(135deg,#C8952A,#e8b84b)', borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'Lora,serif', fontWeight:700, fontSize:14, color:'#1B3A6B' }}>G</div>
          <span style={{ color:'white', fontFamily:'Lora,serif', fontSize:17, fontWeight:600 }}>GAMEA — Sistema Municipal Integrado</span>
        </div>
        <p style={{ color:'rgba(255,255,255,.38)', fontSize:12.5, fontFamily:'Nunito,sans-serif', margin:0 }}>
          © 2024 Gobierno Autónomo Municipal de El Alto · Ley SAFCO N° 1178 · Todos los derechos reservados.
        </p>
      </div>
    </footer>
  );
}
