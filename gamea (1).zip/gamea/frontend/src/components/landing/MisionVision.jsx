import { Target, Eye } from 'lucide-react';
export default function MisionVision() {
  const items = [
    { id:'mision', icon:<Target size={26} color="#C8952A"/>, bg:'rgba(200,149,42,.15)', bar:'linear-gradient(90deg,#C8952A,#e8b84b)', title:'Misión', text:'Administrar los recursos públicos del municipio de El Alto con transparencia, eficiencia y equidad, garantizando la prestación de servicios de calidad mediante tecnologías modernas y el cumplimiento estricto de la Ley SAFCO N° 1178 y el Estatuto del Funcionario Público.' },
    { id:'vision', icon:<Eye size={26} color="#93c5fd"/>, bg:'rgba(27,58,107,.4)', bar:'linear-gradient(90deg,#1B3A6B,#2d5296)', title:'Visión', text:'Ser el municipio referente en transformación digital de Bolivia al año 2030, con un gobierno abierto que integre a la ciudadanía en la toma de decisiones, consolidando un modelo de gestión pública eficiente, innovador y orientado al desarrollo sostenible de El Alto.' },
  ];
  return (
    <section id="mision" className="g-section g-section-dark">
      <div style={{ maxWidth:1180, margin:'0 auto', padding:'0 32px' }}>
        <div style={{ textAlign:'center', marginBottom:52 }}>
          <div style={{ display:'inline-block', padding:'4px 14px', background:'rgba(200,149,42,.12)', border:'1px solid rgba(200,149,42,.3)', borderRadius:100, color:'#C8952A', fontSize:11, fontWeight:700, letterSpacing:'1.4px', textTransform:'uppercase', marginBottom:14, fontFamily:'Nunito,sans-serif' }}>Orientación Estratégica</div>
          <h2 style={{ fontSize:'clamp(1.9rem,3.5vw,2.8rem)', fontWeight:700, color:'white' }}>Misión & Visión</h2>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:28 }}>
          {items.map(({ id,icon,bg,bar,title,text })=>(
            <div key={id} id={id} style={{ background:'rgba(255,255,255,.04)', border:'1px solid rgba(255,255,255,.08)', borderRadius:20, padding:38, position:'relative', overflow:'hidden' }}>
              <div style={{ position:'absolute', top:0, left:0, right:0, height:4, background:bar }}/>
              <div style={{ width:52, height:52, background:bg, borderRadius:13, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:22 }}>{icon}</div>
              <h3 style={{ fontSize:22, color:'white', marginBottom:14 }}>{title}</h3>
              <p style={{ color:'rgba(255,255,255,.7)', lineHeight:1.8, fontFamily:'Nunito,sans-serif', fontSize:14.5, margin:0 }}>{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
