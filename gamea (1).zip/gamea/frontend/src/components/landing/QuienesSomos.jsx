import { Users, Package, Target, Route } from 'lucide-react';
export default function QuienesSomos() {
  const features = [
    { icon:<Users size={22}/>, title:'Gestión de Personal', desc:'Expedientes, asistencia biométrica y evaluación de desempeño', bg:'#dbeafe', ic:'#1B3A6B' },
    { icon:<Package size={22}/>, title:'Activos Fijos', desc:'Inventario BSIAF y control de almacenes municipales', bg:'#d1fae5', ic:'#065f46' },
    { icon:<Target size={22}/>, title:'Planificación', desc:'POA, seguimiento físico y certificados de cumplimiento', bg:'#fef3c7', ic:'#92400e' },
    { icon:<Route size={22}/>, title:'Hojas de Ruta', desc:'Proyectos, contabilidad y tesorería municipal', bg:'#ede9fe', ic:'#5b21b6' },
  ];
  return (
    <section id="quienes-somos" className="g-section" style={{ background:'white' }}>
      <div style={{ maxWidth:1180, margin:'0 auto', padding:'0 32px' }}>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:56, alignItems:'center' }}>
          <div>
            <div style={{ display:'inline-block', padding:'4px 14px', background:'rgba(200,149,42,.12)', border:'1px solid rgba(200,149,42,.3)', borderRadius:100, color:'#C8952A', fontSize:11, fontWeight:700, letterSpacing:'1.4px', textTransform:'uppercase', marginBottom:14, fontFamily:'Nunito,sans-serif' }}>Quiénes Somos</div>
            <h2 style={{ fontSize:'clamp(1.8rem,3vw,2.6rem)', fontWeight:700, lineHeight:1.2, marginBottom:18, color:'#0a1732' }}>El Gobierno Autónomo<br/>Municipal de El Alto</h2>
            <p style={{ color:'#4b5563', lineHeight:1.8, marginBottom:16, fontFamily:'Nunito,sans-serif', fontSize:15 }}>
              El GAMEA administra y gestiona los servicios públicos del municipio de El Alto, con más de 1 millón de habitantes. Operamos bajo el Estatuto del Funcionario Público y la Ley SAFCO N° 1178.
            </p>
            <p style={{ color:'#4b5563', lineHeight:1.8, fontFamily:'Nunito,sans-serif', fontSize:15, margin:0 }}>
              Esta plataforma es el resultado de un proceso de modernización tecnológica orientado a un <strong>Gobierno Abierto y Transparente</strong>.
            </p>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 }}>
            {features.map(({ icon,title,desc,bg,ic })=>(
              <div key={title} style={{ background:'white', borderRadius:16, padding:24, border:'1px solid #e5e7eb', transition:'all .3s' }}
                onMouseEnter={e=>e.currentTarget.style.transform='translateY(-3px)'}
                onMouseLeave={e=>e.currentTarget.style.transform='none'}>
                <div style={{ width:48, height:48, borderRadius:12, background:bg, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:16 }}><span style={{ color:ic }}>{icon}</span></div>
                <h6 style={{ fontSize:14, fontWeight:700, marginBottom:6, color:'#1a1a2e' }}>{title}</h6>
                <p style={{ fontSize:12.5, color:'#6b7280', lineHeight:1.5, margin:0, fontFamily:'Nunito,sans-serif' }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
