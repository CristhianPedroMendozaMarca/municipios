import { useNavigate } from 'react-router-dom';
import { LogIn, BookOpen, Shield } from 'lucide-react';
export default function Hero() {
  const navigate = useNavigate();
  const sc = id => document.getElementById(id)?.scrollIntoView({ behavior:'smooth' });
  return (
    <section id="inicio" className="g-hero">
      <div style={{ position:'absolute', inset:0, backgroundImage:'linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px)', backgroundSize:'48px 48px' }}/>
      <div style={{ position:'absolute', inset:0, background:'radial-gradient(circle at 18% 80%,rgba(200,149,42,.12) 0%,transparent 50%),radial-gradient(circle at 80% 20%,rgba(45,82,150,.2) 0%,transparent 50%)' }}/>
      <div style={{ position:'relative', zIndex:1, maxWidth:1180, margin:'0 auto', padding:'70px 32px', width:'100%' }}>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:56, alignItems:'center' }}>
          <div>
            <div style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'5px 14px', background:'rgba(200,149,42,.15)', border:'1px solid rgba(200,149,42,.35)', borderRadius:100, color:'#e8b84b', fontSize:12, fontWeight:600, marginBottom:22, fontFamily:'Nunito,sans-serif' }}>
              <Shield size={13}/>Sistema Oficial GAMEA – Gestión Municipal Integrada
            </div>
            <h1 style={{ fontSize:'clamp(2.4rem,5vw,4rem)', fontWeight:700, color:'white', lineHeight:1.1, marginBottom:20 }}>
              Plataforma Digital<br/>para <span style={{ color:'#C8952A' }}>Gobiernos</span><br/>Autónomos
            </h1>
            <p style={{ fontSize:'1.05rem', color:'rgba(255,255,255,.68)', lineHeight:1.75, maxWidth:520, marginBottom:36, fontFamily:'Nunito,sans-serif' }}>
              Modernizamos la administración municipal con tecnología de vanguardia. Personal, activos, planificación y tesorería — en una sola plataforma alineada con la Ley SAFCO N° 1178.
            </p>
            <div className="d-flex gap-3 flex-wrap">
              <button onClick={()=>navigate('/login')} style={{ padding:'13px 30px', background:'linear-gradient(135deg,#C8952A,#e8b84b)', color:'#0d2247', fontWeight:700, fontSize:15, border:'none', borderRadius:10, cursor:'pointer', display:'inline-flex', alignItems:'center', gap:8, fontFamily:'Nunito,sans-serif' }}>
                <LogIn size={17}/>Acceder al Sistema
              </button>
              <button onClick={()=>sc('quienes-somos')} style={{ padding:'13px 30px', background:'transparent', color:'white', fontWeight:600, fontSize:15, border:'1.5px solid rgba(255,255,255,.28)', borderRadius:10, cursor:'pointer', display:'inline-flex', alignItems:'center', gap:8, fontFamily:'Nunito,sans-serif' }}>
                <BookOpen size={17}/>Conocer más
              </button>
            </div>
            <div style={{ display:'flex', gap:36, marginTop:48, paddingTop:36, borderTop:'1px solid rgba(255,255,255,.1)' }}>
              {[['4','Módulos'],['8+','Sub-módulos'],['24/7','Disponible'],['500+','Funcionarios']].map(([n,l])=>(
                <div key={l}>
                  <div style={{ fontSize:'1.8rem', fontWeight:700, color:'#C8952A', fontFamily:'Lora,serif', lineHeight:1 }}>{n}</div>
                  <div style={{ fontSize:12, color:'rgba(255,255,255,.55)', marginTop:4, fontFamily:'Nunito,sans-serif' }}>{l}</div>
                </div>
              ))}
            </div>
          </div>
          {/* Mockup dashboard */}
          <div style={{ background:'rgba(255,255,255,.05)', borderRadius:20, border:'1px solid rgba(255,255,255,.1)', padding:20, backdropFilter:'blur(10px)' }}>
            <div className="d-flex gap-2 mb-3">
              {['#ef4444','#f59e0b','#10b981'].map(c=><div key={c} style={{ width:10, height:10, borderRadius:'50%', background:c }}/>)}
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:14 }}>
              {[['Personal Activo','487','#3b82f6'],['Activos Reg.','1,243','#10b981'],['Proyectos','24','#C8952A'],['Presup. Ejec.','98.2%','#8b5cf6']].map(([l,v,c])=>(
                <div key={l} style={{ background:'rgba(255,255,255,.06)', borderRadius:10, padding:14, border:'1px solid rgba(255,255,255,.08)' }}>
                  <div style={{ fontSize:10, color:'rgba(255,255,255,.5)', marginBottom:5, fontFamily:'Nunito,sans-serif' }}>{l}</div>
                  <div style={{ fontSize:22, fontWeight:700, color:c, fontFamily:'Lora,serif' }}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{ background:'rgba(255,255,255,.04)', borderRadius:10, padding:14, border:'1px solid rgba(255,255,255,.08)' }}>
              <div style={{ fontSize:10, color:'rgba(255,255,255,.5)', marginBottom:8, fontFamily:'Nunito,sans-serif' }}>Asistencia mensual</div>
              <div style={{ display:'flex', gap:5, alignItems:'flex-end', height:48 }}>
                {[72,80,68,86,78,90,76,83,88,84,80,92].map((h,i)=>(
                  <div key={i} style={{ flex:1, height:`${h}%`, background:i===11?'#C8952A':'rgba(27,58,107,.75)', borderRadius:'3px 3px 0 0' }}/>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
