import { useEffect } from 'react';
import { X } from 'lucide-react';
export default function Modal({ show, onClose, title, children, size='md' }) {
  useEffect(() => {
    const fn = (e) => { if (e.key === 'Escape') onClose(); };
    if (show) document.addEventListener('keydown', fn);
    return () => document.removeEventListener('keydown', fn);
  }, [show, onClose]);
  if (!show) return null;
  const maxW = { sm:'380px', md:'520px', lg:'720px', xl:'960px' }[size] || '520px';
  return (
    <div className="g-modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="g-modal-box" style={{ maxWidth:maxW }}>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h5 style={{ margin:0, fontFamily:'Lora,serif', fontSize:18 }}>{title}</h5>
          <button className="btn-icon-gamea" onClick={onClose}><X size={16}/></button>
        </div>
        {children}
      </div>
    </div>
  );
}
