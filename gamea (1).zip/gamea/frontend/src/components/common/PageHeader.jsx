export default function PageHeader({ title, subtitle, actions }) {
  return (
    <div className="d-flex justify-content-between align-items-center mb-3" style={{ flexWrap:'wrap', gap:10 }}>
      <div>
        <h4 style={{ margin:0, fontFamily:'Lora,serif', color:'#1a1a2e' }}>{title}</h4>
        {subtitle && <p style={{ margin:'2px 0 0', fontSize:13, color:'#6b7280', fontFamily:'Nunito,sans-serif' }}>{subtitle}</p>}
      </div>
      {actions && <div className="d-flex gap-2">{actions}</div>}
    </div>
  );
}
