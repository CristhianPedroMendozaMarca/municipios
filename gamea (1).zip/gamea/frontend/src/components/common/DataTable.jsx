import { Search } from 'lucide-react';
export default function DataTable({ columns, data, search, onSearch, actions, footer }) {
  return (
    <div className="g-card">
      <div className="g-card-header">
        <h5 style={{ margin:0 }}>{columns.title}</h5>
        <div className="d-flex gap-2 align-items-center flex-wrap">
          {onSearch && (
            <div className="g-search-wrap">
              <Search size={14} className="icon"/>
              <input placeholder="Buscar..." value={search} onChange={e=>onSearch(e.target.value)} style={{ width:200 }}/>
            </div>
          )}
          {actions}
        </div>
      </div>
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead>
            <tr>{columns.cols.map((c,i)=><th key={i}>{c.label}</th>)}</tr>
          </thead>
          <tbody>
            {data.length===0
              ? <tr><td colSpan={columns.cols.length} className="text-center py-4" style={{ color:'#9ca3af', fontFamily:'Nunito,sans-serif' }}>Sin registros</td></tr>
              : data.map((row,ri)=>(
                  <tr key={ri}>
                    {columns.cols.map((c,ci)=>(
                      <td key={ci}>{typeof c.render==='function' ? c.render(row) : row[c.key]}</td>
                    ))}
                  </tr>
                ))
            }
          </tbody>
        </table>
      </div>
      {footer && <div style={{ padding:'10px 20px', borderTop:'1px solid #f3f4f6' }}>{footer}</div>}
    </div>
  );
}
