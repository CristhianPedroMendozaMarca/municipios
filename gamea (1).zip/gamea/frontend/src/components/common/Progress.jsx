import { progressColor } from '../../utils/helpers';
export default function Progress({ value=0, showLabel=true }) {
  const color = progressColor(value);
  return (
    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
      <div className="g-progress" style={{ flex:1 }}>
        <div className="g-progress-fill" style={{ width:`${Math.min(value,100)}%`, background:`linear-gradient(90deg,${color},${color}cc)` }} />
      </div>
      {showLabel && <span style={{ fontSize:12, fontWeight:600, color, minWidth:32, fontFamily:'Nunito,sans-serif' }}>{value}%</span>}
    </div>
  );
}
