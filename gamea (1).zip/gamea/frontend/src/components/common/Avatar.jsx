export default function Avatar({ initials='?', size=34, bg='linear-gradient(135deg,#1B3A6B,#2d5296)', color='white' }) {
  return (
    <div style={{ width:size, height:size, borderRadius:'50%', background:bg, color, display:'flex', alignItems:'center', justifyContent:'center', fontSize:size*0.32, fontWeight:700, fontFamily:'Nunito,sans-serif', flexShrink:0 }}>
      {initials}
    </div>
  );
}
