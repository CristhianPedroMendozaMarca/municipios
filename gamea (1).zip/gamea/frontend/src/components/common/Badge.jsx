import { badgeClass } from '../../utils/helpers';
export default function Badge({ estado }) {
  return <span className={badgeClass(estado)}>{estado}</span>;
}
