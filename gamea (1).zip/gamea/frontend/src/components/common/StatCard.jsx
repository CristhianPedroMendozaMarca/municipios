export default function StatCard({ label, value, sub, icon, bg, iconColor, trend, trendUp=true }) {
  return (
    <div className="g-stat-card">
      <div className="d-flex justify-content-between align-items-start mb-3">
        <div className="g-stat-icon" style={{ background:bg }}>
          <span style={{ color:iconColor }}>{icon}</span>
        </div>
        {trend && (
          <span style={{ fontSize:11.5, color:trendUp?'#10b981':'#ef4444', fontWeight:600, background:trendUp?'#d1fae5':'#fee2e2', padding:'2px 8px', borderRadius:100, fontFamily:'Nunito,sans-serif' }}>
            {trendUp?'↑':'↓'} {trend}
          </span>
        )}
      </div>
      <div style={{ fontSize:26, fontWeight:700, color:'#1a1a2e', fontFamily:'Lora,serif', lineHeight:1 }}>{value}</div>
      <div style={{ fontSize:13, fontWeight:600, color:'#374151', fontFamily:'Nunito,sans-serif', marginTop:4 }}>{label}</div>
      {sub && <div style={{ fontSize:11.5, color:'#9ca3af', fontFamily:'Nunito,sans-serif', marginTop:2 }}>{sub}</div>}
    </div>
  );
}
