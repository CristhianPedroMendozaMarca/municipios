import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';
import { usePermissions } from './hooks/usePermissions';

// Layouts
import MainLayout from './components/layout/MainLayout';

// Páginas públicas
import LandingPage from './pages/LandingPage';
import LoginPage   from './pages/auth/LoginPage';

// Dashboard
import DashboardPage from './pages/dashboard/DashboardPage';

// Personal
import PersonalPage    from './pages/personal/PersonalPage';
import ExpedienteTab   from './pages/personal/tabs/ExpedienteTab';
import AsistenciaTab   from './pages/personal/tabs/AsistenciaTab';
import DesempenoTab    from './pages/personal/tabs/DesempenoTab';
import KpisTab         from './pages/personal/tabs/KpisTab';

// Activos
import ActivosPage   from './pages/activos/ActivosPage';
import BsiafTab      from './pages/activos/tabs/BsiafTab';
import AlmacenesTab  from './pages/activos/tabs/AlmacenesTab';

// Planificación
import PlanificacionPage  from './pages/planificacion/PlanificacionPage';
import PoaTab             from './pages/planificacion/tabs/PoaTab';
import SeguimientoTab     from './pages/planificacion/tabs/SeguimientoTab';
import CertificadosTab    from './pages/planificacion/tabs/CertificadosTab';

// Hojas de Ruta
import HojasRutaPage      from './pages/hojarutas/HojasRutaPage';
import ProyectosTab       from './pages/hojarutas/tabs/ProyectosTab';
import SeguimientoHRTab   from './pages/hojarutas/tabs/SeguimientoHRTab';
import ContabilidadTab    from './pages/hojarutas/tabs/ContabilidadTab';

// Super Usuario
import SuperUserPage from './pages/superuser/SuperUserPage';
import UsuariosTab   from './pages/superuser/tabs/UsuariosTab';
import PermisosTab   from './pages/superuser/tabs/PermisosTab';
import LogsTab       from './pages/superuser/tabs/LogsTab';

/* ── Guard: redirige si no tiene permiso al módulo ── */
function ModuleGuard({ module, children }) {
  const { canAccess } = usePermissions();
  if (!canAccess(module)) return <Navigate to="/app/dashboard" replace />;
  return children;
}

/* ── Guard: sólo super usuario ── */
function SuperGuard({ children }) {
  const { isSuperUser } = usePermissions();
  if (!isSuperUser) return <Navigate to="/app/dashboard" replace />;
  return children;
}

export default function App() {
  const { loading } = useAuth();

  if (loading) {
    return (
      <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100vh', background:'#F0F2F5' }}>
        <div style={{ textAlign:'center' }}>
          <div style={{ width:48, height:48, background:'linear-gradient(135deg,#C8952A,#e8b84b)', borderRadius:12, display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 16px', fontFamily:'Lora,serif', fontWeight:700, fontSize:22, color:'#1B3A6B' }}>G</div>
          <div style={{ fontSize:14, color:'#6b7280', fontFamily:'Nunito,sans-serif' }}>Cargando GAMEA...</div>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      {/* ── Públicas ── */}
      <Route path="/"      element={<LandingPage />} />
      <Route path="/login" element={<LoginPage />} />

      {/* ── App protegida ── */}
      <Route path="/app" element={<MainLayout />}>
        {/* Redirect raíz → dashboard */}
        <Route index element={<Navigate to="dashboard" replace />} />

        {/* Dashboard */}
        <Route path="dashboard" element={<DashboardPage />} />

        {/* Administración de Personal */}
        <Route path="personal" element={<ModuleGuard module="personal"><PersonalPage /></ModuleGuard>}>
          <Route index                element={<Navigate to="expediente" replace />} />
          <Route path="expediente"    element={<ExpedienteTab />} />
          <Route path="asistencia"    element={<AsistenciaTab />} />
          <Route path="desempeno"     element={<DesempenoTab />} />
          <Route path="kpis"          element={<KpisTab />} />
        </Route>

        {/* Activos Fijos */}
        <Route path="activos" element={<ModuleGuard module="activos"><ActivosPage /></ModuleGuard>}>
          <Route index              element={<Navigate to="bsiaf" replace />} />
          <Route path="bsiaf"       element={<BsiafTab />} />
          <Route path="almacenes"   element={<AlmacenesTab />} />
        </Route>

        {/* Planificación */}
        <Route path="planificacion" element={<ModuleGuard module="planificacion"><PlanificacionPage /></ModuleGuard>}>
          <Route index                  element={<Navigate to="poa" replace />} />
          <Route path="poa"             element={<PoaTab />} />
          <Route path="seguimiento"     element={<SeguimientoTab />} />
          <Route path="certificados"    element={<CertificadosTab />} />
        </Route>

        {/* Hojas de Ruta */}
        <Route path="hojarutas" element={<ModuleGuard module="hojarutas"><HojasRutaPage /></ModuleGuard>}>
          <Route index                  element={<Navigate to="proyectos" replace />} />
          <Route path="proyectos"       element={<ProyectosTab />} />
          <Route path="seguimiento"     element={<SeguimientoHRTab />} />
          <Route path="contabilidad"    element={<ContabilidadTab />} />
        </Route>

        {/* Super Usuario */}
        <Route path="superuser" element={<SuperGuard><SuperUserPage /></SuperGuard>}>
          <Route index              element={<Navigate to="usuarios" replace />} />
          <Route path="usuarios"    element={<UsuariosTab />} />
          <Route path="permisos"    element={<PermisosTab />} />
          <Route path="logs"        element={<LogsTab />} />
        </Route>

        {/* Catch-all dentro de /app */}
        <Route path="*" element={<Navigate to="dashboard" replace />} />
      </Route>

      {/* Catch-all global */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
