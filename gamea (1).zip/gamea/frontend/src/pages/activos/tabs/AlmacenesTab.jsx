import { Plus } from 'lucide-react';
const MOCK_ALMACENES=[{ id:1,nombre:'Almacén Central TI',ubi:'Piso 3 – Edificio Central',resp:'Lic. Carlos Choque',items:45 },{ id:2,nombre:'Almacén Obras Públicas',ubi:'Zona Industrial',resp:'Dir. Obras Públicas',items:128 },{ id:3,nombre:'Bodega de Materiales',ubi:'Planta Baja Norte',resp:'Jef. Logística',items:73 }];
export default function AlmacenesTab() {
  return (
    <div style={{ padding:20 }}>
      <div className="d-flex justify-content-between align-items-center mb-3">
        <span style={{ fontSize:13.5, fontFamily:'Nunito,sans-serif', color:'#374151' }}>{MOCK_ALMACENES.length} almacenes registrados</span>
        <button className="btn-gold-gamea"><Plus size={14}/>Nuevo Almacén</button>
      </div>
      <div className="row g-3">
        {MOCK_ALMACENES.map(a=>(
          <div key={a.id} className="col-12 col-md-4">
            <div className="g-stat-card" style={{ cursor:'pointer' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 }}>
                <div style={{ width:42, height:42, background:'#dbeafe', borderRadius:10, display:'flex', alignItems:'center', justifyContent:'center', fontSize:20 }}>🏭</div>
                <span className="g-badge badge-success">Activo</span>
              </div>
              <div style={{ fontWeight:700, fontSize:15, color:'#1a1a2e', marginBottom:4, fontFamily:'Lora,serif' }}>{a.nombre}</div>
              <div style={{ fontSize:12.5, color:'#6b7280', marginBottom:2, fontFamily:'Nunito,sans-serif' }}>{a.ubi}</div>
              <div style={{ fontSize:12, color:'#9ca3af', fontFamily:'Nunito,sans-serif', marginBottom:12 }}>Resp: {a.resp}</div>
              <div style={{ display:'flex', justifyContent:'space-between', paddingTop:12, borderTop:'1px solid #f3f4f6' }}>
                <span style={{ fontSize:13, fontFamily:'Nunito,sans-serif', color:'#374151' }}><strong>{a.items}</strong> ítems</span>
                <button className="btn-primary-gamea" style={{ padding:'5px 12px', fontSize:12 }}>Ver inventario</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
