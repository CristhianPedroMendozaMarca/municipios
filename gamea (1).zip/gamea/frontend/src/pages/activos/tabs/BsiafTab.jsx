import { useState } from 'react';
import { Plus, Eye, Edit2, Search } from 'lucide-react';
import Badge  from '../../../components/common/Badge';
import Modal  from '../../../components/common/Modal';
import { MOCK_ACTIVOS } from '../../../utils/mockData';
export default function BsiafTab() {
  const [data,   setData]  = useState(MOCK_ACTIVOS);
  const [search, setSearch]= useState('');
  const [modal,  setModal] = useState(false);
  const [form,   setForm]  = useState({ desc:'', cod:'', cat:'Equipo Tecnológico', ubi:'', valor:'', estado:'Bueno', resp:'' });
  const filtered = data.filter(a=>a.desc.toLowerCase().includes(search.toLowerCase())||a.cod.toLowerCase().includes(search.toLowerCase()));
  const save = () => {
    setData(d=>[...d,{ ...form, id:`ACT-${String(d.length+1).padStart(3,'0')}`, fecha:new Date().toLocaleDateString('es-BO') }]);
    setModal(false);
  };
  return (
    <div>
      <div className="row g-3 p-3">
        {[['Total Activos','1,243','#1B3A6B'],['Valor Total (Bs)','12.8M','#065f46'],['Buen Estado','84%','#d97706'],['Por Dar de Baja','18','#991b1b']].map(([l,v,c])=>(
          <div key={l} className="col-6 col-md-3">
            <div className="g-stat-card">
              <div style={{ fontSize:22, fontWeight:700, color:c, fontFamily:'Lora,serif' }}>{v}</div>
              <div style={{ fontSize:12.5, color:'#374151', fontFamily:'Nunito,sans-serif', marginTop:3, fontWeight:600 }}>{l}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ padding:'0 20px 14px', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10 }}>
        <div className="g-search-wrap"><Search size={14} className="icon"/><input placeholder="Buscar activo..." value={search} onChange={e=>setSearch(e.target.value)}/></div>
        <button className="btn-gold-gamea" onClick={()=>setModal(true)}><Plus size={14}/>Registrar Activo</button>
      </div>
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead><tr><th>ID</th><th>Descripción</th><th>Código BSIAF</th><th>Categoría</th><th>Ubicación</th><th>Valor (Bs)</th><th>Estado</th><th>Responsable</th><th>Acc.</th></tr></thead>
          <tbody>
            {filtered.map(a=>(
              <tr key={a.id}>
                <td><code style={{ fontSize:12, color:'#6b7280' }}>{a.id}</code></td>
                <td style={{ fontWeight:600, maxWidth:200 }}>{a.desc}</td>
                <td><code style={{ fontSize:11.5, color:'#6b7280' }}>{a.cod}</code></td>
                <td style={{ fontSize:12.5 }}><span className="g-badge badge-info">{a.cat}</span></td>
                <td style={{ fontSize:12.5, color:'#6b7280' }}>{a.ubi}</td>
                <td style={{ fontWeight:600, color:'#1B3A6B' }}>{a.valor}</td>
                <td><Badge estado={a.estado}/></td>
                <td style={{ fontSize:12.5 }}>{a.resp}</td>
                <td><div className="d-flex gap-1"><button className="btn-icon-gamea view"><Eye size={12}/></button><button className="btn-icon-gamea edit"><Edit2 size={12}/></button></div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Modal show={modal} onClose={()=>setModal(false)} title="Registrar Nuevo Activo">
        <div className="row g-3">
          <div className="col-12"><label className="g-form-label">Descripción *</label><input className="g-form-control" value={form.desc} onChange={e=>setForm(f=>({...f,desc:e.target.value}))} placeholder="Ej: Computadora HP EliteDesk"/></div>
          <div className="col-6"><label className="g-form-label">Código BSIAF *</label><input className="g-form-control" value={form.cod} onChange={e=>setForm(f=>({...f,cod:e.target.value}))} placeholder="GAMEA/TI/2024/001"/></div>
          <div className="col-6"><label className="g-form-label">Categoría</label><select className="g-form-control" value={form.cat} onChange={e=>setForm(f=>({...f,cat:e.target.value}))}><option>Equipo Tecnológico</option><option>Vehículo</option><option>Maquinaria Pesada</option><option>Mobiliario</option><option>Equipamiento</option></select></div>
          <div className="col-12"><label className="g-form-label">Ubicación</label><input className="g-form-control" value={form.ubi} onChange={e=>setForm(f=>({...f,ubi:e.target.value}))}/></div>
          <div className="col-6"><label className="g-form-label">Valor (Bs)</label><input className="g-form-control" type="number" value={form.valor} onChange={e=>setForm(f=>({...f,valor:e.target.value}))}/></div>
          <div className="col-6"><label className="g-form-label">Estado</label><select className="g-form-control" value={form.estado} onChange={e=>setForm(f=>({...f,estado:e.target.value}))}><option>Excelente</option><option>Bueno</option><option>Regular</option><option>Malo</option></select></div>
          <div className="col-12"><label className="g-form-label">Responsable</label><input className="g-form-control" value={form.resp} onChange={e=>setForm(f=>({...f,resp:e.target.value}))}/></div>
        </div>
        <div className="d-flex justify-content-end gap-2 mt-4">
          <button className="btn-secondary-gamea" onClick={()=>setModal(false)}>Cancelar</button>
          <button className="btn-primary-gamea" onClick={save}>Registrar Activo</button>
        </div>
      </Modal>
    </div>
  );
}
