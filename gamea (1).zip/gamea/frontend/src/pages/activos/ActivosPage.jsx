import { Outlet, useNavigate, useLocation } from 'react-router-dom';
const TABS = [{ id:'bsiaf', label:'BSIAF' },{ id:'almacenes', label:'Control Almacenes' }];
export default function ActivosPage() {
  const navigate = useNavigate(); const { pathname } = useLocation();
  return (
    <div className="g-card g-fade-in">
      <div className="g-tabs-bar">
        {TABS.map(t=><button key={t.id} className={`g-tab-btn ${pathname.endsWith(t.id)?'active':''}`} onClick={()=>navigate(`/app/activos/${t.id}`)}>{t.label}</button>)}
      </div>
      <Outlet/>
    </div>
  );
}
