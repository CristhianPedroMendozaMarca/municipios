import Progress from '../../../components/common/Progress';
import { MOCK_PROYECTOS } from '../../../utils/mockData';
const MOCK_HR=[
  { id:'HR-001', nombre:'Programa Desarrollo Vial', tipo:'Programa', responsable:'Ing. Roberto Cáceres', inicio:'01/01/2024', fin:'31/12/2024', avance:55 },
  { id:'HR-002', nombre:'Hoja de Ruta: Gestión Ambiental', tipo:'Actividad', responsable:'Lic. Elena Torrez', inicio:'15/03/2024', fin:'30/11/2024', avance:30 },
  { id:'HR-003', nombre:'Programa Social Integral', tipo:'Programa', responsable:'Lic. Sandra Rojas', inicio:'01/02/2024', fin:'31/12/2024', avance:70 },
];
export default function SeguimientoHRTab() {
  return (
    <div style={{ padding:20 }}>
      {MOCK_HR.map(h=>(
        <div key={h.id} className="g-card mb-3">
          <div style={{ padding:'16px 20px' }}>
            <div className="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2">
              <div>
                <span className="g-badge badge-info me-2">{h.tipo}</span>
                <span style={{ fontWeight:700, fontSize:15, fontFamily:'Lora,serif', color:'#1a1a2e' }}>{h.nombre}</span>
              </div>
              <span style={{ fontSize:12, color:'#6b7280', fontFamily:'Nunito,sans-serif' }}>{h.inicio} → {h.fin}</span>
            </div>
            <div style={{ fontSize:12.5, color:'#6b7280', marginBottom:10, fontFamily:'Nunito,sans-serif' }}>Responsable: {h.responsable}</div>
            <Progress value={h.avance}/>
          </div>
        </div>
      ))}
    </div>
  );
}
