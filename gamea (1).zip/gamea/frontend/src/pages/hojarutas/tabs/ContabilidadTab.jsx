import { Plus, Download } from 'lucide-react';
import Badge from '../../../components/common/Badge';
import { MOCK_TESORERIA } from '../../../utils/mockData';
export default function ContabilidadTab() {
  const total_ing = 1245680+580000+342150;
  const total_egr = 856340+124500;
  return (
    <div>
      <div className="row g-3 p-3">
        {[['Ingresos Ejecutados',`Bs ${(total_ing/1000).toFixed(1)}K`,'#10b981'],['Gastos Corrientes',`Bs ${(total_egr/1000).toFixed(1)}K`,'#1B3A6B'],['Inversión Pública','Bs 7.2M','#d97706'],['Saldo Tesorería','Bs 1.8M','#7c3aed']].map(([l,v,c])=>(
          <div key={l} className="col-6 col-md-3">
            <div className="g-stat-card" style={{ borderLeft:`4px solid ${c}` }}>
              <div style={{ fontSize:20, fontWeight:700, color:c, fontFamily:'Lora,serif' }}>{v}</div>
              <div style={{ fontSize:12.5, color:'#374151', fontFamily:'Nunito,sans-serif', marginTop:3, fontWeight:600 }}>{l}</div>
              <div style={{ fontSize:11, color:'#9ca3af', fontFamily:'Nunito,sans-serif', marginTop:2 }}>Junio 2024</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ padding:'0 20px 14px', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10 }}>
        <h6 style={{ margin:0, fontFamily:'Lora,serif' }}>Movimientos de Tesorería — Junio 2024</h6>
        <div className="d-flex gap-2">
          <button className="btn-secondary-gamea"><Download size={13}/>Exportar</button>
          <button className="btn-gold-gamea"><Plus size={14}/>Nueva Transacción</button>
        </div>
      </div>
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead><tr><th>Fecha</th><th>Descripción</th><th>Tipo</th><th>Monto (Bs)</th><th>Estado</th><th>Referencia</th></tr></thead>
          <tbody>
            {MOCK_TESORERIA.map(t=>(
              <tr key={t.id}>
                <td style={{ fontSize:12.5, color:'#6b7280' }}>{t.fecha}</td>
                <td style={{ fontWeight:500 }}>{t.desc}</td>
                <td>{t.tipo==='Ingreso'?<span className="g-badge badge-success">Ingreso</span>:<span className="g-badge badge-danger">Egreso</span>}</td>
                <td style={{ fontWeight:600, color:t.tipo==='Ingreso'?'#10b981':'#ef4444' }}>{t.tipo==='Egreso'?'- ':'+ '}{t.monto}</td>
                <td><Badge estado={t.estado}/></td>
                <td><code style={{ fontSize:12, color:'#6b7280' }}>{t.ref}</code></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
