import { Plus } from 'lucide-react';
import Badge    from '../../../components/common/Badge';
import Progress from '../../../components/common/Progress';
import { MOCK_PROYECTOS } from '../../../utils/mockData';
export default function ProyectosTab() {
  return (
    <div>
      <div className="d-flex justify-content-between align-items-center p-3"><span style={{ fontSize:13.5, fontFamily:'Nunito,sans-serif', color:'#374151', fontWeight:600 }}>Programas y Proyectos 2024</span><button className="btn-gold-gamea"><Plus size={14}/>Nuevo Proyecto</button></div>
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead><tr><th>Código</th><th>Proyecto</th><th>Sector</th><th>Presupuesto (Bs)</th><th>Av. Físico</th><th>Av. Financiero</th><th>Estado</th><th>Fecha Fin</th></tr></thead>
          <tbody>{MOCK_PROYECTOS.map(p=>(
            <tr key={p.id}>
              <td><code style={{ fontSize:12, color:'#6b7280' }}>{p.id}</code></td>
              <td style={{ fontWeight:600, maxWidth:240 }}>{p.nombre}</td>
              <td><span className="g-badge badge-info">{p.sector}</span></td>
              <td style={{ fontWeight:600, color:'#1B3A6B' }}>{p.presupuesto}</td>
              <td style={{ minWidth:130 }}><Progress value={p.avFis}/></td>
              <td style={{ minWidth:130 }}><Progress value={p.avFin}/></td>
              <td><Badge estado={p.estado}/></td>
              <td style={{ fontSize:12, color:'#6b7280' }}>{p.fin}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}
