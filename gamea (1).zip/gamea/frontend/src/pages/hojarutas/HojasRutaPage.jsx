import { Outlet, useNavigate, useLocation } from 'react-router-dom';
const TABS=[{id:'proyectos',label:'Prog. y Proyectos'},{id:'seguimiento',label:'Seguimiento'},{id:'contabilidad',label:'Contabilidad/Tesorería'}];
export default function HojasRutaPage() {
  const navigate=useNavigate(); const { pathname }=useLocation();
  return (<div className="g-card g-fade-in"><div className="g-tabs-bar">{TABS.map(t=><button key={t.id} className={`g-tab-btn ${pathname.endsWith(t.id)?'active':''}`} onClick={()=>navigate(`/app/hojarutas/${t.id}`)}>{t.label}</button>)}</div><Outlet/></div>);
}
