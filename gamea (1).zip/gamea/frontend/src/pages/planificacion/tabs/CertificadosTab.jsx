import { Plus } from 'lucide-react';
import Badge    from '../../../components/common/Badge';
import Progress from '../../../components/common/Progress';
import { MOCK_PROYECTOS } from '../../../utils/mockData';
export default function CertificadosTab() {
  return (
    <div>
      <div className="d-flex justify-content-between align-items-center p-3">
        <span style={{ fontSize:13, color:'#6b7280', fontFamily:'Nunito,sans-serif' }}>{MOCK_PROYECTOS.length} proyectos</span>
        <button className="btn-gold-gamea"><Plus size={14}/>Emitir Certificado</button>
      </div>
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead><tr><th>Código</th><th>Proyecto/Actividad</th><th>Sector</th><th>Cumplimiento</th><th>Estado Cert.</th><th>Fecha Emisión</th></tr></thead>
          <tbody>
            {MOCK_PROYECTOS.map(p=>(
              <tr key={p.id}>
                <td><code style={{ fontSize:12, color:'#6b7280' }}>{p.id}</code></td>
                <td style={{ fontWeight:600 }}>{p.nombre}</td>
                <td style={{ fontSize:12.5, color:'#6b7280' }}>{p.sector}</td>
                <td style={{ minWidth:140 }}><Progress value={p.avFis}/></td>
                <td>{p.avFis>=100?<Badge estado="Certificado"/>:p.avFis>=80?<span className="g-badge badge-warning">Por Certificar</span>:<span className="g-badge badge-info">En Proceso</span>}</td>
                <td style={{ fontSize:12.5, color:'#6b7280' }}>{p.avFis>=100?'30/04/2024':'—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
