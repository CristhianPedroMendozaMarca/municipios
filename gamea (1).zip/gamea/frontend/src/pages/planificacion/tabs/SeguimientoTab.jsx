import Progress from '../../../components/common/Progress';
import Badge    from '../../../components/common/Badge';
import { MOCK_PROYECTOS } from '../../../utils/mockData';
export default function SeguimientoTab() {
  return (
    <div style={{ padding:20 }}>
      {MOCK_PROYECTOS.map(p=>(
        <div key={p.id} className="g-card mb-3" style={{ overflow:'visible' }}>
          <div style={{ padding:'16px 20px' }}>
            <div className="d-flex justify-content-between align-items-start mb-3 flex-wrap gap-2">
              <div>
                <div style={{ fontWeight:700, fontSize:15, color:'#1a1a2e', fontFamily:'Lora,serif' }}>{p.nombre}</div>
                <div style={{ fontSize:12.5, color:'#6b7280', fontFamily:'Nunito,sans-serif' }}>{p.sector} · {p.inicio} → {p.fin}</div>
              </div>
              <div className="d-flex align-items-center gap-2">
                <span style={{ fontSize:13, color:'#1B3A6B', fontWeight:600, fontFamily:'Nunito,sans-serif' }}>Bs {p.presupuesto}</span>
                <Badge estado={p.estado}/>
              </div>
            </div>
            <div className="row g-2">
              <div className="col-6"><div style={{ fontSize:11.5, color:'#6b7280', marginBottom:6, fontFamily:'Nunito,sans-serif' }}>Avance Físico</div><Progress value={p.avFis}/></div>
              <div className="col-6"><div style={{ fontSize:11.5, color:'#6b7280', marginBottom:6, fontFamily:'Nunito,sans-serif' }}>Avance Financiero</div><Progress value={p.avFin}/></div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
