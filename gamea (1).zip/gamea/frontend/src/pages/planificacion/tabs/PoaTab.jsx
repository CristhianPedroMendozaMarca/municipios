import { Plus, Download } from 'lucide-react';
import Badge    from '../../../components/common/Badge';
import Progress from '../../../components/common/Progress';
import { MOCK_PROYECTOS } from '../../../utils/mockData';
export default function PoaTab() {
  return (
    <div>
      <div className="d-flex justify-content-between align-items-center p-3" style={{ flexWrap:'wrap', gap:10 }}>
        <div className="d-flex gap-3">
          {[['24','Total Proyectos','#1B3A6B'],['Bs 18.2M','Presupuesto','#065f46'],['47%','Avance Prom.','#d97706']].map(([v,l,c])=>(
            <div key={l} style={{ textAlign:'center' }}>
              <div style={{ fontSize:20, fontWeight:700, color:c, fontFamily:'Lora,serif', lineHeight:1 }}>{v}</div>
              <div style={{ fontSize:11.5, color:'#6b7280', fontFamily:'Nunito,sans-serif' }}>{l}</div>
            </div>
          ))}
        </div>
        <div className="d-flex gap-2">
          <button className="btn-secondary-gamea"><Download size={13}/>Reporte</button>
          <button className="btn-gold-gamea"><Plus size={14}/>Nuevo Proyecto</button>
        </div>
      </div>
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead><tr><th>Código</th><th>Proyecto/Actividad</th><th>Sector</th><th>Presupuesto (Bs)</th><th>Av. Físico</th><th>Av. Financiero</th><th>Estado</th><th>Inicio</th><th>Fin</th></tr></thead>
          <tbody>
            {MOCK_PROYECTOS.map(p=>(
              <tr key={p.id}>
                <td><code style={{ fontSize:12, color:'#6b7280' }}>{p.id}</code></td>
                <td style={{ fontWeight:600, maxWidth:240 }}>{p.nombre}</td>
                <td><span className="g-badge badge-info">{p.sector}</span></td>
                <td style={{ fontWeight:600, color:'#1B3A6B' }}>{p.presupuesto}</td>
                <td style={{ minWidth:140 }}><Progress value={p.avFis}/></td>
                <td style={{ minWidth:140 }}><Progress value={p.avFin}/></td>
                <td><Badge estado={p.estado}/></td>
                <td style={{ fontSize:12, color:'#6b7280' }}>{p.inicio}</td>
                <td style={{ fontSize:12, color:'#6b7280' }}>{p.fin}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
