import { Outlet, useNavigate, useLocation } from 'react-router-dom';
const TABS=[{id:'poa',label:'Plan Operativo Anual'},{id:'seguimiento',label:'Seguimiento Físico'},{id:'certificados',label:'Certificados'}];
export default function PlanificacionPage() {
  const navigate=useNavigate(); const { pathname }=useLocation();
  return (<div className="g-card g-fade-in"><div className="g-tabs-bar">{TABS.map(t=><button key={t.id} className={`g-tab-btn ${pathname.endsWith(t.id)?'active':''}`} onClick={()=>navigate(`/app/planificacion/${t.id}`)}>{t.label}</button>)}</div><Outlet/></div>);
}
