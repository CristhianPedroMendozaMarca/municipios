import { useState } from 'react';
import { Search, Download, Activity } from 'lucide-react';
import { MOCK_LOGS } from '../../../utils/mockData';
export default function LogsTab() {
  const [search, setSearch] = useState('');
  const [modulo, setModulo] = useState('');
  const filtered = MOCK_LOGS.filter(l =>
    (!search || l.accion.toLowerCase().includes(search.toLowerCase()) || l.nombre.toLowerCase().includes(search.toLowerCase())) &&
    (!modulo || l.modulo === modulo)
  );
  const modulos = [...new Set(MOCK_LOGS.map(l=>l.modulo))];
  const tipo_colors = { info:'#dbeafe,#3b82f6', success:'#d1fae5,#10b981', warning:'#fef3c7,#d97706', danger:'#fee2e2,#ef4444' };
  return (
    <div>
      <div style={{ padding:'14px 20px', borderBottom:'1px solid #e5e7eb', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10 }}>
        <div className="d-flex gap-2 flex-wrap">
          <div className="g-search-wrap"><Search size={14} className="icon"/><input placeholder="Buscar en logs..." value={search} onChange={e=>setSearch(e.target.value)}/></div>
          <select className="g-form-control" style={{ width:180 }} value={modulo} onChange={e=>setModulo(e.target.value)}>
            <option value="">Todos los módulos</option>
            {modulos.map(m=><option key={m}>{m}</option>)}
          </select>
        </div>
        <button className="btn-secondary-gamea"><Download size={13}/>Exportar</button>
      </div>
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead><tr><th>Tipo</th><th>Usuario</th><th>Acción Realizada</th><th>Módulo</th><th>Fecha y Hora</th><th>IP</th></tr></thead>
          <tbody>
            {filtered.map(l=>{
              const [bg,c]=(tipo_colors[l.tipo]||'#f3f4f6,#6b7280').split(',');
              return (
                <tr key={l.id}>
                  <td><div style={{ width:28,height:28,borderRadius:'50%',background:bg,display:'flex',alignItems:'center',justifyContent:'center' }}><Activity size={13} color={c}/></div></td>
                  <td><div style={{ fontWeight:600, fontSize:13.5 }}>{l.nombre}</div><div style={{ fontSize:11.5, color:'#6b7280', fontFamily:'monospace' }}>{l.user}</div></td>
                  <td style={{ maxWidth:280 }}>{l.accion}</td>
                  <td><span className={`g-badge ${l.modulo==='Super Usuario'?'badge-purple':l.modulo==='Autenticación'?'badge-info':'badge-gray'}`}>{l.modulo}</span></td>
                  <td><code style={{ fontSize:12.5, color:'#6b7280' }}>{l.fecha}</code></td>
                  <td><code style={{ fontSize:12 }}>{l.ip}</code></td>
                </tr>
              );
            })}
            {filtered.length===0&&<tr><td colSpan={6} className="text-center py-4" style={{ color:'#9ca3af',fontFamily:'Nunito,sans-serif' }}>Sin registros</td></tr>}
          </tbody>
        </table>
      </div>
      <div style={{ padding:'10px 20px', borderTop:'1px solid #f3f4f6' }}>
        <span style={{ fontSize:12.5, color:'#6b7280', fontFamily:'Nunito,sans-serif' }}>{filtered.length} registros encontrados</span>
      </div>
    </div>
  );
}
