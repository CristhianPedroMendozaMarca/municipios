import { CheckCircle } from 'lucide-react';
import Avatar from '../../../components/common/Avatar';
import { useAuth } from '../../../hooks/useAuth';
const MODS=[{id:'personal',label:'Adm. Personal'},{id:'activos',label:'Activos Fijos'},{id:'planificacion',label:'Planificación'},{id:'hojarutas',label:'Hojas de Ruta'}];

export default function PermisosTab() {
  const { usersDb, permsDb, updatePerms } = useAuth();
  const toggle = (uid,mod) => {
    const cur = permsDb[uid]||{};
    updatePerms(uid, { ...cur, [mod]:!cur[mod] });
  };
  return (
    <div>
      <div style={{ padding:'14px 20px', borderBottom:'1px solid #e5e7eb', display:'flex', alignItems:'center', gap:8 }}>
        <CheckCircle size={15} color="#10b981"/>
        <span style={{ fontSize:13, color:'#6b7280', fontFamily:'Nunito,sans-serif' }}>Los cambios se aplican de inmediato. Los usuarios inhabilitados no pueden acceder aunque tengan permisos.</span>
      </div>
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead>
            <tr>
              <th>Usuario</th><th>Rol</th>
              {MODS.map(m=><th key={m.id} style={{ textAlign:'center' }}>{m.label}</th>)}
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            {usersDb.filter(u=>u.role!=='superuser').map(u=>(
              <tr key={u.id}>
                <td>
                  <div className="d-flex align-items-center gap-2">
                    <Avatar initials={u.avatar} size={28}/>
                    <div><div style={{ fontWeight:600, fontSize:13.5 }}>{u.nombre}</div><div style={{ fontSize:11.5, color:'#6b7280' }}>{u.email}</div></div>
                  </div>
                </td>
                <td><span className="g-badge badge-info">{u.cargo}</span></td>
                {MODS.map(m=>(
                  <td key={m.id} style={{ textAlign:'center' }}>
                    <input type="checkbox" style={{ width:17, height:17, cursor:'pointer', accentColor:'#1B3A6B' }}
                      checked={!!(permsDb[u.id]||{})[m.id]} onChange={()=>toggle(u.id,m.id)} disabled={!u.active}/>
                  </td>
                ))}
                <td>{u.active?<span className="g-badge badge-success">Activo</span>:<span className="g-badge badge-danger">Inactivo</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div style={{ padding:'12px 20px', background:'#F8FAFC', borderTop:'1px solid #e5e7eb', display:'flex', alignItems:'center', gap:8 }}>
        <span style={{ fontSize:12.5, color:'#1B3A6B', fontFamily:'Nunito,sans-serif' }}>🛡️ <strong>Super Usuario</strong> siempre tiene acceso completo a todos los módulos independientemente de los permisos.</span>
      </div>
    </div>
  );
}
