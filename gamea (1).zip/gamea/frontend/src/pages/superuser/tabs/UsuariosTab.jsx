import { useState } from 'react';
import { UserPlus, Edit2, Trash2, Lock, Unlock, Search } from 'lucide-react';
import Avatar from '../../../components/common/Avatar';
import Badge  from '../../../components/common/Badge';
import Modal  from '../../../components/common/Modal';
import { useAuth } from '../../../hooks/useAuth';
import { getInitials } from '../../../utils/helpers';

export default function UsuariosTab() {
  const { usersDb, setUsersDb } = useAuth();
  const [search, setSearch] = useState('');
  const [modal,  setModal]  = useState(false);
  const [edit,   setEdit]   = useState(null);
  const [form,   setForm]   = useState({ nombre:'', email:'', password:'', cargo:'', role:'rrhh' });

  const filtered = usersDb.filter(u => u.nombre.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase()));
  const openNew  = () => { setEdit(null); setForm({ nombre:'',email:'',password:'',cargo:'',role:'rrhh' }); setModal(true); };
  const openEdit = (u) => { setEdit(u); setForm({ nombre:u.nombre,email:u.email,password:u.password,cargo:u.cargo,role:u.role }); setModal(true); };
  const save = () => {
    if (!form.nombre||!form.email) { alert('Nombre y email son requeridos'); return; }
    if (edit) {
      setUsersDb(d => d.map(u => u.id===edit.id ? { ...u,...form,avatar:getInitials(form.nombre) } : u));
    } else {
      const id = Math.max(...usersDb.map(u=>u.id))+1;
      setUsersDb(d=>[...d,{ id,...form,avatar:getInitials(form.nombre),active:true,creado:new Date().toLocaleDateString('es-BO') }]);
    }
    setModal(false);
  };
  const toggle = (id) => setUsersDb(d => d.map(u => u.id===id ? { ...u,active:!u.active } : u));
  const del    = (id) => { if (window.confirm('¿Confirma eliminar este usuario?')) setUsersDb(d=>d.filter(u=>u.id!==id)); };

  return (
    <div>
      <div style={{ padding:'14px 20px', borderBottom:'1px solid #e5e7eb', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10 }}>
        <div className="g-search-wrap"><Search size={14} className="icon"/><input placeholder="Buscar usuario..." value={search} onChange={e=>setSearch(e.target.value)}/></div>
        <button className="btn-gold-gamea" onClick={openNew}><UserPlus size={14}/>Nuevo Usuario</button>
      </div>
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead><tr><th>Usuario</th><th>Correo</th><th>Cargo</th><th>Rol</th><th>Estado</th><th>Creado</th><th>Acciones</th></tr></thead>
          <tbody>
            {filtered.map(u=>(
              <tr key={u.id}>
                <td>
                  <div className="d-flex align-items-center gap-2">
                    <Avatar initials={u.avatar} size={30} bg={u.role==='superuser'?'linear-gradient(135deg,#C8952A,#e8b84b)':undefined} color={u.role==='superuser'?'#0d2247':undefined}/>
                    <div>
                      <div style={{ fontWeight:600, fontSize:13.5 }}>{u.nombre}</div>
                      {u.role==='superuser' && <div style={{ fontSize:10.5, color:'#C8952A', fontWeight:700 }}>SUPER USUARIO</div>}
                    </div>
                  </div>
                </td>
                <td style={{ fontSize:13 }}>{u.email}</td>
                <td style={{ fontSize:13, color:'#6b7280' }}>{u.cargo}</td>
                <td><span className={`g-badge ${u.role==='superuser'?'badge-warning':'badge-info'}`}>{u.role}</span></td>
                <td><Badge estado={u.active?'Activo':'Inhabilitado'}/></td>
                <td style={{ fontSize:12, color:'#6b7280' }}>{u.creado}</td>
                <td>
                  <div className="d-flex gap-1">
                    <button className="btn-icon-gamea edit" onClick={()=>openEdit(u)} title="Editar"><Edit2 size={12}/></button>
                    <button className="btn-icon-gamea" onClick={()=>toggle(u.id)} title={u.active?'Inhabilitar':'Habilitar'}
                      style={u.active?{}:{borderColor:'#10b981',color:'#10b981'}}>
                      {u.active?<Lock size={12}/>:<Unlock size={12}/>}
                    </button>
                    {u.role!=='superuser' && <button className="btn-icon-gamea del" onClick={()=>del(u.id)} title="Eliminar"><Trash2 size={12}/></button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal show={modal} onClose={()=>setModal(false)} title={edit?'Editar Usuario':'Nuevo Usuario'}>
        <div className="row g-3">
          <div className="col-12"><label className="g-form-label">Nombre Completo *</label><input className="g-form-control" value={form.nombre} onChange={e=>setForm(f=>({...f,nombre:e.target.value}))} placeholder="Ej: Juan Pérez López"/></div>
          <div className="col-12"><label className="g-form-label">Correo Institucional *</label><input className="g-form-control" type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} placeholder="usuario@gamea.bo"/></div>
          <div className="col-12"><label className="g-form-label">Contraseña {edit?'(dejar vacío para no cambiar)':''}</label><input className="g-form-control" type="password" value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))} placeholder="Mínimo 6 caracteres"/></div>
          <div className="col-12"><label className="g-form-label">Cargo</label><input className="g-form-control" value={form.cargo} onChange={e=>setForm(f=>({...f,cargo:e.target.value}))} placeholder="Ej: Jefe de Área"/></div>
          <div className="col-12">
            <label className="g-form-label">Rol del Sistema</label>
            <select className="g-form-control" value={form.role} onChange={e=>setForm(f=>({...f,role:e.target.value}))}>
              <option value="rrhh">Recursos Humanos</option>
              <option value="activos">Activos Fijos</option>
              <option value="planificacion">Planificación</option>
              <option value="finanzas">Finanzas</option>
            </select>
          </div>
        </div>
        <div className="d-flex justify-content-end gap-2 mt-4">
          <button className="btn-secondary-gamea" onClick={()=>setModal(false)}>Cancelar</button>
          <button className="btn-primary-gamea" onClick={save}>Guardar Usuario</button>
        </div>
      </Modal>
    </div>
  );
}
