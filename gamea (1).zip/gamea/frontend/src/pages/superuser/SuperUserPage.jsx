import { Outlet, useNavigate, useLocation } from 'react-router-dom';
const TABS=[{id:'usuarios',label:'Gestión Usuarios'},{id:'permisos',label:'Permisos de Acceso'},{id:'logs',label:'Logs del Sistema'}];
export default function SuperUserPage() {
  const navigate=useNavigate(); const { pathname }=useLocation();
  return (<div className="g-card g-fade-in"><div className="g-tabs-bar">{TABS.map(t=><button key={t.id} className={`g-tab-btn ${pathname.endsWith(t.id)?'active':''}`} onClick={()=>navigate(`/app/superuser/${t.id}`)}>{t.label}</button>)}</div><Outlet/></div>);
}
