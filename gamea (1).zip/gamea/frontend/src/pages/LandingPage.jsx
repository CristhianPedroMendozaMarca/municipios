import LandingNavbar  from '../components/landing/LandingNavbar';
import Hero           from '../components/landing/Hero';
import QuienesSomos   from '../components/landing/QuienesSomos';
import MisionVision   from '../components/landing/MisionVision';
import Footer         from '../components/landing/Footer';

export default function LandingPage() {
  return (
    <>
      <LandingNavbar />
      <Hero />
      <QuienesSomos />
      <MisionVision />
      <Footer />
    </>
  );
}
