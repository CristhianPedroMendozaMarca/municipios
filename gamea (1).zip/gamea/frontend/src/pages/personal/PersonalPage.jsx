import { useNavigate, useParams, Outlet, Navigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';

const TABS = [
  { id:'expediente',  label:'Expediente Digital'    },
  { id:'asistencia',  label:'Control Asistencia'    },
  { id:'desempeno',   label:'Desempeño'             },
  { id:'kpis',        label:'KPIs / Dashboard'      },
];

export default function PersonalPage() {
  const navigate  = useNavigate();
  const { pathname } = useLocation();
  const active = (id) => pathname.endsWith(id);
  return (
    <div className="g-card g-fade-in">
      <div className="g-tabs-bar">
        {TABS.map(t => (
          <button key={t.id} className={`g-tab-btn ${active(t.id)?'active':''}`}
            onClick={() => navigate(`/app/personal/${t.id}`)}>
            {t.label}
          </button>
        ))}
      </div>
      <div style={{ padding:0 }}>
        <Outlet/>
      </div>
    </div>
  );
}
