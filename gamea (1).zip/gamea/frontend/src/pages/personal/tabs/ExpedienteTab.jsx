import { useState } from 'react';
import { Plus, Eye, Edit2, Trash2, Search } from 'lucide-react';
import Badge    from '../../../components/common/Badge';
import Avatar   from '../../../components/common/Avatar';
import Modal    from '../../../components/common/Modal';
import { MOCK_PERSONAL } from '../../../utils/mockData';
import { getInitials } from '../../../utils/helpers';

export default function ExpedienteTab() {
  const [data,   setData]   = useState(MOCK_PERSONAL);
  const [search, setSearch] = useState('');
  const [modal,  setModal]  = useState(false);
  const [edit,   setEdit]   = useState(null);
  const [form,   setForm]   = useState({ nombre:'', ci:'', cargo:'', unidad:'', tipo:'Ítem', estado:'Activo', ingreso:'' });

  const filtered = data.filter(p =>
    p.nombre.toLowerCase().includes(search.toLowerCase()) || p.ci.includes(search)
  );

  const openNew  = () => { setEdit(null); setForm({ nombre:'', ci:'', cargo:'', unidad:'', tipo:'Ítem', estado:'Activo', ingreso:'' }); setModal(true); };
  const openEdit = (row) => { setEdit(row); setForm({ nombre:row.nombre, ci:row.ci, cargo:row.cargo, unidad:row.unidad, tipo:row.tipo, estado:row.estado, ingreso:row.ingreso }); setModal(true); };
  const del      = (id) => { if (window.confirm('¿Confirma eliminar este funcionario?')) setData(d => d.filter(x => x.id !== id)); };
  const save = () => {
    if (!form.nombre || !form.ci) { alert('Nombre y CI son requeridos'); return; }
    if (edit) {
      setData(d => d.map(x => x.id === edit.id ? { ...x, ...form, av: getInitials(form.nombre) } : x));
    } else {
      setData(d => [...d, { ...form, id:`F-${String(d.length+1).padStart(3,'0')}`, av: getInitials(form.nombre) }]);
    }
    setModal(false);
  };

  return (
    <div>
      {/* Header */}
      <div style={{ padding:'16px 20px', borderBottom:'1px solid #e5e7eb', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10 }}>
        <span style={{ fontSize:13, color:'#6b7280', fontFamily:'Nunito,sans-serif' }}>
          {filtered.length} de {data.length} registros
        </span>
        <div className="d-flex gap-2">
          <div className="g-search-wrap">
            <Search size={14} className="icon"/>
            <input placeholder="Buscar por nombre o CI..." value={search} onChange={e => setSearch(e.target.value)}/>
          </div>
          <button className="btn-gold-gamea" onClick={openNew}><Plus size={14}/>Nuevo Funcionario</button>
        </div>
      </div>

      {/* Tabla */}
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead>
            <tr><th>Cód.</th><th>Funcionario</th><th>C.I.</th><th>Cargo</th><th>Unidad</th><th>Tipo</th><th>Estado</th><th>Ingreso</th><th>Acciones</th></tr>
          </thead>
          <tbody>
            {filtered.map(row => (
              <tr key={row.id}>
                <td><code style={{ fontSize:12, color:'#6b7280' }}>{row.id}</code></td>
                <td>
                  <div className="d-flex align-items-center gap-2">
                    <Avatar initials={row.av} size={28}/>
                    <span style={{ fontWeight:600 }}>{row.nombre}</span>
                  </div>
                </td>
                <td><code style={{ fontSize:13 }}>{row.ci}</code></td>
                <td>{row.cargo}</td>
                <td style={{ fontSize:12.5, color:'#6b7280' }}>{row.unidad}</td>
                <td>
                  {row.tipo==='Ítem'     && <Badge estado="Activo"   />}
                  {row.tipo==='Eventual' && <span className="g-badge badge-warning">Eventual</span>}
                  {row.tipo==='Consultor'&& <span className="g-badge badge-purple">Consultor</span>}
                </td>
                <td><Badge estado={row.estado}/></td>
                <td style={{ fontSize:12.5, color:'#6b7280' }}>{row.ingreso}</td>
                <td>
                  <div className="d-flex gap-1">
                    <button className="btn-icon-gamea view" title="Ver"><Eye size={13}/></button>
                    <button className="btn-icon-gamea edit" title="Editar" onClick={() => openEdit(row)}><Edit2 size={13}/></button>
                    <button className="btn-icon-gamea del"  title="Eliminar" onClick={() => del(row.id)}><Trash2 size={13}/></button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length===0 && (
              <tr><td colSpan={9} className="text-center py-4" style={{ color:'#9ca3af', fontFamily:'Nunito,sans-serif' }}>Sin resultados para "{search}"</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      <Modal show={modal} onClose={() => setModal(false)} title={edit ? 'Editar Funcionario' : 'Nuevo Funcionario'}>
        <div className="row g-3">
          <div className="col-12">
            <label className="g-form-label">Nombre Completo *</label>
            <input className="g-form-control" value={form.nombre} onChange={e => setForm(f=>({...f,nombre:e.target.value}))} placeholder="Ej: Juan Pérez López"/>
          </div>
          <div className="col-6">
            <label className="g-form-label">Cédula de Identidad *</label>
            <input className="g-form-control" value={form.ci} onChange={e => setForm(f=>({...f,ci:e.target.value}))} placeholder="1234567"/>
          </div>
          <div className="col-6">
            <label className="g-form-label">Fecha de Ingreso</label>
            <input className="g-form-control" type="date" value={form.ingreso} onChange={e => setForm(f=>({...f,ingreso:e.target.value}))}/>
          </div>
          <div className="col-12">
            <label className="g-form-label">Cargo</label>
            <input className="g-form-control" value={form.cargo} onChange={e => setForm(f=>({...f,cargo:e.target.value}))} placeholder="Ej: Técnico en Sistemas"/>
          </div>
          <div className="col-12">
            <label className="g-form-label">Unidad Organizacional</label>
            <input className="g-form-control" value={form.unidad} onChange={e => setForm(f=>({...f,unidad:e.target.value}))} placeholder="Ej: Dirección de TI"/>
          </div>
          <div className="col-6">
            <label className="g-form-label">Tipo de Contrato</label>
            <select className="g-form-control" value={form.tipo} onChange={e => setForm(f=>({...f,tipo:e.target.value}))}>
              <option>Ítem</option><option>Eventual</option><option>Consultor</option>
            </select>
          </div>
          <div className="col-6">
            <label className="g-form-label">Estado</label>
            <select className="g-form-control" value={form.estado} onChange={e => setForm(f=>({...f,estado:e.target.value}))}>
              <option>Activo</option><option>Licencia</option><option>Baja</option><option>Suspendido</option>
            </select>
          </div>
        </div>
        <div className="d-flex justify-content-end gap-2 mt-4">
          <button className="btn-secondary-gamea" onClick={() => setModal(false)}>Cancelar</button>
          <button className="btn-primary-gamea" onClick={save}>Guardar Cambios</button>
        </div>
      </Modal>
    </div>
  );
}
