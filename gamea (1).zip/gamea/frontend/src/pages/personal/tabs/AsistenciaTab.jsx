import { Filter, Download } from 'lucide-react';
import Badge from '../../../components/common/Badge';
import { MOCK_ASISTENCIA } from '../../../utils/mockData';
export default function AsistenciaTab() {
  const resumen = [
    ['Presentes',   MOCK_ASISTENCIA.filter(a=>a.estado==='Presente').length,  '#d1fae5','#10b981'],
    ['Tardanzas',   MOCK_ASISTENCIA.filter(a=>a.estado==='Tardanza').length,   '#fef3c7','#d97706'],
    ['Ausentes',    MOCK_ASISTENCIA.filter(a=>a.estado==='Ausente').length,    '#fee2e2','#ef4444'],
    ['Perm./Lic.',  MOCK_ASISTENCIA.filter(a=>['Permiso','Licencia'].includes(a.estado)).length,'#ede9fe','#7c3aed'],
  ];
  return (
    <div>
      <div style={{ padding:'14px 20px', borderBottom:'1px solid #e5e7eb', display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:10 }}>
        <div className="d-flex gap-2 flex-wrap">
          {resumen.map(([l,n,bg,c])=>(
            <div key={l} style={{ display:'flex', alignItems:'center', gap:7, padding:'7px 13px', background:bg, borderRadius:8 }}>
              <span style={{ fontSize:19, fontWeight:700, color:c, fontFamily:'Lora,serif', lineHeight:1 }}>{n}</span>
              <span style={{ fontSize:12, color:c, fontFamily:'Nunito,sans-serif', fontWeight:600 }}>{l}</span>
            </div>
          ))}
        </div>
        <div className="d-flex gap-2">
          <input type="date" className="g-form-control" defaultValue="2024-06-15" style={{ width:160 }}/>
          <button className="btn-secondary-gamea"><Filter size={13}/>Filtrar</button>
          <button className="btn-primary-gamea"><Download size={13}/>Exportar</button>
        </div>
      </div>
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead><tr><th>Código</th><th>Funcionario</th><th>Entrada</th><th>Salida</th><th>Estado</th><th>Observación</th></tr></thead>
          <tbody>
            {MOCK_ASISTENCIA.map(a=>(
              <tr key={a.id}>
                <td><code style={{ fontSize:12, color:'#6b7280' }}>{a.id}</code></td>
                <td style={{ fontWeight:600 }}>{a.nombre}</td>
                <td><code style={{ color:a.entrada==='—'?'#d1d5db':'#1a1a2e' }}>{a.entrada}</code></td>
                <td><code style={{ color:a.salida==='—'?'#d1d5db':'#1a1a2e' }}>{a.salida}</code></td>
                <td><Badge estado={a.estado}/></td>
                <td style={{ fontSize:12.5, color:'#6b7280' }}>{a.obs}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
