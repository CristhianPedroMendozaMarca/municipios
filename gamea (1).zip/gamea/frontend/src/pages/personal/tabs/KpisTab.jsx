import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { MOCK_CHART_ASIST } from '../../../utils/mockData';
const PIE_DATA = [{ name:'Ítem', value:5, color:'#1B3A6B' },{ name:'Eventual', value:2, color:'#C8952A' },{ name:'Consultor', value:1, color:'#10b981' }];
export default function KpisTab() {
  return (
    <div style={{ padding:20 }}>
      <div className="row g-3 mb-3">
        {[['Índice Puntualidad','88.5%','Jun 2024','#10b981'],['Rotación Personal','4.2%','Ene–Jun 2024','#3b82f6'],['Vac. Pendientes','23.4 días','Prom. / persona','#d97706']].map(([l,v,s,c])=>(
          <div key={l} className="col-12 col-md-4">
            <div className="g-stat-card" style={{ borderTop:`3px solid ${c}` }}>
              <div style={{ fontSize:28, fontWeight:700, color:c, fontFamily:'Lora,serif', lineHeight:1 }}>{v}</div>
              <div style={{ fontSize:13.5, fontWeight:600, color:'#374151', fontFamily:'Nunito,sans-serif', marginTop:6 }}>{l}</div>
              <div style={{ fontSize:11.5, color:'#9ca3af', fontFamily:'Nunito,sans-serif' }}>{s}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="row g-3">
        <div className="col-12 col-md-7">
          <div className="g-card">
            <div className="g-card-header"><h5>Tendencia de Asistencia</h5></div>
            <div style={{ padding:16 }}>
              <ResponsiveContainer width="100%" height={210}>
                <LineChart data={MOCK_CHART_ASIST}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6"/>
                  <XAxis dataKey="mes" tick={{ fontSize:11, fontFamily:'Nunito' }}/>
                  <YAxis tick={{ fontSize:11, fontFamily:'Nunito' }}/>
                  <Tooltip contentStyle={{ fontFamily:'Nunito', fontSize:12, borderRadius:8 }}/>
                  <Legend iconType="circle" wrapperStyle={{ fontSize:11, fontFamily:'Nunito' }}/>
                  <Line type="monotone" dataKey="presentes" name="Presentes" stroke="#1B3A6B" strokeWidth={2} dot={{ r:4 }}/>
                  <Line type="monotone" dataKey="ausentes"  name="Ausentes"  stroke="#ef4444" strokeWidth={2} dot={{ r:4 }}/>
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
        <div className="col-12 col-md-5">
          <div className="g-card">
            <div className="g-card-header"><h5>Distribución por Contrato</h5></div>
            <div style={{ padding:16 }}>
              <ResponsiveContainer width="100%" height={210}>
                <PieChart>
                  <Pie data={PIE_DATA} cx="50%" cy="50%" outerRadius={75} dataKey="value" label={({name,percent})=>`${name} ${(percent*100).toFixed(0)}%`}>
                    {PIE_DATA.map((e,i)=><Cell key={i} fill={e.color}/>)}
                  </Pie>
                  <Tooltip contentStyle={{ fontFamily:'Nunito', fontSize:12, borderRadius:8 }}/>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
