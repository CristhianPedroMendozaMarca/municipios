import { Download } from 'lucide-react';
import Badge    from '../../../components/common/Badge';
import Progress from '../../../components/common/Progress';
import { MOCK_DESEMPENO } from '../../../utils/mockData';
export default function DesempenoTab() {
  return (
    <div>
      <div style={{ padding:'14px 20px', borderBottom:'1px solid #e5e7eb', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <span style={{ fontSize:13.5, fontWeight:600, color:'#374151', fontFamily:'Nunito,sans-serif' }}>Periodo: Ene–Jun 2024</span>
        <button className="btn-primary-gamea"><Download size={13}/>Reporte PDF</button>
      </div>
      <div style={{ overflowX:'auto' }}>
        <table className="g-table">
          <thead><tr><th>Funcionario</th><th>Cargo</th><th>Eficiencia</th><th>Eficacia</th><th>Resultado</th><th>Promedio</th><th>Nivel</th></tr></thead>
          <tbody>
            {MOCK_DESEMPENO.map(d=>(
              <tr key={d.id}>
                <td style={{ fontWeight:600 }}>{d.nombre}</td>
                <td style={{ fontSize:12.5, color:'#6b7280' }}>{d.cargo}</td>
                <td style={{ minWidth:130 }}><Progress value={d.eficiencia}/></td>
                <td style={{ minWidth:130 }}><Progress value={d.eficacia}/></td>
                <td style={{ minWidth:130 }}><Progress value={d.resultado}/></td>
                <td><span style={{ fontSize:16, fontWeight:700, color:d.prom>=85?'#10b981':d.prom>=70?'#d97706':'#ef4444', fontFamily:'Lora,serif' }}>{d.prom}</span></td>
                <td><Badge estado={d.nivel}/></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
