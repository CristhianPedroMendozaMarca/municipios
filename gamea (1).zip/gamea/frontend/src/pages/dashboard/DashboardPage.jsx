import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend, LineChart, Line } from 'recharts';
import { Users, Package, Target, DollarSign, Activity, Download } from 'lucide-react';
import StatCard   from '../../components/common/StatCard';
import { MOCK_CHART_ASIST, MOCK_CHART_PIE, MOCK_CHART_AVANCE, MOCK_LOGS } from '../../utils/mockData';

export default function DashboardPage() {
  return (
    <div className="g-fade-in">
      {/* KPIs */}
      <div className="row g-3 mb-3">
        {[
          { label:'Personal Activo',     value:'487', sub:'+12 este mes',      icon:<Users size={20}/>,    bg:'#dbeafe', iconColor:'#1B3A6B', trend:'2.5%' },
          { label:'Activos Registrados', value:'1,243', sub:'BSIAF actualizado', icon:<Package size={20}/>,  bg:'#d1fae5', iconColor:'#065f46', trend:'+5'  },
          { label:'Proyectos Activos',   value:'24',  sub:'4 por cerrar',      icon:<Target size={20}/>,   bg:'#fef3c7', iconColor:'#92400e', trend:'2 nuevos' },
          { label:'Presup. Ejecutado',   value:'68.4%', sub:'Bs 12.4M de 18.2M', icon:<DollarSign size={20}/>, bg:'#ede9fe', iconColor:'#5b21b6', trend:'3.2%' },
        ].map(p => (
          <div key={p.label} className="col-12 col-sm-6 col-xl-3">
            <StatCard {...p}/>
          </div>
        ))}
      </div>

      {/* Asistencia + Activos */}
      <div className="row g-3 mb-3">
        <div className="col-12 col-lg-8">
          <div className="g-card">
            <div className="g-card-header">
              <h5>Asistencia Mensual — 2024</h5>
              <button className="btn-secondary-gamea"><Download size={13}/>Exportar</button>
            </div>
            <div style={{ padding:'16px' }}>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={MOCK_CHART_ASIST} barGap={2}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6"/>
                  <XAxis dataKey="mes" tick={{ fontSize:12, fontFamily:'Nunito' }}/>
                  <YAxis tick={{ fontSize:12, fontFamily:'Nunito' }}/>
                  <Tooltip contentStyle={{ fontFamily:'Nunito', fontSize:13, borderRadius:8 }}/>
                  <Legend iconType="circle" wrapperStyle={{ fontSize:12, fontFamily:'Nunito' }}/>
                  <Bar dataKey="presentes"  name="Presentes"  fill="#1B3A6B" radius={[4,4,0,0]}/>
                  <Bar dataKey="tardanzas"  name="Tardanzas"  fill="#C8952A" radius={[4,4,0,0]}/>
                  <Bar dataKey="ausentes"   name="Ausentes"   fill="#ef4444" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
        <div className="col-12 col-lg-4">
          <div className="g-card h-100">
            <div className="g-card-header"><h5>Activos por Categoría</h5></div>
            <div style={{ padding:16 }}>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={MOCK_CHART_PIE} cx="50%" cy="50%" innerRadius={55} outerRadius={80} paddingAngle={3} dataKey="value">
                    {MOCK_CHART_PIE.map((e,i) => <Cell key={i} fill={e.color}/>)}
                  </Pie>
                  <Tooltip contentStyle={{ fontFamily:'Nunito', fontSize:12, borderRadius:8 }}/>
                  <Legend iconType="circle" wrapperStyle={{ fontSize:11, fontFamily:'Nunito' }}/>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      {/* Proyectos + Actividad */}
      <div className="row g-3">
        <div className="col-12 col-lg-6">
          <div className="g-card">
            <div className="g-card-header"><h5>Avance de Proyectos</h5></div>
            <div style={{ padding:'16px 8px' }}>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={MOCK_CHART_AVANCE} layout="vertical" barGap={2}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" horizontal={false}/>
                  <XAxis type="number" domain={[0,100]} tick={{ fontSize:11, fontFamily:'Nunito' }}/>
                  <YAxis dataKey="proj" type="category" tick={{ fontSize:11, fontFamily:'Nunito' }} width={68}/>
                  <Tooltip contentStyle={{ fontFamily:'Nunito', fontSize:12, borderRadius:8 }} formatter={v => `${v}%`}/>
                  <Legend iconType="circle" wrapperStyle={{ fontSize:11, fontFamily:'Nunito' }}/>
                  <Bar dataKey="fisico"      name="Físico"      fill="#1B3A6B" radius={[0,4,4,0]}/>
                  <Bar dataKey="financiero"  name="Financiero"  fill="#C8952A" radius={[0,4,4,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
        <div className="col-12 col-lg-6">
          <div className="g-card">
            <div className="g-card-header"><h5>Actividad Reciente</h5></div>
            <div>
              {MOCK_LOGS.slice(0,5).map(l => (
                <div key={l.id} style={{ display:'flex', gap:12, padding:'12px 18px', borderBottom:'1px solid #f3f4f6', alignItems:'flex-start' }}>
                  <div style={{ width:30, height:30, borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, background: l.tipo==='danger'?'#fee2e2':l.tipo==='warning'?'#fef3c7':l.tipo==='success'?'#d1fae5':'#dbeafe' }}>
                    <Activity size={13} color={l.tipo==='danger'?'#ef4444':l.tipo==='warning'?'#d97706':l.tipo==='success'?'#10b981':'#3b82f6'}/>
                  </div>
                  <div>
                    <div style={{ fontSize:13, color:'#1a1a2e', fontFamily:'Nunito,sans-serif', fontWeight:500 }}>{l.accion}</div>
                    <div style={{ fontSize:11.5, color:'#9ca3af', fontFamily:'Nunito,sans-serif', marginTop:2 }}>{l.nombre} · {l.fecha}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
