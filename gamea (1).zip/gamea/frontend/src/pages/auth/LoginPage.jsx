import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, AlertTriangle, Eye, EyeOff, ChevronLeft, LogIn } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

export default function LoginPage() {
  const [email,    setEmail]   = useState('');
  const [password, setPass]    = useState('');
  const [err,      setErr]     = useState('');
  const [loading,  setLoading] = useState(false);
  const [showPass, setShowP]   = useState(false);
  const { login, usersDb }     = useAuth();
  const navigate               = useNavigate();

  const handleSubmit = async () => {
    setErr('');
    if (!email || !password) { setErr('Complete todos los campos.'); return; }
    setLoading(true);
    try {
      await login(email, password);
      navigate('/app/dashboard', { replace: true });
    } catch (e) {
      setErr(e.message || 'Error al iniciar sesión.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight:'100vh', background:'linear-gradient(135deg,#0a1732 0%,#1B3A6B 100%)', display:'flex', alignItems:'center', justifyContent:'center', padding:20, position:'relative' }}>
      <div style={{ position:'absolute', inset:0, background:'radial-gradient(circle at 20% 50%,rgba(200,149,42,.08) 0%,transparent 50%),radial-gradient(circle at 80% 20%,rgba(45,82,150,.14) 0%,transparent 50%)' }}/>
      <div style={{ position:'relative', zIndex:1, width:'100%', maxWidth:440 }}>
        <button onClick={() => navigate('/')}
          style={{ background:'none', border:'none', color:'rgba(255,255,255,.6)', cursor:'pointer', display:'flex', alignItems:'center', gap:7, marginBottom:22, fontFamily:'Nunito,sans-serif', fontSize:13.5, padding:0 }}>
          <ChevronLeft size={15}/>Volver al inicio
        </button>

        <div style={{ background:'white', borderRadius:20, padding:'44px 38px', boxShadow:'0 28px 70px rgba(0,0,0,.38)' }}>
          {/* Logo */}
          <div style={{ textAlign:'center', marginBottom:28 }}>
            <div style={{ width:60, height:60, background:'linear-gradient(135deg,#1B3A6B,#2d5296)', borderRadius:15, display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 14px' }}>
              <Shield size={26} color="white"/>
            </div>
            <h2 style={{ fontSize:22, color:'#0a1732', marginBottom:5 }}>Acceso al Sistema</h2>
            <p style={{ fontSize:13.5, color:'#6b7280', fontFamily:'Nunito,sans-serif', margin:0 }}>GAMEA — Gestión Municipal Integrada</p>
          </div>

          {/* Error */}
          {err && (
            <div style={{ background:'#fee2e2', border:'1px solid #fecaca', borderRadius:8, padding:'11px 14px', marginBottom:18, display:'flex', alignItems:'center', gap:8 }}>
              <AlertTriangle size={15} color="#ef4444"/>
              <span style={{ fontSize:13.5, color:'#991b1b', fontFamily:'Nunito,sans-serif' }}>{err}</span>
            </div>
          )}

          {/* Correo */}
          <div className="mb-3">
            <label className="g-form-label">Correo Institucional</label>
            <input className="g-form-control" type="email" placeholder="usuario@gamea.bo"
              value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key==='Enter' && handleSubmit()}/>
          </div>

          {/* Contraseña */}
          <div className="mb-4">
            <label className="g-form-label">Contraseña</label>
            <div style={{ position:'relative' }}>
              <input className="g-form-control" type={showPass?'text':'password'} placeholder="••••••••"
                value={password} onChange={e => setPass(e.target.value)} onKeyDown={e => e.key==='Enter' && handleSubmit()}
                style={{ paddingRight:42 }}/>
              <button onClick={() => setShowP(!showPass)}
                style={{ position:'absolute', right:11, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#9ca3af', padding:0 }}>
                {showPass ? <EyeOff size={15}/> : <Eye size={15}/>}
              </button>
            </div>
          </div>

          {/* Submit */}
          <button onClick={handleSubmit} disabled={loading}
            style={{ width:'100%', padding:13, background:'linear-gradient(135deg,#1B3A6B,#2d5296)', color:'white', fontWeight:700, fontSize:15, border:'none', borderRadius:10, cursor:'pointer', fontFamily:'Nunito,sans-serif', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
            <LogIn size={16}/>{loading ? 'Verificando...' : 'Ingresar al Sistema'}
          </button>

          {/* Demo credentials */}
          <div style={{ marginTop:22, padding:14, background:'#F8FAFC', borderRadius:10, border:'1px solid #e5e7eb' }}>
            <p style={{ fontSize:10.5, color:'#6b7280', fontFamily:'Nunito,sans-serif', margin:'0 0 7px', fontWeight:700, textTransform:'uppercase', letterSpacing:'0.5px' }}>
              Credenciales de demostración (click para autocompletar)
            </p>
            {usersDb.filter(u => u.active).map(u => (
              <div key={u.email} onClick={() => { setEmail(u.email); setPass(u.password); }}
                style={{ display:'flex', justifyContent:'space-between', padding:'4px 6px', borderRadius:5, cursor:'pointer', marginBottom:2 }}
                onMouseEnter={e => e.currentTarget.style.background='#eef2ff'}
                onMouseLeave={e => e.currentTarget.style.background='transparent'}>
                <span style={{ fontSize:12, color:'#1B3A6B', fontFamily:'Nunito,sans-serif', fontWeight:600 }}>{u.email}</span>
                <span style={{ fontSize:12, color:'#6b7280', fontFamily:'Nunito,sans-serif' }}>{u.password}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
