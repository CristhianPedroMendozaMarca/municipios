const app  = require('./src/app');
const { PORT } = require('./src/config/env');

app.listen(PORT, () => {
  console.log('\n══════════════════════════════════════');
  console.log(' 🏛️  GAMEA — Sistema Municipal BACKEND');
  console.log('══════════════════════════════════════');
  console.log(` 🚀 Servidor : http://localhost:${PORT}`);
  console.log(` 🗄️  Base de datos : PostgreSQL`);
  console.log(` 🌍 Entorno : ${process.env.NODE_ENV || 'development'}`);
  console.log('══════════════════════════════════════\n');
});
