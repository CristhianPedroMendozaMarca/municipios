const { query } = require('../config/db');

exports.getStats = async (req, res, next) => {
  try {
    const [personal, activos, proyectos, presupuesto] = await Promise.all([
      query(`SELECT COUNT(*) AS total, COUNT(*) FILTER(WHERE estado='Activo') AS activos FROM personal`),
      query(`SELECT COUNT(*) AS total FROM activos_fijos WHERE estado != 'Dado de Baja'`),
      query(`SELECT COUNT(*) AS total, COUNT(*) FILTER(WHERE estado='Ejecución') AS en_ejecucion, COUNT(*) FILTER(WHERE estado='Por Cerrar') AS por_cerrar FROM proyectos`),
      query(`SELECT COALESCE(SUM(presupuesto),0) AS total, COALESCE(SUM(presupuesto*avance_financiero/100),0) AS ejecutado FROM proyectos`),
    ]);
    res.json({
      personal:    personal.rows[0],
      activos:     activos.rows[0],
      proyectos:   proyectos.rows[0],
      presupuesto: presupuesto.rows[0],
    });
  } catch (err) { next(err); }
};

exports.getAsistenciaChart = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM v_asistencia_mensual LIMIT 6');
    res.json(rows);
  } catch (err) { next(err); }
};

exports.getActivosChart = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM v_activos_resumen');
    res.json(rows);
  } catch (err) { next(err); }
};

exports.getProyectosChart = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT nombre, avance_fisico AS fisico, avance_financiero AS financiero
       FROM proyectos WHERE estado NOT IN ('Planificado','Suspendido')
       ORDER BY avance_fisico DESC LIMIT 8`
    );
    res.json(rows);
  } catch (err) { next(err); }
};

exports.getActividadReciente = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT l.*, u.nombre_completo, u.email FROM logs_sistema l
       LEFT JOIN usuarios u ON l.usuario_id = u.id
       ORDER BY l.created_at DESC LIMIT 10`
    );
    res.json(rows);
  } catch (err) { next(err); }
};
