const { query } = require('../config/db');

// GET /api/activos
exports.getAll = async (req, res, next) => {
  try {
    const { search, estado, categoria, page=1, limit=20 } = req.query;
    const offset = (page-1)*limit;
    const conds=[],params=[]; let i=1;
    if (search)    { conds.push(`(descripcion ILIKE $${i} OR codigo_bsiaf ILIKE $${i})`); params.push(`%${search}%`); i++; }
    if (estado)    { conds.push(`estado=$${i++}`); params.push(estado); }
    if (categoria) { conds.push(`categoria=$${i++}`); params.push(categoria); }
    const w = conds.length ? `WHERE ${conds.join(' AND ')}` : '';
    const cnt  = await query(`SELECT COUNT(*) FROM activos_fijos ${w}`, params);
    const data = await query(`SELECT * FROM activos_fijos ${w} ORDER BY codigo_bsiaf LIMIT $${i} OFFSET $${i+1}`, [...params,limit,offset]);
    res.json({ data:data.rows, total:+cnt.rows[0].count, page:+page, limit:+limit });
  } catch (err) { next(err); }
};

// GET /api/activos/stats
exports.getStats = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM v_activos_resumen');
    const total = await query(`SELECT COUNT(*) AS total, COALESCE(SUM(valor_adquisicion),0) AS valor FROM activos_fijos WHERE estado != 'Dado de Baja'`);
    res.json({ porCategoria: rows, resumen: total.rows[0] });
  } catch (err) { next(err); }
};

// GET /api/activos/:id
exports.getById = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM activos_fijos WHERE id=$1', [req.params.id]);
    if (!rows[0]) return res.status(404).json({ error: 'Activo no encontrado' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

// POST /api/activos
exports.create = async (req, res, next) => {
  try {
    const { descripcion,codigo_bsiaf,categoria,marca,modelo,serie,ubicacion,unidad_org,responsable,estado,valor_adquisicion,fecha_adquisicion,vida_util_anos,fuente_financiamiento } = req.body;
    const { rows } = await query(
      `INSERT INTO activos_fijos (descripcion,codigo_bsiaf,categoria,marca,modelo,serie,ubicacion,unidad_org,responsable,estado,valor_adquisicion,fecha_adquisicion,vida_util_anos,fuente_financiamiento)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
      [descripcion,codigo_bsiaf,categoria,marca,modelo,serie,ubicacion,unidad_org,responsable,estado||'Bueno',valor_adquisicion,fecha_adquisicion,vida_util_anos,fuente_financiamiento]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

// PUT /api/activos/:id
exports.update = async (req, res, next) => {
  try {
    const { descripcion,ubicacion,unidad_org,responsable,estado,valor_actual,observaciones } = req.body;
    const { rows } = await query(
      `UPDATE activos_fijos SET descripcion=$1,ubicacion=$2,unidad_org=$3,responsable=$4,estado=$5,valor_actual=$6,observaciones=$7,updated_at=NOW()
       WHERE id=$8 RETURNING *`,
      [descripcion,ubicacion,unidad_org,responsable,estado,valor_actual,observaciones,req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Activo no encontrado' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

// DELETE /api/activos/:id
exports.remove = async (req, res, next) => {
  try {
    const { rowCount } = await query('DELETE FROM activos_fijos WHERE id=$1',[req.params.id]);
    if (!rowCount) return res.status(404).json({ error: 'Activo no encontrado' });
    res.json({ message: 'Activo eliminado' });
  } catch (err) { next(err); }
};

// GET /api/activos/:id/mantenimiento
exports.getMantenimiento = async (req, res, next) => {
  try {
    const { rows } = await query(
      'SELECT * FROM mantenimiento_activos WHERE activo_id=$1 ORDER BY fecha_inicio DESC',
      [req.params.id]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

// POST /api/activos/mantenimiento
exports.saveMantenimiento = async (req, res, next) => {
  try {
    const { activo_id,tipo,descripcion,costo,proveedor,fecha_inicio,fecha_fin,tecnico } = req.body;
    const { rows } = await query(
      `INSERT INTO mantenimiento_activos (activo_id,tipo,descripcion,costo,proveedor,fecha_inicio,fecha_fin,tecnico)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [activo_id,tipo,descripcion,costo,proveedor,fecha_inicio,fecha_fin,tecnico]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

// GET /api/activos/almacenes/lista
exports.getAlmacenes = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM almacenes WHERE activo=true ORDER BY nombre');
    res.json(rows);
  } catch (err) { next(err); }
};

// POST /api/activos/almacenes
exports.createAlmacen = async (req, res, next) => {
  try {
    const { nombre,ubicacion,responsable,capacidad,descripcion } = req.body;
    const { rows } = await query(
      `INSERT INTO almacenes (nombre,ubicacion,responsable,capacidad,descripcion) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [nombre,ubicacion,responsable,capacidad,descripcion]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

// GET /api/activos/almacenes/:id/inventario
exports.getInventario = async (req, res, next) => {
  try {
    const { rows } = await query(
      'SELECT * FROM inventario_almacen WHERE almacen_id=$1 ORDER BY descripcion',
      [req.params.id]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

// POST /api/activos/almacenes/inventario
exports.saveInventario = async (req, res, next) => {
  try {
    const { almacen_id,descripcion,unidad_medida,cantidad,cantidad_minima,valor_unitario,codigo } = req.body;
    const { rows } = await query(
      `INSERT INTO inventario_almacen (almacen_id,descripcion,unidad_medida,cantidad,cantidad_minima,valor_unitario,codigo)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [almacen_id,descripcion,unidad_medida,cantidad,cantidad_minima,valor_unitario,codigo]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};
