const bcrypt = require('bcryptjs');
const { query } = require('../config/db');

// ── Usuarios ──────────────────────────────────────────────────
exports.getUsuarios = async (_req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT u.id,u.nombre_completo,u.email,u.cargo,u.activo,u.avatar_iniciales,u.ultimo_acceso,u.created_at, r.nombre AS rol
       FROM usuarios u JOIN roles r ON u.rol_id=r.id ORDER BY u.nombre_completo`
    );
    res.json(rows);
  } catch (err) { next(err); }
};

exports.getUsuarioById = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT u.*,r.nombre AS rol FROM usuarios u JOIN roles r ON u.rol_id=r.id WHERE u.id=$1`, [req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error:'Usuario no encontrado' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

exports.createUsuario = async (req, res, next) => {
  try {
    const { nombre_completo,email,password,cargo,rol_id } = req.body;
    if (!nombre_completo||!email||!password||!rol_id)
      return res.status(400).json({ error:'Nombre, email, contraseña y rol son requeridos' });
    const hash = await bcrypt.hash(password, 12);
    const av   = nombre_completo.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase();
    const { rows } = await query(
      `INSERT INTO usuarios (nombre_completo,email,password_hash,cargo,rol_id,avatar_iniciales) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id,nombre_completo,email,cargo,activo,avatar_iniciales,created_at`,
      [nombre_completo,email,hash,cargo,rol_id,av]
    );
    // Crear permisos vacíos
    await query(`INSERT INTO permisos_usuario (usuario_id) VALUES ($1) ON CONFLICT DO NOTHING`, [rows[0].id]);
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

exports.updateUsuario = async (req, res, next) => {
  try {
    const { nombre_completo,cargo,rol_id,activo } = req.body;
    const av = nombre_completo.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase();
    const { rows } = await query(
      `UPDATE usuarios SET nombre_completo=$1,cargo=$2,rol_id=$3,activo=$4,avatar_iniciales=$5,updated_at=NOW() WHERE id=$6 RETURNING id,nombre_completo,email,cargo,activo,avatar_iniciales`,
      [nombre_completo,cargo,rol_id,activo,av,req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error:'Usuario no encontrado' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

exports.deleteUsuario = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT rol_id FROM usuarios WHERE id=$1',[req.params.id]);
    if (!rows[0]) return res.status(404).json({ error:'Usuario no encontrado' });
    const { rows: roleRows } = await query('SELECT nombre FROM roles WHERE id=$1',[rows[0].rol_id]);
    if (roleRows[0]?.nombre === 'superuser')
      return res.status(403).json({ error:'No se puede eliminar al Super Administrador' });
    await query('DELETE FROM usuarios WHERE id=$1',[req.params.id]);
    res.json({ message:'Usuario eliminado correctamente' });
  } catch (err) { next(err); }
};

exports.toggleUsuario = async (req, res, next) => {
  try {
    const { rows } = await query(
      `UPDATE usuarios SET activo=NOT activo,updated_at=NOW() WHERE id=$1 RETURNING activo,nombre_completo`,
      [req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error:'Usuario no encontrado' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

exports.resetPassword = async (req, res, next) => {
  try {
    const { nueva_password } = req.body;
    if (!nueva_password || nueva_password.length < 6)
      return res.status(400).json({ error:'La contraseña debe tener al menos 6 caracteres' });
    const hash = await bcrypt.hash(nueva_password, 12);
    await query('UPDATE usuarios SET password_hash=$1,updated_at=NOW() WHERE id=$2',[hash,req.params.id]);
    res.json({ message:'Contraseña actualizada correctamente' });
  } catch (err) { next(err); }
};

// ── Permisos ──────────────────────────────────────────────────
exports.getPermisos = async (_req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT p.*,u.nombre_completo,u.email FROM permisos_usuario p JOIN usuarios u ON p.usuario_id=u.id`
    );
    res.json(rows);
  } catch (err) { next(err); }
};

exports.updatePermisos = async (req, res, next) => {
  try {
    const { personal=false,activos=false,planificacion=false,hojarutas=false } = req.body;
    const { rows } = await query(
      `INSERT INTO permisos_usuario (usuario_id,personal,activos,planificacion,hojarutas)
       VALUES ($1,$2,$3,$4,$5)
       ON CONFLICT (usuario_id) DO UPDATE SET personal=$2,activos=$3,planificacion=$4,hojarutas=$5,updated_at=NOW()
       RETURNING *`,
      [req.params.usuarioId,personal,activos,planificacion,hojarutas]
    );
    res.json(rows[0]);
  } catch (err) { next(err); }
};

// ── Roles ─────────────────────────────────────────────────────
exports.getRoles = async (_req, res, next) => {
  try {
    const { rows } = await query('SELECT id,nombre,descripcion FROM roles ORDER BY id');
    res.json(rows);
  } catch (err) { next(err); }
};

// ── Logs ──────────────────────────────────────────────────────
exports.getLogs = async (req, res, next) => {
  try {
    const { usuario_id,modulo,desde,hasta,search,page=1,limit=50 } = req.query;
    const offset=(page-1)*limit; const conds=[],params=[]; let i=1;
    if (usuario_id) { conds.push(`l.usuario_id=$${i++}`); params.push(usuario_id); }
    if (modulo)     { conds.push(`l.modulo=$${i++}`); params.push(modulo); }
    if (desde)      { conds.push(`l.created_at>=$${i++}`); params.push(desde); }
    if (hasta)      { conds.push(`l.created_at<=$${i++}`); params.push(hasta); }
    if (search)     { conds.push(`l.accion ILIKE $${i++}`); params.push(`%${search}%`); }
    const w = conds.length?`WHERE ${conds.join(' AND ')}`:'';
    const cnt  = await query(`SELECT COUNT(*) FROM logs_sistema l ${w}`,params);
    const data = await query(
      `SELECT l.*,u.nombre_completo,u.email FROM logs_sistema l LEFT JOIN usuarios u ON l.usuario_id=u.id ${w} ORDER BY l.created_at DESC LIMIT $${i} OFFSET $${i+1}`,
      [...params,limit,offset]
    );
    res.json({ data:data.rows, total:+cnt.rows[0].count });
  } catch (err) { next(err); }
};

exports.getModulosLog = async (_req, res, next) => {
  try {
    const { rows } = await query('SELECT DISTINCT modulo FROM logs_sistema ORDER BY modulo');
    res.json(rows.map(r=>r.modulo));
  } catch (err) { next(err); }
};
