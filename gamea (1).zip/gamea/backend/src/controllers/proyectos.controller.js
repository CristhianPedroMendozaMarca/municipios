const { query } = require('../config/db');

exports.getAll = async (req, res, next) => {
  try {
    const { estado, sector, page=1, limit=20 } = req.query;
    const offset=(page-1)*limit; const conds=[],params=[]; let i=1;
    if (estado) { conds.push(`estado=$${i++}`); params.push(estado); }
    if (sector) { conds.push(`sector=$${i++}`); params.push(sector); }
    const w = conds.length?`WHERE ${conds.join(' AND ')}`:'';
    const cnt  = await query(`SELECT COUNT(*) FROM proyectos ${w}`,params);
    const data = await query(`SELECT * FROM proyectos ${w} ORDER BY id LIMIT $${i} OFFSET $${i+1}`,[...params,limit,offset]);
    res.json({ data:data.rows, total:+cnt.rows[0].count });
  } catch (err) { next(err); }
};

exports.getStats = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM v_dashboard_proyectos');
    const tot = await query(`SELECT COUNT(*) AS total, COALESCE(SUM(presupuesto),0) AS presupuesto_total, ROUND(AVG(avance_fisico),1) AS avance_promedio FROM proyectos`);
    res.json({ porSector:rows, resumen:tot.rows[0] });
  } catch (err) { next(err); }
};

exports.getById = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM proyectos WHERE id=$1',[req.params.id]);
    if (!rows[0]) return res.status(404).json({ error:'Proyecto no encontrado' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

exports.create = async (req, res, next) => {
  try {
    const { nombre,sector,descripcion,presupuesto,fecha_inicio,fecha_fin,estado,responsable,fuente_financiamiento } = req.body;
    const { rows } = await query(
      `INSERT INTO proyectos (nombre,sector,descripcion,presupuesto,fecha_inicio,fecha_fin,estado,responsable,fuente_financiamiento)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [nombre,sector,descripcion,presupuesto,fecha_inicio,fecha_fin,estado||'Planificado',responsable,fuente_financiamiento]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

exports.update = async (req, res, next) => {
  try {
    const { nombre,sector,descripcion,presupuesto,fecha_inicio,fecha_fin,estado,responsable } = req.body;
    const { rows } = await query(
      `UPDATE proyectos SET nombre=$1,sector=$2,descripcion=$3,presupuesto=$4,fecha_inicio=$5,fecha_fin=$6,estado=$7,responsable=$8,updated_at=NOW()
       WHERE id=$9 RETURNING *`,
      [nombre,sector,descripcion,presupuesto,fecha_inicio,fecha_fin,estado,responsable,req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error:'Proyecto no encontrado' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

exports.remove = async (req, res, next) => {
  try {
    const { rowCount } = await query('DELETE FROM proyectos WHERE id=$1',[req.params.id]);
    if (!rowCount) return res.status(404).json({ error:'Proyecto no encontrado' });
    res.json({ message:'Proyecto eliminado' });
  } catch (err) { next(err); }
};

exports.updateAvance = async (req, res, next) => {
  try {
    const { avance_fisico,avance_financiero,estado,observacion } = req.body;
    const { rows } = await query(
      `UPDATE proyectos SET avance_fisico=$1,avance_financiero=$2,estado=$3,updated_at=NOW() WHERE id=$4 RETURNING *`,
      [avance_fisico,avance_financiero,estado,req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error:'Proyecto no encontrado' });
    await query(
      `INSERT INTO historial_avances (proyecto_id,avance_fisico,avance_financiero,observacion,registrado_por) VALUES ($1,$2,$3,$4,$5)`,
      [req.params.id,avance_fisico,avance_financiero,observacion,req.user.id]
    );
    res.json(rows[0]);
  } catch (err) { next(err); }
};

exports.getHistorialAvances = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT h.*, u.nombre_completo FROM historial_avances h LEFT JOIN usuarios u ON h.registrado_por=u.id
       WHERE h.proyecto_id=$1 ORDER BY h.created_at DESC`, [req.params.id]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

exports.getCertificados = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT c.*, p.nombre AS proyecto_nombre, u.nombre_completo AS emitido_por_nombre
       FROM certificados c LEFT JOIN proyectos p ON c.proyecto_id=p.id
       LEFT JOIN usuarios u ON c.emitido_por=u.id ORDER BY c.fecha_emision DESC`
    );
    res.json(rows);
  } catch (err) { next(err); }
};

exports.createCertificado = async (req, res, next) => {
  try {
    const { proyecto_id,numero_certificado,observaciones } = req.body;
    const { rows } = await query(
      `INSERT INTO certificados (proyecto_id,numero_certificado,observaciones,emitido_por) VALUES ($1,$2,$3,$4) RETURNING *`,
      [proyecto_id,numero_certificado,observaciones,req.user.id]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

exports.getHojasRuta = async (req, res, next) => {
  try {
    const { rows } = await query(`SELECT hr.*, p.nombre_completo AS responsable_nombre FROM hojas_ruta hr LEFT JOIN personal p ON hr.responsable_id=p.id ORDER BY hr.id`);
    res.json(rows);
  } catch (err) { next(err); }
};

exports.createHojaRuta = async (req, res, next) => {
  try {
    const { nombre,tipo,descripcion,responsable_id,fecha_inicio,fecha_fin } = req.body;
    const { rows } = await query(
      `INSERT INTO hojas_ruta (nombre,tipo,descripcion,responsable_id,fecha_inicio,fecha_fin) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
      [nombre,tipo,descripcion,responsable_id,fecha_inicio,fecha_fin]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

exports.saveSeguimiento = async (req, res, next) => {
  try {
    const { hoja_ruta_id,descripcion_avance,porcentaje_avance,observaciones } = req.body;
    const { rows } = await query(
      `INSERT INTO seguimiento_hojas_ruta (hoja_ruta_id,descripcion_avance,porcentaje_avance,observaciones,registrado_por) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [hoja_ruta_id,descripcion_avance,porcentaje_avance,observaciones,req.user.id]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};
