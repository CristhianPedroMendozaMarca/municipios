const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');
const { query } = require('../config/db');
const { JWT_SECRET, JWT_EXPIRES } = require('../config/env');
const { saveLog } = require('../middleware/auditLog.middleware');

const signToken = (payload) => jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES });

// POST /api/auth/login
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: 'Email y contraseña son requeridos' });

    const { rows } = await query(
      `SELECT u.*, r.nombre AS rol
       FROM usuarios u JOIN roles r ON u.rol_id = r.id
       WHERE u.email = $1`, [email]
    );
    const user = rows[0];

    if (!user)
      return res.status(401).json({ error: 'Credenciales incorrectas' });
    if (!user.activo)
      return res.status(403).json({ error: 'Usuario inhabilitado. Contacte al administrador.' });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok)
      return res.status(401).json({ error: 'Credenciales incorrectas' });

    await query('UPDATE usuarios SET ultimo_acceso = NOW() WHERE id = $1', [user.id]);
    await saveLog(user.id, 'Autenticación', 'Inició sesión', req.ip);

    const token = signToken({ id: user.id, email: user.email, role: user.rol });

    res.json({
      token,
      user: {
        id:     user.id,
        nombre: user.nombre_completo,
        email:  user.email,
        cargo:  user.cargo,
        role:   user.rol,
        avatar: user.avatar_iniciales,
      },
    });
  } catch (err) { next(err); }
};

// POST /api/auth/logout
exports.logout = async (req, res, next) => {
  try {
    await saveLog(req.user.id, 'Autenticación', 'Cerró sesión', req.ip);
    res.json({ message: 'Sesión cerrada correctamente' });
  } catch (err) { next(err); }
};

// PUT /api/auth/password
exports.changePassword = async (req, res, next) => {
  try {
    const { actual, nueva } = req.body;
    if (!actual || !nueva)
      return res.status(400).json({ error: 'Contraseña actual y nueva son requeridas' });
    if (nueva.length < 6)
      return res.status(400).json({ error: 'La nueva contraseña debe tener al menos 6 caracteres' });

    const { rows } = await query('SELECT password_hash FROM usuarios WHERE id = $1', [req.user.id]);
    const ok = await bcrypt.compare(actual, rows[0].password_hash);
    if (!ok)
      return res.status(401).json({ error: 'La contraseña actual es incorrecta' });

    const hash = await bcrypt.hash(nueva, 12);
    await query('UPDATE usuarios SET password_hash = $1, updated_at = NOW() WHERE id = $2', [hash, req.user.id]);
    await saveLog(req.user.id, 'Autenticación', 'Cambió su contraseña', req.ip);

    res.json({ message: 'Contraseña actualizada correctamente' });
  } catch (err) { next(err); }
};

// GET /api/auth/me
exports.me = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT u.id, u.nombre_completo, u.email, u.cargo, u.avatar_iniciales,
              u.ultimo_acceso, r.nombre AS rol
       FROM usuarios u JOIN roles r ON u.rol_id = r.id WHERE u.id = $1`,
      [req.user.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Usuario no encontrado' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};
