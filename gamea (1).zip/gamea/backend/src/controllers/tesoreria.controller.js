const { query } = require('../config/db');

exports.getAll = async (req, res, next) => {
  try {
    const { tipo,estado,desde,hasta,page=1,limit=20 } = req.query;
    const offset=(page-1)*limit; const conds=[],params=[]; let i=1;
    if (tipo)   { conds.push(`tipo=$${i++}`); params.push(tipo); }
    if (estado) { conds.push(`estado=$${i++}`); params.push(estado); }
    if (desde)  { conds.push(`fecha_transaccion>=$${i++}`); params.push(desde); }
    if (hasta)  { conds.push(`fecha_transaccion<=$${i++}`); params.push(hasta); }
    const w = conds.length?`WHERE ${conds.join(' AND ')}`:'';
    const cnt  = await query(`SELECT COUNT(*) FROM transacciones_tesoreria ${w}`,params);
    const data = await query(`SELECT t.*, p.nombre AS proyecto_nombre FROM transacciones_tesoreria t LEFT JOIN proyectos p ON t.proyecto_id=p.id ${w} ORDER BY t.fecha_transaccion DESC LIMIT $${i} OFFSET $${i+1}`,[...params,limit,offset]);
    res.json({ data:data.rows, total:+cnt.rows[0].count });
  } catch (err) { next(err); }
};

exports.getStats = async (req, res, next) => {
  try {
    const { rows } = await query(`
      SELECT
        COALESCE(SUM(monto) FILTER(WHERE tipo='Ingreso' AND estado!='Anulado'),0) AS total_ingresos,
        COALESCE(SUM(monto) FILTER(WHERE tipo='Egreso'  AND estado!='Anulado'),0) AS total_egresos,
        COALESCE(SUM(monto) FILTER(WHERE tipo='Ingreso' AND estado='Pendiente'),0) AS ingresos_pendientes,
        COALESCE(SUM(monto) FILTER(WHERE tipo='Egreso'  AND estado='Pendiente'),0) AS egresos_pendientes
      FROM transacciones_tesoreria`);
    res.json(rows[0]);
  } catch (err) { next(err); }
};

exports.getById = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM transacciones_tesoreria WHERE id=$1',[req.params.id]);
    if (!rows[0]) return res.status(404).json({ error:'Transacción no encontrada' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

exports.create = async (req, res, next) => {
  try {
    const { tipo,descripcion,monto,fuente,partida_presupuestaria,numero_referencia,fecha_transaccion,estado,proyecto_id,observaciones } = req.body;
    const { rows } = await query(
      `INSERT INTO transacciones_tesoreria (tipo,descripcion,monto,fuente,partida_presupuestaria,numero_referencia,fecha_transaccion,estado,proyecto_id,observaciones,aprobado_por)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [tipo,descripcion,monto,fuente,partida_presupuestaria,numero_referencia,fecha_transaccion,estado||'Pendiente',proyecto_id,observaciones,req.user.id]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

exports.updateEstado = async (req, res, next) => {
  try {
    const { estado } = req.body;
    const { rows } = await query(`UPDATE transacciones_tesoreria SET estado=$1 WHERE id=$2 RETURNING *`,[estado,req.params.id]);
    res.json(rows[0]);
  } catch (err) { next(err); }
};

exports.remove = async (req, res, next) => {
  try {
    await query(`UPDATE transacciones_tesoreria SET estado='Anulado' WHERE id=$1`,[req.params.id]);
    res.json({ message:'Transacción anulada' });
  } catch (err) { next(err); }
};

exports.getContrataciones = async (req, res, next) => {
  try {
    const { rows } = await query(`SELECT c.*, p.nombre AS proyecto_nombre FROM contrataciones c LEFT JOIN proyectos p ON c.proyecto_id=p.id ORDER BY c.created_at DESC`);
    res.json(rows);
  } catch (err) { next(err); }
};

exports.createContratacion = async (req, res, next) => {
  try {
    const { numero_contrato,proveedor,objeto_contratacion,modalidad,monto_contrato,fecha_inicio,fecha_fin,proyecto_id } = req.body;
    const { rows } = await query(
      `INSERT INTO contrataciones (numero_contrato,proveedor,objeto_contratacion,modalidad,monto_contrato,fecha_inicio,fecha_fin,proyecto_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [numero_contrato,proveedor,objeto_contratacion,modalidad,monto_contrato,fecha_inicio,fecha_fin,proyecto_id]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

exports.updateContratacion = async (req, res, next) => {
  try {
    const { proveedor,objeto_contratacion,monto_contrato,estado } = req.body;
    const { rows } = await query(
      `UPDATE contrataciones SET proveedor=$1,objeto_contratacion=$2,monto_contrato=$3,estado=$4 WHERE id=$5 RETURNING *`,
      [proveedor,objeto_contratacion,monto_contrato,estado,req.params.id]
    );
    res.json(rows[0]);
  } catch (err) { next(err); }
};
