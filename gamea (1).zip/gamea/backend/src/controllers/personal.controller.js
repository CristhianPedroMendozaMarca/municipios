const { query } = require('../config/db');

// ── Helpers ──────────────────────────────────────────────────
const buildWhere = (filters) => {
  const conds = [], params = [];
  let i = 1;
  const { search, unidad, tipo, estado } = filters;
  if (search) { conds.push(`(nombre_completo ILIKE $${i} OR ci = $${i+1})`); params.push(`%${search}%`, search); i += 2; }
  if (unidad) { conds.push(`unidad_organizacional = $${i++}`); params.push(unidad); }
  if (tipo)   { conds.push(`tipo_contrato = $${i++}`); params.push(tipo); }
  if (estado) { conds.push(`estado = $${i++}`); params.push(estado); }
  return { where: conds.length ? `WHERE ${conds.join(' AND ')}` : '', params, nextIdx: i };
};

// GET /api/personal
exports.getAll = async (req, res, next) => {
  try {
    const { page = 1, limit = 20, ...filters } = req.query;
    const offset = (page - 1) * limit;
    const { where, params, nextIdx } = buildWhere(filters);

    const cnt  = await query(`SELECT COUNT(*) FROM personal ${where}`, params);
    const data = await query(
      `SELECT * FROM personal ${where} ORDER BY nombre_completo LIMIT $${nextIdx} OFFSET $${nextIdx+1}`,
      [...params, limit, offset]
    );
    res.json({ data: data.rows, total: +cnt.rows[0].count, page: +page, limit: +limit });
  } catch (err) { next(err); }
};

// GET /api/personal/:id
exports.getById = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM personal WHERE id = $1', [req.params.id]);
    if (!rows[0]) return res.status(404).json({ error: 'Funcionario no encontrado' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

// POST /api/personal
exports.create = async (req, res, next) => {
  try {
    const { nombre_completo, ci, cargo, unidad_organizacional, tipo_contrato, estado, fecha_ingreso, telefono, email_institucional } = req.body;
    const av = nombre_completo.split(' ').map(w => w[0]).slice(0,2).join('').toUpperCase();
    const { rows } = await query(
      `INSERT INTO personal (nombre_completo,ci,cargo,unidad_organizacional,tipo_contrato,estado,fecha_ingreso,telefono,email_institucional,avatar_iniciales)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [nombre_completo,ci,cargo,unidad_organizacional,tipo_contrato,estado||'Activo',fecha_ingreso,telefono,email_institucional,av]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

// PUT /api/personal/:id
exports.update = async (req, res, next) => {
  try {
    const { nombre_completo,ci,cargo,unidad_organizacional,tipo_contrato,estado,telefono,email_institucional,
            tiene_cert_idioma,tiene_libreta_militar,tiene_cert_capacitacion,tiene_dec_jurada_bienes } = req.body;
    const { rows } = await query(
      `UPDATE personal SET
         nombre_completo=$1,ci=$2,cargo=$3,unidad_organizacional=$4,tipo_contrato=$5,estado=$6,
         telefono=$7,email_institucional=$8,tiene_cert_idioma=$9,tiene_libreta_militar=$10,
         tiene_cert_capacitacion=$11,tiene_dec_jurada_bienes=$12,updated_at=NOW()
       WHERE id=$13 RETURNING *`,
      [nombre_completo,ci,cargo,unidad_organizacional,tipo_contrato,estado,telefono,email_institucional,
       tiene_cert_idioma,tiene_libreta_militar,tiene_cert_capacitacion,tiene_dec_jurada_bienes,req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Funcionario no encontrado' });
    res.json(rows[0]);
  } catch (err) { next(err); }
};

// DELETE /api/personal/:id
exports.remove = async (req, res, next) => {
  try {
    const { rowCount } = await query('DELETE FROM personal WHERE id = $1', [req.params.id]);
    if (!rowCount) return res.status(404).json({ error: 'Funcionario no encontrado' });
    res.json({ message: 'Funcionario eliminado correctamente' });
  } catch (err) { next(err); }
};

// GET /api/personal/asistencia/hoy
exports.getAsistenciaHoy = async (req, res, next) => {
  try {
    const fecha = req.query.fecha || new Date().toISOString().split('T')[0];
    const { rows } = await query(
      `SELECT a.*, p.nombre_completo, p.cargo, p.unidad_organizacional, p.avatar_iniciales
       FROM asistencia a JOIN personal p ON a.personal_id = p.id
       WHERE a.fecha = $1 ORDER BY p.nombre_completo`, [fecha]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

// GET /api/personal/asistencia/historial
exports.getAsistenciaHistorial = async (req, res, next) => {
  try {
    const { personal_id, desde, hasta } = req.query;
    const conds = [], params = []; let i = 1;
    if (personal_id) { conds.push(`a.personal_id = $${i++}`); params.push(personal_id); }
    if (desde)       { conds.push(`a.fecha >= $${i++}`); params.push(desde); }
    if (hasta)       { conds.push(`a.fecha <= $${i++}`); params.push(hasta); }
    const w = conds.length ? `WHERE ${conds.join(' AND ')}` : '';
    const { rows } = await query(
      `SELECT a.*, p.nombre_completo FROM asistencia a
       JOIN personal p ON a.personal_id = p.id ${w} ORDER BY a.fecha DESC`, params
    );
    res.json(rows);
  } catch (err) { next(err); }
};

// GET /api/personal/asistencia/resumen
exports.getAsistenciaResumen = async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM v_asistencia_mensual LIMIT 12');
    res.json(rows);
  } catch (err) { next(err); }
};

// POST /api/personal/asistencia
exports.saveAsistencia = async (req, res, next) => {
  try {
    const { personal_id, fecha, hora_entrada, hora_salida, estado, observacion } = req.body;
    const { rows } = await query(
      `INSERT INTO asistencia (personal_id,fecha,hora_entrada,hora_salida,estado,observacion,registrado_por)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (personal_id,fecha) DO UPDATE SET
         hora_entrada=EXCLUDED.hora_entrada, hora_salida=EXCLUDED.hora_salida,
         estado=EXCLUDED.estado, observacion=EXCLUDED.observacion, updated_at=NOW()
       RETURNING *`,
      [personal_id,fecha,hora_entrada,hora_salida,estado,observacion,req.user.id]
    );
    res.json(rows[0]);
  } catch (err) { next(err); }
};

// GET /api/personal/desempeno/lista
exports.getDesempeno = async (req, res, next) => {
  try {
    const { periodo } = req.query;
    const { rows } = await query(
      `SELECT d.*, p.nombre_completo, p.cargo, p.unidad_organizacional
       FROM desempeno d JOIN personal p ON d.personal_id = p.id
       WHERE ($1::text IS NULL OR d.periodo = $1) ORDER BY d.promedio DESC`,
      [periodo || null]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

// POST /api/personal/desempeno
exports.saveDesempeno = async (req, res, next) => {
  try {
    const { personal_id, periodo, eficiencia, eficacia, resultado, observaciones } = req.body;
    const { rows } = await query(
      `INSERT INTO desempeno (personal_id,periodo,eficiencia,eficacia,resultado,observaciones,evaluado_por)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       ON CONFLICT (personal_id,periodo) DO UPDATE SET
         eficiencia=EXCLUDED.eficiencia, eficacia=EXCLUDED.eficacia,
         resultado=EXCLUDED.resultado, observaciones=EXCLUDED.observaciones
       RETURNING *`,
      [personal_id,periodo,eficiencia,eficacia,resultado,observaciones,req.user.id]
    );
    res.json(rows[0]);
  } catch (err) { next(err); }
};

// GET /api/personal/:id/permisos
exports.getPermisos = async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT pl.*, p.nombre_completo FROM permisos_licencias pl
       JOIN personal p ON pl.personal_id = p.id
       WHERE pl.personal_id = $1 ORDER BY pl.fecha_inicio DESC`,
      [req.params.id]
    );
    res.json(rows);
  } catch (err) { next(err); }
};

// POST /api/personal/permisos
exports.savePermiso = async (req, res, next) => {
  try {
    const { personal_id, tipo, motivo, fecha_inicio, fecha_fin } = req.body;
    const { rows } = await query(
      `INSERT INTO permisos_licencias (personal_id,tipo,motivo,fecha_inicio,fecha_fin,estado)
       VALUES ($1,$2,$3,$4,$5,'Pendiente') RETURNING *`,
      [personal_id,tipo,motivo,fecha_inicio,fecha_fin]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
};

// PUT /api/personal/permisos/:id/estado
exports.updatePermisoEstado = async (req, res, next) => {
  try {
    const { estado } = req.body;
    const { rows } = await query(
      `UPDATE permisos_licencias SET estado=$1, aprobado_por=$2
       WHERE id=$3 RETURNING *`,
      [estado, req.user.id, req.params.id]
    );
    res.json(rows[0]);
  } catch (err) { next(err); }
};
