require('dotenv').config();

const required = ['DB_HOST','DB_NAME','DB_USER','DB_PASS','JWT_SECRET'];
required.forEach(key => {
  if (!process.env[key]) {
    console.warn(`⚠️  Variable de entorno faltante: ${key}`);
  }
});

module.exports = {
  PORT:         process.env.PORT         || 4000,
  NODE_ENV:     process.env.NODE_ENV     || 'development',
  FRONTEND_URL: process.env.FRONTEND_URL || 'http://localhost:5173',
  JWT_SECRET:   process.env.JWT_SECRET   || 'gamea_fallback_secret',
  JWT_EXPIRES:  process.env.JWT_EXPIRES  || '8h',
  DB: {
    host:     process.env.DB_HOST || 'localhost',
    port:     parseInt(process.env.DB_PORT) || 5432,
    database: process.env.DB_NAME || 'gamea_db',
    user:     process.env.DB_USER || 'postgres',
    password: process.env.DB_PASS || 'postgres',
    ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
  },
};
