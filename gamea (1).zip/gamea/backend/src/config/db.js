const { Pool } = require('pg');
const { DB }   = require('./env');

const pool = new Pool({
  host:     DB.host,
  port:     DB.port,
  database: DB.database,
  user:     DB.user,
  password: DB.password,
  ssl:      DB.ssl,
  max:      10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('connect', () => {
  if (process.env.NODE_ENV !== 'test') {
    console.log('✅ PostgreSQL conectado →', DB.database);
  }
});

pool.on('error', (err) => {
  console.error('❌ Error en pool PostgreSQL:', err.message);
});

/**
 * Ejecuta una query con parámetros
 * @param {string} text  SQL query
 * @param {Array}  params parámetros
 */
const query = (text, params) => pool.query(text, params);

/**
 * Obtiene una conexión del pool (para transacciones)
 */
const getClient = () => pool.connect();

module.exports = { query, getClient, pool };
