const { query } = require('../config/db');

/**
 * Registra acciones en la tabla logs_sistema
 * @param {string} modulo  Nombre del módulo
 * @param {Function} getAccion  Función que recibe (req) y retorna la descripción del log
 */
const auditLog = (modulo, getAccion) => async (req, res, next) => {
  // Guardamos la función original de res.json para interceptar la respuesta
  const originalJson = res.json.bind(res);

  res.json = async (body) => {
    // Solo registrar si la respuesta fue exitosa (2xx)
    if (res.statusCode >= 200 && res.statusCode < 300 && req.user) {
      try {
        const accion = typeof getAccion === 'function'
          ? getAccion(req)
          : getAccion;

        await query(
          `INSERT INTO logs_sistema (usuario_id, modulo, accion, ip_address, detalles)
           VALUES ($1, $2, $3, $4, $5)`,
          [
            req.user.id,
            modulo,
            accion,
            req.ip || req.connection?.remoteAddress,
            JSON.stringify({ method: req.method, path: req.path, params: req.params }),
          ]
        );
      } catch (err) {
        console.error('Error al registrar log de auditoría:', err.message);
      }
    }
    return originalJson(body);
  };

  next();
};

/**
 * Función helper para guardar un log directamente
 */
const saveLog = async (userId, modulo, accion, ip = null, detalles = {}) => {
  try {
    await query(
      `INSERT INTO logs_sistema (usuario_id, modulo, accion, ip_address, detalles)
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, modulo, accion, ip, JSON.stringify(detalles)]
    );
  } catch (err) {
    console.error('saveLog error:', err.message);
  }
};

module.exports = { auditLog, saveLog };
