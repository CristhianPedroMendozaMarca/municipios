/**
 * Manejador global de errores de Express
 * Debe ser el último middleware registrado en app.js
 */
const errorHandler = (err, req, res, _next) => {
  console.error(`❌ [${req.method}] ${req.path} →`, err.message);

  // Error de violación de unicidad en PostgreSQL
  if (err.code === '23505') {
    return res.status(409).json({ error: 'El registro ya existe (dato duplicado).' });
  }

  // Error de clave foránea
  if (err.code === '23503') {
    return res.status(400).json({ error: 'Referencia a registro inexistente.' });
  }

  // Error de validación de tipo en PostgreSQL
  if (err.code === '22P02') {
    return res.status(400).json({ error: 'Tipo de dato inválido en la solicitud.' });
  }

  // Error de JWT
  if (err.name === 'JsonWebTokenError') {
    return res.status(401).json({ error: 'Token inválido.' });
  }

  if (err.name === 'TokenExpiredError') {
    return res.status(401).json({ error: 'Sesión expirada.' });
  }

  // Error genérico
  const status  = err.status || err.statusCode || 500;
  const message = err.message || 'Error interno del servidor';

  res.status(status).json({
    error:   message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
};

module.exports = errorHandler;
