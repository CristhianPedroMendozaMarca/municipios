/**
 * Middleware: verifica que el usuario autenticado tenga rol 'superuser'
 * Debe usarse después del middleware 'auth'
 */
const superUser = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ error: 'No autenticado' });
  }
  if (req.user.role !== 'superuser') {
    return res.status(403).json({
      error: 'Acceso denegado. Se requiere rol de Super Administrador.'
    });
  }
  next();
};

module.exports = superUser;
