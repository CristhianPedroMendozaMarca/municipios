const router = require('express').Router();

router.use('/auth',        require('./auth.routes'));
router.use('/personal',    require('./personal.routes'));
router.use('/activos',     require('./activos.routes'));
router.use('/proyectos',   require('./proyectos.routes'));
router.use('/tesoreria',   require('./tesoreria.routes'));
router.use('/dashboard',   require('./dashboard.routes'));
router.use('/admin',       require('./admin.routes'));

module.exports = router;
