const router = require('express').Router();
const ctrl   = require('../controllers/proyectos.controller');
const auth   = require('../middleware/auth.middleware');
const { auditLog } = require('../middleware/auditLog.middleware');

router.use(auth);

// ── Proyectos POA ─────────────────────────────────────────────
router.get   ('/',                   ctrl.getAll);
router.get   ('/stats',              ctrl.getStats);
router.get   ('/:id',                ctrl.getById);
router.post  ('/',                   auditLog('Planificación', req => `Creó proyecto: ${req.body.nombre}`), ctrl.create);
router.put   ('/:id',                auditLog('Planificación', req => `Modificó proyecto ID: ${req.params.id}`), ctrl.update);
router.delete('/:id',                auditLog('Planificación', req => `Eliminó proyecto ID: ${req.params.id}`), ctrl.remove);

// ── Avance físico y financiero ────────────────────────────────
router.put   ('/:id/avance',         auditLog('Planificación', req => `Actualizó avance proyecto ID: ${req.params.id}`), ctrl.updateAvance);
router.get   ('/:id/historial',      ctrl.getHistorialAvances);

// ── Certificados ──────────────────────────────────────────────
router.get   ('/certificados/lista', ctrl.getCertificados);
router.post  ('/certificados',       auditLog('Planificación', 'Emitió certificado de cumplimiento'), ctrl.createCertificado);

// ── Hojas de Ruta ─────────────────────────────────────────────
router.get   ('/hojarutas/lista',    ctrl.getHojasRuta);
router.post  ('/hojarutas',          auditLog('Hojas de Ruta', 'Creó hoja de ruta'), ctrl.createHojaRuta);
router.post  ('/hojarutas/seguimiento', auditLog('Hojas de Ruta', 'Registró seguimiento'), ctrl.saveSeguimiento);

module.exports = router;
