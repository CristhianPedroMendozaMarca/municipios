const router = require('express').Router();
const ctrl   = require('../controllers/personal.controller');
const auth   = require('../middleware/auth.middleware');
const { auditLog } = require('../middleware/auditLog.middleware');

// Todos los endpoints requieren autenticación
router.use(auth);

// ── Expediente Digital ───────────────────────────────────────
router.get   ('/',          ctrl.getAll);
router.get   ('/:id',       ctrl.getById);
router.post  ('/',          auditLog('Adm. Personal', req => `Registró funcionario: ${req.body.nombre_completo}`), ctrl.create);
router.put   ('/:id',       auditLog('Adm. Personal', req => `Modificó funcionario ID: ${req.params.id}`),       ctrl.update);
router.delete('/:id',       auditLog('Adm. Personal', req => `Eliminó funcionario ID: ${req.params.id}`),        ctrl.remove);

// ── Asistencia ────────────────────────────────────────────────
router.get   ('/asistencia/hoy',      ctrl.getAsistenciaHoy);
router.get   ('/asistencia/historial',ctrl.getAsistenciaHistorial);
router.get   ('/asistencia/resumen',  ctrl.getAsistenciaResumen);
router.post  ('/asistencia',          auditLog('Adm. Personal', 'Registró asistencia'), ctrl.saveAsistencia);

// ── Desempeño ─────────────────────────────────────────────────
router.get   ('/desempeno/lista',     ctrl.getDesempeno);
router.post  ('/desempeno',           auditLog('Adm. Personal', req => `Evaluó funcionario ID: ${req.body.personal_id}`), ctrl.saveDesempeno);

// ── Permisos y Licencias ──────────────────────────────────────
router.get   ('/:id/permisos',        ctrl.getPermisos);
router.post  ('/permisos',            auditLog('Adm. Personal', 'Registró permiso/licencia'), ctrl.savePermiso);
router.put   ('/permisos/:id/estado', auditLog('Adm. Personal', req => `Actualizó estado permiso ID: ${req.params.id}`), ctrl.updatePermisoEstado);

module.exports = router;
