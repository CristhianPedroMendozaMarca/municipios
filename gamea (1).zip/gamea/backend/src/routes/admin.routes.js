const router    = require('express').Router();
const ctrl      = require('../controllers/admin.controller');
const auth      = require('../middleware/auth.middleware');
const superUser = require('../middleware/superUser.middleware');
const { auditLog } = require('../middleware/auditLog.middleware');

// Todos los endpoints requieren auth + superUser
router.use(auth, superUser);

// ── Gestión de Usuarios ───────────────────────────────────────
router.get   ('/usuarios',                  ctrl.getUsuarios);
router.get   ('/usuarios/:id',              ctrl.getUsuarioById);
router.post  ('/usuarios',                  auditLog('Super Usuario', req => `Creó usuario: ${req.body.email}`),               ctrl.createUsuario);
router.put   ('/usuarios/:id',              auditLog('Super Usuario', req => `Modificó usuario ID: ${req.params.id}`),          ctrl.updateUsuario);
router.delete('/usuarios/:id',              auditLog('Super Usuario', req => `Eliminó usuario ID: ${req.params.id}`),           ctrl.deleteUsuario);
router.patch ('/usuarios/:id/toggle',       auditLog('Super Usuario', req => `Cambió estado usuario ID: ${req.params.id}`),     ctrl.toggleUsuario);
router.patch ('/usuarios/:id/password',     auditLog('Super Usuario', req => `Reseteó contraseña usuario ID: ${req.params.id}`),ctrl.resetPassword);

// ── Permisos ──────────────────────────────────────────────────
router.get   ('/permisos',                  ctrl.getPermisos);
router.put   ('/permisos/:usuarioId',       auditLog('Super Usuario', req => `Actualizó permisos usuario ID: ${req.params.usuarioId}`), ctrl.updatePermisos);

// ── Roles ─────────────────────────────────────────────────────
router.get   ('/roles',                     ctrl.getRoles);

// ── Logs del Sistema ──────────────────────────────────────────
router.get   ('/logs',                      ctrl.getLogs);
router.get   ('/logs/modulos',              ctrl.getModulosLog);

module.exports = router;
