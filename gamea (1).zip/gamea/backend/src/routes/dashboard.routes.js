const router = require('express').Router();
const ctrl   = require('../controllers/dashboard.controller');
const auth   = require('../middleware/auth.middleware');

router.use(auth);

router.get('/stats',       ctrl.getStats);
router.get('/asistencia',  ctrl.getAsistenciaChart);
router.get('/activos',     ctrl.getActivosChart);
router.get('/proyectos',   ctrl.getProyectosChart);
router.get('/actividad',   ctrl.getActividadReciente);

module.exports = router;
