const router = require('express').Router();
const ctrl   = require('../controllers/auth.controller');
const auth   = require('../middleware/auth.middleware');

// POST /api/auth/login        → Iniciar sesión
router.post('/login',            ctrl.login);

// POST /api/auth/logout       → Cerrar sesión (requiere token)
router.post('/logout',    auth,  ctrl.logout);

// PUT  /api/auth/password     → Cambiar propia contraseña
router.put('/password',   auth,  ctrl.changePassword);

// GET  /api/auth/me           → Info del usuario autenticado
router.get('/me',         auth,  ctrl.me);

module.exports = router;
