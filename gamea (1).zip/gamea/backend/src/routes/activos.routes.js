const router = require('express').Router();
const ctrl   = require('../controllers/activos.controller');
const auth   = require('../middleware/auth.middleware');
const { auditLog } = require('../middleware/auditLog.middleware');

router.use(auth);

// ── BSIAF ─────────────────────────────────────────────────────
router.get   ('/',            ctrl.getAll);
router.get   ('/stats',       ctrl.getStats);
router.get   ('/:id',         ctrl.getById);
router.post  ('/',            auditLog('Activos Fijos', req => `Registró activo: ${req.body.codigo_bsiaf}`), ctrl.create);
router.put   ('/:id',         auditLog('Activos Fijos', req => `Modificó activo ID: ${req.params.id}`),     ctrl.update);
router.delete('/:id',         auditLog('Activos Fijos', req => `Eliminó activo ID: ${req.params.id}`),      ctrl.remove);

// ── Mantenimiento ─────────────────────────────────────────────
router.get   ('/:id/mantenimiento', ctrl.getMantenimiento);
router.post  ('/mantenimiento',     auditLog('Activos Fijos', 'Registró mantenimiento'), ctrl.saveMantenimiento);

// ── Almacenes ─────────────────────────────────────────────────
router.get   ('/almacenes/lista',   ctrl.getAlmacenes);
router.post  ('/almacenes',         auditLog('Activos Fijos', 'Registró almacén'), ctrl.createAlmacen);
router.get   ('/almacenes/:id/inventario', ctrl.getInventario);
router.post  ('/almacenes/inventario',     auditLog('Activos Fijos', 'Actualizó inventario'), ctrl.saveInventario);

module.exports = router;
