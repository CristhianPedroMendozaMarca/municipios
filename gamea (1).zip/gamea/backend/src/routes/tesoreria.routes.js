const router = require('express').Router();
const ctrl   = require('../controllers/tesoreria.controller');
const auth   = require('../middleware/auth.middleware');
const { auditLog } = require('../middleware/auditLog.middleware');

router.use(auth);

// ── Transacciones ─────────────────────────────────────────────
router.get   ('/',              ctrl.getAll);
router.get   ('/stats',         ctrl.getStats);
router.get   ('/:id',           ctrl.getById);
router.post  ('/',              auditLog('Contabilidad', req => `Registró transacción: ${req.body.numero_referencia}`), ctrl.create);
router.put   ('/:id/estado',    auditLog('Contabilidad', req => `Actualizó estado transacción ID: ${req.params.id}`),   ctrl.updateEstado);
router.delete('/:id',           auditLog('Contabilidad', req => `Anuló transacción ID: ${req.params.id}`),              ctrl.remove);

// ── Contrataciones ────────────────────────────────────────────
router.get   ('/contrataciones/lista', ctrl.getContrataciones);
router.post  ('/contrataciones',       auditLog('Contabilidad', 'Registró contratación'), ctrl.createContratacion);
router.put   ('/contrataciones/:id',   auditLog('Contabilidad', req => `Modificó contratación ID: ${req.params.id}`), ctrl.updateContratacion);

module.exports = router;
