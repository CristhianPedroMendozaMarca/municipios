-- ═══════════════════════════════════════════════════════════
--  GAMEA — Esquema de Base de Datos PostgreSQL
--  Ejecutar: psql -U postgres -d gamea_db -f database/schema.sql
-- ═══════════════════════════════════════════════════════════
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ROLES
CREATE TABLE IF NOT EXISTS roles (
    id SERIAL PRIMARY KEY, nombre VARCHAR(50) NOT NULL UNIQUE,
    descripcion TEXT, permisos JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);
INSERT INTO roles (nombre,descripcion,permisos) VALUES
  ('superuser','Super Administrador','{"all":true}'),
  ('rrhh','Recursos Humanos','{"personal":true}'),
  ('activos','Activos Fijos','{"activos":true}'),
  ('planificacion','Planificación','{"planificacion":true,"hojarutas":true}'),
  ('finanzas','Contabilidad','{"hojarutas":true}')
ON CONFLICT DO NOTHING;

-- USUARIOS
CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY, nombre_completo VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE, password_hash TEXT NOT NULL,
    cargo VARCHAR(150), rol_id INT REFERENCES roles(id) ON DELETE SET NULL,
    avatar_iniciales VARCHAR(5), activo BOOLEAN DEFAULT TRUE,
    ultimo_acceso TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
INSERT INTO usuarios (nombre_completo,email,password_hash,cargo,rol_id,avatar_iniciales)
SELECT 'Carlos Mamani Choque','admin@gamea.bo',crypt('Admin123',gen_salt('bf',12)),'Super Administrador',r.id,'CM'
FROM roles r WHERE r.nombre='superuser' ON CONFLICT DO NOTHING;
INSERT INTO usuarios (nombre_completo,email,password_hash,cargo,rol_id,avatar_iniciales)
SELECT 'María Elena Quispe','rrhh@gamea.bo',crypt('Rrhh123',gen_salt('bf',12)),'Jefa de RRHH',r.id,'MQ'
FROM roles r WHERE r.nombre='rrhh' ON CONFLICT DO NOTHING;
INSERT INTO usuarios (nombre_completo,email,password_hash,cargo,rol_id,avatar_iniciales)
SELECT 'Pedro Flores López','activos@gamea.bo',crypt('Activos123',gen_salt('bf',12)),'Encargado de Activos',r.id,'PF'
FROM roles r WHERE r.nombre='activos' ON CONFLICT DO NOTHING;
INSERT INTO usuarios (nombre_completo,email,password_hash,cargo,rol_id,avatar_iniciales)
SELECT 'Ana Quispe Mamani','planif@gamea.bo',crypt('Planif123',gen_salt('bf',12)),'Planificadora',r.id,'AQ'
FROM roles r WHERE r.nombre='planificacion' ON CONFLICT DO NOTHING;

-- PERMISOS_USUARIO
CREATE TABLE IF NOT EXISTS permisos_usuario (
    id SERIAL PRIMARY KEY, usuario_id INT UNIQUE REFERENCES usuarios(id) ON DELETE CASCADE,
    personal BOOLEAN DEFAULT FALSE, activos BOOLEAN DEFAULT FALSE,
    planificacion BOOLEAN DEFAULT FALSE, hojarutas BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- PERSONAL
CREATE TABLE IF NOT EXISTS personal (
    id SERIAL PRIMARY KEY, codigo VARCHAR(20) UNIQUE, nombre_completo VARCHAR(200) NOT NULL,
    ci VARCHAR(20) UNIQUE NOT NULL, ci_expedicion VARCHAR(5) DEFAULT 'LP',
    fecha_nacimiento DATE, sexo CHAR(1), cargo VARCHAR(150), unidad_organizacional VARCHAR(150),
    tipo_contrato VARCHAR(50) CHECK (tipo_contrato IN ('Ítem','Eventual','Consultor')),
    estado VARCHAR(30) DEFAULT 'Activo' CHECK (estado IN ('Activo','Baja','Licencia','Suspendido')),
    fecha_ingreso DATE, fecha_baja DATE, motivo_baja TEXT,
    tiene_cert_idioma BOOLEAN DEFAULT FALSE, tiene_libreta_militar BOOLEAN DEFAULT FALSE,
    tiene_cert_capacitacion BOOLEAN DEFAULT FALSE, tiene_dec_jurada_bienes BOOLEAN DEFAULT FALSE,
    fecha_dec_jurada DATE, telefono VARCHAR(20), email_institucional VARCHAR(150),
    direccion TEXT, latitud DECIMAL(10,8), longitud DECIMAL(11,8),
    avatar_iniciales VARCHAR(5), foto_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE SEQUENCE IF NOT EXISTS personal_seq START 1;
CREATE OR REPLACE FUNCTION fn_personal_codigo() RETURNS TRIGGER AS $$
BEGIN IF NEW.codigo IS NULL THEN NEW.codigo:='F-'||LPAD(nextval('personal_seq')::TEXT,3,'0'); END IF; RETURN NEW; END;
$$ LANGUAGE plpgsql;
CREATE OR REPLACE TRIGGER tr_personal_codigo BEFORE INSERT ON personal FOR EACH ROW EXECUTE FUNCTION fn_personal_codigo();
CREATE INDEX IF NOT EXISTS idx_personal_ci     ON personal(ci);
CREATE INDEX IF NOT EXISTS idx_personal_estado  ON personal(estado);
CREATE INDEX IF NOT EXISTS idx_personal_unidad  ON personal(unidad_organizacional);

-- ASISTENCIA
CREATE TABLE IF NOT EXISTS asistencia (
    id SERIAL PRIMARY KEY, personal_id INT REFERENCES personal(id) ON DELETE CASCADE,
    fecha DATE NOT NULL, hora_entrada TIME, hora_salida TIME,
    estado VARCHAR(30) DEFAULT 'Presente' CHECK (estado IN ('Presente','Tardanza','Ausente','Permiso','Licencia','Feriado')),
    observacion TEXT, registrado_por INT REFERENCES usuarios(id),
    fuente VARCHAR(20) DEFAULT 'Manual' CHECK (fuente IN ('Manual','Biometrico','Geolocalización')),
    latitud DECIMAL(10,8), longitud DECIMAL(11,8),
    created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(personal_id, fecha)
);
CREATE INDEX IF NOT EXISTS idx_asistencia_fecha    ON asistencia(fecha);
CREATE INDEX IF NOT EXISTS idx_asistencia_personal ON asistencia(personal_id);

-- DESEMPEÑO
CREATE TABLE IF NOT EXISTS desempeno (
    id SERIAL PRIMARY KEY, personal_id INT REFERENCES personal(id) ON DELETE CASCADE,
    periodo VARCHAR(20) NOT NULL, eficiencia DECIMAL(5,2) CHECK (eficiencia BETWEEN 0 AND 100),
    eficacia DECIMAL(5,2) CHECK (eficacia BETWEEN 0 AND 100), resultado DECIMAL(5,2) CHECK (resultado BETWEEN 0 AND 100),
    promedio DECIMAL(5,2) GENERATED ALWAYS AS ((eficiencia+eficacia+resultado)/3) STORED,
    nivel VARCHAR(20) GENERATED ALWAYS AS (
      CASE WHEN (eficiencia+eficacia+resultado)/3>=85 THEN 'Excelente'
           WHEN (eficiencia+eficacia+resultado)/3>=70 THEN 'Bueno'
           WHEN (eficiencia+eficacia+resultado)/3>=60 THEN 'Regular'
           ELSE 'Deficiente' END) STORED,
    observaciones TEXT, evaluado_por INT REFERENCES usuarios(id),
    created_at TIMESTAMPTZ DEFAULT NOW(), UNIQUE(personal_id, periodo)
);

-- PERMISOS_LICENCIAS
CREATE TABLE IF NOT EXISTS permisos_licencias (
    id SERIAL PRIMARY KEY, personal_id INT REFERENCES personal(id) ON DELETE CASCADE,
    tipo VARCHAR(50) NOT NULL, motivo VARCHAR(200), fecha_inicio DATE NOT NULL, fecha_fin DATE NOT NULL,
    dias INT GENERATED ALWAYS AS (fecha_fin - fecha_inicio + 1) STORED,
    estado VARCHAR(20) DEFAULT 'Pendiente', aprobado_por INT REFERENCES usuarios(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ACTIVOS_FIJOS
CREATE TABLE IF NOT EXISTS activos_fijos (
    id SERIAL PRIMARY KEY, codigo_bsiaf VARCHAR(50) UNIQUE NOT NULL,
    descripcion VARCHAR(300) NOT NULL, categoria VARCHAR(100), marca VARCHAR(100),
    modelo VARCHAR(100), serie VARCHAR(100), numero_inventario VARCHAR(50),
    ubicacion VARCHAR(200), unidad_org VARCHAR(150), responsable VARCHAR(200),
    estado VARCHAR(30) DEFAULT 'Bueno' CHECK (estado IN ('Excelente','Bueno','Regular','Malo','Dado de Baja')),
    valor_adquisicion DECIMAL(15,2), valor_actual DECIMAL(15,2), fecha_adquisicion DATE,
    vida_util_anos INT, depreciacion_anual DECIMAL(15,2), fuente_financiamiento VARCHAR(100),
    latitud DECIMAL(10,8), longitud DECIMAL(11,8), especificaciones JSONB DEFAULT '{}', observaciones TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_activos_cat    ON activos_fijos(categoria);
CREATE INDEX IF NOT EXISTS idx_activos_estado ON activos_fijos(estado);

-- MANTENIMIENTO_ACTIVOS
CREATE TABLE IF NOT EXISTS mantenimiento_activos (
    id SERIAL PRIMARY KEY, activo_id INT REFERENCES activos_fijos(id) ON DELETE CASCADE,
    tipo VARCHAR(50), descripcion TEXT, costo DECIMAL(12,2), proveedor VARCHAR(200),
    fecha_inicio DATE, fecha_fin DATE, tecnico VARCHAR(150), created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ALMACENES
CREATE TABLE IF NOT EXISTS almacenes (
    id SERIAL PRIMARY KEY, nombre VARCHAR(150) NOT NULL, ubicacion VARCHAR(200),
    responsable VARCHAR(200), capacidad INT, descripcion TEXT,
    activo BOOLEAN DEFAULT TRUE, created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS inventario_almacen (
    id SERIAL PRIMARY KEY, almacen_id INT REFERENCES almacenes(id),
    descripcion VARCHAR(300) NOT NULL, unidad_medida VARCHAR(50),
    cantidad DECIMAL(12,2) DEFAULT 0, cantidad_minima DECIMAL(12,2) DEFAULT 0,
    valor_unitario DECIMAL(12,2), codigo VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- PROYECTOS
CREATE TABLE IF NOT EXISTS proyectos (
    id SERIAL PRIMARY KEY, codigo VARCHAR(20) UNIQUE,
    nombre VARCHAR(300) NOT NULL, sector VARCHAR(150), descripcion TEXT,
    presupuesto DECIMAL(15,2) DEFAULT 0,
    avance_fisico DECIMAL(5,2) DEFAULT 0 CHECK (avance_fisico BETWEEN 0 AND 100),
    avance_financiero DECIMAL(5,2) DEFAULT 0 CHECK (avance_financiero BETWEEN 0 AND 100),
    estado VARCHAR(50) DEFAULT 'Planificado' CHECK (estado IN ('Planificado','Inicio','Ejecución','Por Cerrar','Finalizado','Suspendido')),
    fecha_inicio DATE, fecha_fin DATE, fecha_inicio_real DATE, fecha_fin_real DATE,
    responsable VARCHAR(200), fuente_financiamiento VARCHAR(100),
    geojson JSONB, latitud DECIMAL(10,8), longitud DECIMAL(11,8),
    created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE SEQUENCE IF NOT EXISTS proyectos_seq START 1;
CREATE OR REPLACE FUNCTION fn_proyecto_codigo() RETURNS TRIGGER AS $$
BEGIN IF NEW.codigo IS NULL THEN NEW.codigo:='PRY-'||LPAD(nextval('proyectos_seq')::TEXT,3,'0'); END IF; RETURN NEW; END;
$$ LANGUAGE plpgsql;
CREATE OR REPLACE TRIGGER tr_proyecto_codigo BEFORE INSERT ON proyectos FOR EACH ROW EXECUTE FUNCTION fn_proyecto_codigo();
CREATE INDEX IF NOT EXISTS idx_proyectos_estado ON proyectos(estado);
CREATE INDEX IF NOT EXISTS idx_proyectos_sector ON proyectos(sector);

-- HISTORIAL_AVANCES
CREATE TABLE IF NOT EXISTS historial_avances (
    id SERIAL PRIMARY KEY, proyecto_id INT REFERENCES proyectos(id) ON DELETE CASCADE,
    avance_fisico DECIMAL(5,2), avance_financiero DECIMAL(5,2),
    observacion TEXT, registrado_por INT REFERENCES usuarios(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- CERTIFICADOS
CREATE TABLE IF NOT EXISTS certificados (
    id SERIAL PRIMARY KEY, proyecto_id INT REFERENCES proyectos(id),
    numero_certificado VARCHAR(50) UNIQUE, fecha_emision DATE DEFAULT CURRENT_DATE,
    observaciones TEXT, emitido_por INT REFERENCES usuarios(id), created_at TIMESTAMPTZ DEFAULT NOW()
);

-- HOJAS_RUTA
CREATE TABLE IF NOT EXISTS hojas_ruta (
    id SERIAL PRIMARY KEY, codigo VARCHAR(30) UNIQUE, nombre VARCHAR(300) NOT NULL,
    tipo VARCHAR(50), descripcion TEXT, responsable_id INT REFERENCES personal(id),
    fecha_inicio DATE, fecha_fin DATE, estado VARCHAR(50) DEFAULT 'Activo',
    observaciones TEXT, created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS seguimiento_hojas_ruta (
    id SERIAL PRIMARY KEY, hoja_ruta_id INT REFERENCES hojas_ruta(id),
    fecha_seguimiento DATE DEFAULT CURRENT_DATE, descripcion_avance TEXT,
    porcentaje_avance DECIMAL(5,2), observaciones TEXT,
    registrado_por INT REFERENCES usuarios(id), created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TESORERÍA
CREATE TABLE IF NOT EXISTS transacciones_tesoreria (
    id SERIAL PRIMARY KEY, tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('Ingreso','Egreso')),
    descripcion VARCHAR(300) NOT NULL, monto DECIMAL(15,2) NOT NULL, fuente VARCHAR(100),
    partida_presupuestaria VARCHAR(50), numero_referencia VARCHAR(100) UNIQUE,
    fecha_transaccion DATE DEFAULT CURRENT_DATE,
    estado VARCHAR(30) DEFAULT 'Pendiente' CHECK (estado IN ('Pendiente','Acreditado','Pagado','Anulado')),
    proyecto_id INT REFERENCES proyectos(id), aprobado_por INT REFERENCES usuarios(id),
    observaciones TEXT, created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_tesoreria_fecha ON transacciones_tesoreria(fecha_transaccion);

-- CONTRATACIONES
CREATE TABLE IF NOT EXISTS contrataciones (
    id SERIAL PRIMARY KEY, numero_contrato VARCHAR(50) UNIQUE NOT NULL,
    proveedor VARCHAR(300) NOT NULL, objeto_contratacion TEXT NOT NULL,
    modalidad VARCHAR(100), monto_contrato DECIMAL(15,2), fecha_inicio DATE, fecha_fin DATE,
    estado VARCHAR(30) DEFAULT 'Vigente', proyecto_id INT REFERENCES proyectos(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- LOGS_SISTEMA
CREATE TABLE IF NOT EXISTS logs_sistema (
    id BIGSERIAL PRIMARY KEY, usuario_id INT REFERENCES usuarios(id) ON DELETE SET NULL,
    modulo VARCHAR(100) NOT NULL, accion TEXT NOT NULL, ip_address INET,
    user_agent TEXT, detalles JSONB DEFAULT '{}', created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_logs_usuario ON logs_sistema(usuario_id);
CREATE INDEX IF NOT EXISTS idx_logs_modulo  ON logs_sistema(modulo);
CREATE INDEX IF NOT EXISTS idx_logs_fecha   ON logs_sistema(created_at DESC);

-- FUNCIÓN updated_at
CREATE OR REPLACE FUNCTION fn_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at=NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DO $$ DECLARE t TEXT; BEGIN
  FOR t IN SELECT unnest(ARRAY['usuarios','personal','activos_fijos','proyectos','hojas_ruta','permisos_usuario','inventario_almacen','asistencia'])
  LOOP EXECUTE FORMAT('DROP TRIGGER IF EXISTS tr_upd ON %I; CREATE TRIGGER tr_upd BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION fn_updated_at();',t,t); END LOOP;
END $$;

-- VISTAS
CREATE OR REPLACE VIEW v_asistencia_mensual AS
SELECT DATE_TRUNC('month',fecha) AS mes, COUNT(*) FILTER(WHERE estado='Presente') AS presentes,
       COUNT(*) FILTER(WHERE estado='Tardanza') AS tardanzas, COUNT(*) FILTER(WHERE estado='Ausente') AS ausentes,
       COUNT(*) AS total FROM asistencia GROUP BY DATE_TRUNC('month',fecha) ORDER BY mes DESC;

CREATE OR REPLACE VIEW v_activos_resumen AS
SELECT categoria, COUNT(*) AS total,
       COUNT(*) FILTER(WHERE estado IN ('Excelente','Bueno')) AS buen_estado,
       ROUND(SUM(valor_adquisicion),2) AS valor_total
FROM activos_fijos WHERE estado!='Dado de Baja' GROUP BY categoria;

CREATE OR REPLACE VIEW v_dashboard_proyectos AS
SELECT sector, COUNT(*) AS total, COUNT(*) FILTER(WHERE estado='Ejecución') AS en_ejecucion,
       COUNT(*) FILTER(WHERE estado='Finalizado') AS finalizados,
       ROUND(AVG(avance_fisico),1) AS avance_fisico_prom, SUM(presupuesto) AS presupuesto_total
FROM proyectos GROUP BY sector;

-- DATOS INICIALES
INSERT INTO personal (nombre_completo,ci,cargo,unidad_organizacional,tipo_contrato,estado,fecha_ingreso,avatar_iniciales,tiene_cert_capacitacion,tiene_dec_jurada_bienes) VALUES
  ('Roberto Cáceres Vera','5678901','Técnico en Sistemas','Infraestructura TI','Ítem','Activo','2022-03-15','RC',TRUE,TRUE),
  ('Lucía Mamani Flores','4567890','Auxiliar Administrativa','Administración General','Eventual','Activo','2024-01-08','LM',FALSE,FALSE),
  ('José Luis Quispe Condori','6789012','Ingeniero Civil','Obras Públicas','Consultor','Activo','2024-02-10','JQ',TRUE,TRUE),
  ('Carmen Rosa Alvarado','3456789','Secretaria Ejecutiva','Despacho Alcaldía','Ítem','Activo','2021-06-01','CA',TRUE,TRUE),
  ('Raúl Condori Mamani','7890123','Chofer Ejecutivo','Transporte','Ítem','Licencia','2020-01-15','RC',TRUE,TRUE),
  ('Elena Torrez Choque','2345678','Abogada Municipal','Asesoría Legal','Ítem','Activo','2019-07-20','ET',TRUE,TRUE),
  ('Marco Huanca Apaza','8901234','Contador','Finanzas','Ítem','Activo','2022-09-01','MH',TRUE,TRUE),
  ('Sandra Rojas Vda. de Lima','1234567','Trabajadora Social','Desarrollo Social','Eventual','Activo','2024-03-01','SR',FALSE,FALSE)
ON CONFLICT (ci) DO NOTHING;

INSERT INTO activos_fijos (descripcion,codigo_bsiaf,categoria,ubicacion,valor_adquisicion,estado,responsable,fecha_adquisicion) VALUES
  ('Computadora HP EliteDesk 800 G6','GAMEA/TI/2022/001','Equipo Tecnológico','Oficina TI',8500.00,'Bueno','Carlos Choque','2022-03-15'),
  ('Vehículo Toyota HiLux 4x4','GAMEA/TRS/2021/005','Vehículo','Parque Automotor',125000.00,'Bueno','Jef. Transporte','2021-08-20'),
  ('Motoniveladora Caterpillar 140M3','GAMEA/OPU/2019/001','Maquinaria Pesada','Almacén Central',450000.00,'Regular','Dir. Obras Públicas','2019-01-10'),
  ('Escritorio Ejecutivo Nogal','GAMEA/MOB/2023/012','Mobiliario','Despacho Alcaldía',2800.00,'Excelente','Sec. Alcaldía','2023-05-01'),
  ('Proyector Epson EB-U05','GAMEA/TI/2022/015','Equipo Tecnológico','Sala Reuniones A',5600.00,'Bueno','Administración','2022-11-30')
ON CONFLICT (codigo_bsiaf) DO NOTHING;

INSERT INTO proyectos (nombre,sector,presupuesto,avance_fisico,avance_financiero,estado,fecha_inicio,fecha_fin) VALUES
  ('Pavimentación Calle 14 Zona Norte','Infraestructura Vial',2500000,65,60,'Ejecución','2024-01-15','2024-12-31'),
  ('Sistema Agua Potable Zona Sur','Servicios Básicos',1800000,30,25,'Ejecución','2024-03-01','2025-02-28'),
  ('Mercado Municipal 23 de Marzo','Desarrollo Económico',3200000,10,8,'Inicio','2024-04-15','2025-06-30'),
  ('Refacción Unidad Educativa 16 de Julio','Educación',450000,90,88,'Por Cerrar','2024-01-10','2024-08-30'),
  ('Mantenimiento Parques y Plazas','Medio Ambiente',280000,100,97,'Finalizado','2024-01-02','2024-04-30')
ON CONFLICT DO NOTHING;

INSERT INTO transacciones_tesoreria (tipo,descripcion,monto,fuente,numero_referencia,fecha_transaccion,estado) VALUES
  ('Ingreso','Coparticipación Tributaria Municipal',1245680.00,'TGN','TGN-2024-0612','2024-06-02','Acreditado'),
  ('Egreso','Pago Planilla Personal Ítem',856340.00,'Interno','ORD-2024-0145','2024-06-05','Pagado'),
  ('Ingreso','Transferencia Inversión Pública',580000.00,'TGN','TGN-2024-0628','2024-06-08','Acreditado'),
  ('Egreso','Contratación Materiales Construcción',124500.00,'Interno','ORD-2024-0162','2024-06-12','Pagado'),
  ('Ingreso','IDH Municipal Junio 2024',342150.00,'IDH','TGN-2024-0641','2024-06-15','Pendiente')
ON CONFLICT DO NOTHING;
