# 🏛️ GAMEA — Sistema Municipal Integrado
### Gobierno Autónomo Municipal de El Alto, Bolivia

---

## 📁 Estructura del Proyecto

```
gamea/
├── frontend/                        ← React 18 + Vite + Bootstrap 5
│   ├── src/
│   │   ├── api/                     ← Llamadas HTTP al backend
│   │   │   ├── axios.js             (instancia Axios + interceptors)
│   │   │   ├── auth.api.js
│   │   │   ├── personal.api.js
│   │   │   ├── activos.api.js
│   │   │   ├── proyectos.api.js
│   │   │   ├── tesoreria.api.js
│   │   │   └── admin.api.js
│   │   ├── components/
│   │   │   ├── common/              ← Avatar, Badge, Progress, Modal, StatCard, DataTable, PageHeader
│   │   │   ├── layout/              ← Sidebar, Topbar, MainLayout
│   │   │   └── landing/             ← LandingNavbar, Hero, QuienesSomos, MisionVision, Footer
│   │   ├── context/
│   │   │   └── AuthContext.jsx      ← Estado global de autenticación
│   │   ├── hooks/
│   │   │   ├── useAuth.js
│   │   │   └── usePermissions.js
│   │   ├── pages/
│   │   │   ├── LandingPage.jsx
│   │   │   ├── auth/LoginPage.jsx
│   │   │   ├── dashboard/DashboardPage.jsx
│   │   │   ├── personal/            ← PersonalPage + 4 tabs
│   │   │   ├── activos/             ← ActivosPage + 2 tabs
│   │   │   ├── planificacion/       ← PlanificacionPage + 3 tabs
│   │   │   ├── hojarutas/           ← HojasRutaPage + 3 tabs
│   │   │   └── superuser/           ← SuperUserPage + 3 tabs
│   │   ├── styles/theme.css         ← Variables CSS + estilos del sistema
│   │   ├── utils/
│   │   │   ├── constants.js
│   │   │   ├── helpers.js
│   │   │   └── mockData.js          ← Datos mock para modo sin backend
│   │   ├── App.jsx                  ← Router principal (React Router v6)
│   │   └── main.jsx
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
│
├── backend/                         ← Node.js + Express + PostgreSQL
│   ├── src/
│   │   ├── config/
│   │   │   ├── db.js                ← Pool PostgreSQL
│   │   │   └── env.js               ← Variables de entorno
│   │   ├── middleware/
│   │   │   ├── auth.middleware.js
│   │   │   ├── superUser.middleware.js
│   │   │   ├── auditLog.middleware.js
│   │   │   └── errorHandler.middleware.js
│   │   ├── routes/
│   │   │   ├── index.js
│   │   │   ├── auth.routes.js
│   │   │   ├── personal.routes.js
│   │   │   ├── activos.routes.js
│   │   │   ├── proyectos.routes.js
│   │   │   ├── tesoreria.routes.js
│   │   │   ├── dashboard.routes.js
│   │   │   └── admin.routes.js
│   │   └── controllers/
│   │       ├── auth.controller.js
│   │       ├── personal.controller.js
│   │       ├── activos.controller.js
│   │       ├── proyectos.controller.js
│   │       ├── tesoreria.controller.js
│   │       ├── dashboard.controller.js
│   │       └── admin.controller.js
│   ├── database/
│   │   └── schema.sql               ← Tablas, vistas, triggers, datos iniciales
│   ├── server.js
│   ├── src/app.js
│   ├── package.json
│   └── .env.example
│
└── README.md
```

---

## ⚡ Instalación Paso a Paso

### Requisitos Previos
- **Node.js** v18+ → https://nodejs.org
- **PostgreSQL** v14+ → https://www.postgresql.org
- **npm** v9+

---

### 1️⃣ Base de Datos

```bash
# Crear la base de datos
psql -U postgres -c "CREATE DATABASE gamea_db ENCODING 'UTF8';"

# Ejecutar esquema completo
psql -U postgres -d gamea_db -f backend/database/schema.sql
```

---

### 2️⃣ Backend

```bash
cd backend

# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env
# Editar .env con sus datos de PostgreSQL

# Modo desarrollo (hot-reload)
npm run dev

# Modo producción
npm start
```

✅ API disponible en: **http://localhost:4000**
🔍 Health check: `GET http://localhost:4000/api/health`

---

### 3️⃣ Frontend

```bash
cd frontend

# Instalar dependencias
npm install

# Modo desarrollo
npm run dev

# Construir para producción
npm run build
```

✅ App disponible en: **http://localhost:5173**

---

## 🔐 Credenciales de Acceso

| Rol | Correo | Contraseña | Módulos |
|-----|--------|-----------|---------|
| Super Administrador | admin@gamea.bo | Admin123 | **Todo + Super Usuario** |
| RRHH | rrhh@gamea.bo | Rrhh123 | Adm. Personal |
| Activos | activos@gamea.bo | Activos123 | Activos Fijos |
| Planificación | planif@gamea.bo | Planif123 | Planificación + Hojas de Ruta |

---

## 🗂️ Módulos del Sistema

### 🏠 Landing Page
- Navbar fijo con scroll suave
- Hero con mockup de dashboard animado
- Secciones: Quiénes Somos, Misión, Visión

### 📊 Dashboard
- 4 KPI cards con tendencias
- Gráfico de barras: Asistencia mensual (Recharts)
- Gráfico de torta: Activos por categoría
- Gráfico de barras horizontales: Avance de proyectos
- Feed de actividad reciente

### 👥 Administración de Personal
| Sub-módulo | Funcionalidad |
|-----------|--------------|
| Expediente Digital | CRUD completo, búsqueda por nombre/CI, modal de edición |
| Control Asistencia | Registro diario, estados, resumen visual del día |
| Evaluación Desempeño | Indicadores eficiencia/eficacia/resultado con barras |
| KPIs / Dashboard | Índices de puntualidad, rotación, distribución por contrato |

### 🏢 Activos Fijos
| Sub-módulo | Funcionalidad |
|-----------|--------------|
| BSIAF | Registro oficial con código, búsqueda, modal de registro |
| Control Almacenes | Listado de almacenes con inventario |

### 📋 Planificación
| Sub-módulo | Funcionalidad |
|-----------|--------------|
| POA | Tabla de proyectos con presupuesto y avances |
| Seguimiento Físico | Cards por proyecto con barras de avance |
| Certificados | Estado de certificación por proyecto |

### 🗺️ Hojas de Ruta
| Sub-módulo | Funcionalidad |
|-----------|--------------|
| Programas/Proyectos | Tabla completa con avances físico/financiero |
| Seguimiento | Cards de seguimiento con porcentaje |
| Contabilidad/Tesorería | KPIs + tabla de movimientos ingresos/egresos |

### 🛡️ Super Usuario
| Sub-módulo | Funcionalidad |
|-----------|--------------|
| Gestión Usuarios | CRUD completo: crear, editar, habilitar/inhabilitar |
| Permisos de Acceso | Matriz de checkboxes por módulo y usuario |
| Logs del Sistema | Auditoría con filtros por usuario, módulo y búsqueda |

---

## 📡 API REST — Endpoints Principales

```
# Autenticación
POST   /api/auth/login
POST   /api/auth/logout
PUT    /api/auth/password
GET    /api/auth/me

# Personal
GET    /api/personal?search=&unidad=&tipo=&estado=&page=&limit=
POST   /api/personal
PUT    /api/personal/:id
DELETE /api/personal/:id
GET    /api/personal/asistencia/hoy?fecha=
POST   /api/personal/asistencia
GET    /api/personal/desempeno/lista?periodo=
POST   /api/personal/desempeno

# Activos
GET    /api/activos?search=&estado=&categoria=
POST   /api/activos
PUT    /api/activos/:id
DELETE /api/activos/:id
GET    /api/activos/almacenes/lista

# Proyectos / Planificación
GET    /api/proyectos?estado=&sector=
POST   /api/proyectos
PUT    /api/proyectos/:id/avance
GET    /api/proyectos/certificados/lista
GET    /api/proyectos/hojarutas/lista

# Tesorería
GET    /api/tesoreria?tipo=&estado=&desde=&hasta=
POST   /api/tesoreria
GET    /api/tesoreria/contrataciones/lista

# Dashboard
GET    /api/dashboard/stats
GET    /api/dashboard/asistencia
GET    /api/dashboard/activos
GET    /api/dashboard/proyectos
GET    /api/dashboard/actividad

# Super Usuario (requiere rol superuser)
GET    /api/admin/usuarios
POST   /api/admin/usuarios
PUT    /api/admin/usuarios/:id
DELETE /api/admin/usuarios/:id
PATCH  /api/admin/usuarios/:id/toggle
PATCH  /api/admin/usuarios/:id/password
GET    /api/admin/permisos
PUT    /api/admin/permisos/:usuarioId
GET    /api/admin/roles
GET    /api/admin/logs?usuario_id=&modulo=&desde=&hasta=&search=
```

---

## 🗄️ Base de Datos — Tablas

| Tabla | Descripción |
|-------|-------------|
| `roles` | Roles del sistema |
| `usuarios` | Cuentas de acceso con bcrypt |
| `permisos_usuario` | Matriz de permisos por módulo |
| `personal` | Expediente digital (Ley SAFCO) |
| `asistencia` | Control diario con geolocalización |
| `desempeno` | Evaluaciones con columnas calculadas |
| `permisos_licencias` | Gestión de permisos y licencias |
| `activos_fijos` | Registro BSIAF |
| `mantenimiento_activos` | Historial de mantenimiento |
| `almacenes` + `inventario_almacen` | Control de almacenes |
| `proyectos` | POA con avances físico/financiero |
| `historial_avances` | Trazabilidad de avances |
| `certificados` | Certificados de cumplimiento |
| `hojas_ruta` + `seguimiento_hojas_ruta` | Hojas de ruta |
| `transacciones_tesoreria` | Contabilidad y tesorería |
| `contrataciones` | Contratos y licitaciones |
| `logs_sistema` | Auditoría completa del sistema |

---

## 🛡️ Seguridad

- **JWT** con expiración de 8 horas
- **bcrypt** con 12 rondas de salt para contraseñas
- **RBAC** Control de acceso basado en roles
- **Helmet.js** Headers HTTP seguros
- **CORS** restringido al dominio del frontend
- **Audit Logs** automáticos en cada operación

---

## 🔧 Variables de Entorno

```env
# backend/.env
PORT=4000
NODE_ENV=development
FRONTEND_URL=http://localhost:5173

DB_HOST=localhost
DB_PORT=5432
DB_NAME=gamea_db
DB_USER=postgres
DB_PASS=TU_PASSWORD_AQUI

JWT_SECRET=clave_muy_larga_y_segura_cambiar_en_produccion
JWT_EXPIRES=8h
```

---

## 📋 Marco Legal

Desarrollado en cumplimiento de:
- **Ley N° 1178** — SAFCO (Sistema de Administración y Control Gubernamental)
- **Estatuto del Funcionario Público** — Bolivia
- **Manuales de Organización y Funciones (MOF)** — GAMEA
- **Plan Estratégico Institucional (PEI)** — GAMEA

---

## 🔧 Stack Tecnológico

| Capa | Tecnología |
|------|-----------|
| Frontend | React 18 + React Router v6 + Vite |
| UI | Bootstrap 5.3 + Bootstrap Icons + Lucide React |
| Gráficos | Recharts |
| HTTP | Axios |
| Backend | Node.js + Express.js |
| Base de datos | PostgreSQL 14+ |
| Auth | JWT (jsonwebtoken) + bcryptjs |
| Seguridad | Helmet + CORS |
| Dev | Nodemon |

---

*© 2024 Gobierno Autónomo Municipal de El Alto — Sistema Municipal Integrado*
